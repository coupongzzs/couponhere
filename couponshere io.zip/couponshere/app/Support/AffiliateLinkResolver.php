<?php

namespace App\Support;

use App\Models\Category;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

final class AffiliateLinkResolver
{
    public function __construct(
        private readonly MerchantProductExtractor $productExtractor = new MerchantProductExtractor(),
        private readonly MerchantProductEnricher $productEnricher = new MerchantProductEnricher(),
        private readonly GeminiBlogWriter $geminiWriter = new GeminiBlogWriter(),
        private readonly MerchantPricingOfferExtractor $pricingOfferExtractor = new MerchantPricingOfferExtractor(),
    ) {}

    public function finalUrl(string $affiliateUrl): string
    {
        $affiliateUrl = trim($affiliateUrl);

        if ($affiliateUrl === '') {
            return '';
        }

        $redirected = $this->followRedirects($affiliateUrl);
        $seedUrl = $this->unwrapAffiliateUrl($affiliateUrl);

        if ($seedUrl === $affiliateUrl) {
            return $redirected;
        }

        $unwrappedFinal = $this->followRedirects($seedUrl);
        $host = parse_url($unwrappedFinal, PHP_URL_HOST);

        if (is_string($host) && $host !== '') {
            $host = preg_replace('/^www\./', '', strtolower($host));

            if (! $this->isAffiliateHost($host)) {
                return $unwrappedFinal;
            }
        }

        return $redirected;
    }

    public function resolve(string $affiliateUrl, bool $productFocus = false): array
    {
        $affiliateUrl = trim($affiliateUrl);
        $seedUrl = $this->unwrapAffiliateUrl($affiliateUrl);
        $finalUrl = $this->finalUrl($affiliateUrl);
        $host = $this->merchantDomain($finalUrl, $seedUrl, $affiliateUrl);

        $html = $this->fetchHtml($finalUrl) ?? $this->fetchHtml($seedUrl) ?? $this->fetchHtml($affiliateUrl);
        $pageTitle = $this->extractTitle($html);
        $metaDescription = $this->extractMetaDescription($html);
        $name = $this->guessStoreName($host, $pageTitle);
        $category = $this->guessCategory($host, $pageTitle, $metaDescription, $finalUrl);
        $logo = $this->resolveLogo($host, $finalUrl, $html);
        $faqs = $this->extractFaqs($html);
        $products = $productFocus
            ? $this->discoverFocusedProduct($finalUrl, $html)
            : $this->discoverProducts($finalUrl, $html, [
                'store_name' => $name,
                'category_name' => $category?->name,
                'meta_description' => $metaDescription,
                'page_title' => $pageTitle,
                'domain' => $host,
            ]);
        $banner = $this->extractBannerImage($html, $finalUrl);

        if ($productFocus && $products !== [] && filled($products[0]['name'] ?? null)) {
            $name = Str::limit((string) $products[0]['name'], 100, '');
        }

        $pricingOffers = [];
        if (! $productFocus && $this->productExtractor->uniqueTake($products, max(count($products), 1)) === []) {
            $pricingOffers = $this->discoverPricingOffers($finalUrl ?: $seedUrl ?: $affiliateUrl, $html);
        }

        return [
            'affiliate_url' => $affiliateUrl,
            'final_url' => $finalUrl,
            'domain' => $host,
            'name' => $name,
            'logo' => $logo,
            'banner' => $banner,
            'page_title' => $pageTitle,
            'meta_description' => $metaDescription,
            'category_id' => $category?->id,
            'category_name' => $category?->name,
            'faqs' => $faqs,
            'products' => $products,
            'pricing_offers' => $pricingOffers,
            'product_focus' => $productFocus,
        ];
    }

    /**
     * Pull FAQ and extra copy from the public store website when provided.
     *
     * @param  array<string, mixed>  $merchant
     * @return array<string, mixed>
     */
    public function enrichFromWebsite(array $merchant, string $websiteUrl, bool $productFocus = false): array
    {
        $html = $this->fetchHtml($websiteUrl);

        if ($html) {
            $faqs = $this->extractFaqs($html);

            if ($faqs !== []) {
                $merchant['faqs'] = $faqs;
            }

            if (empty($merchant['meta_description'])) {
                $merchant['meta_description'] = $this->extractMetaDescription($html);
            }

            $host = parse_url($websiteUrl, PHP_URL_HOST) ?: ($merchant['domain'] ?? '');
            $logo = $this->resolveLogo($host, $websiteUrl, $html);

            if ($logo) {
                $merchant['logo'] = $logo;
            }

            $banner = $this->extractBannerImage($html, $websiteUrl);

            if ($banner && empty($merchant['banner'])) {
                $merchant['banner'] = $banner;
            }

            // Product-focus mode keeps only the affiliate landing product — do not crawl the wider catalog.
            if (! $productFocus) {
                $websiteProducts = $this->discoverProducts($websiteUrl, $html, [
                    'store_name' => $merchant['name'] ?? null,
                    'category_name' => $merchant['category_name'] ?? null,
                    'meta_description' => $merchant['meta_description'] ?? null,
                    'page_title' => $merchant['page_title'] ?? null,
                    'domain' => $host,
                ]);

                if (count($websiteProducts) >= count($merchant['products'] ?? [])) {
                    $merchant['products'] = $websiteProducts;
                }
            }
        }

        $usableProducts = $this->productExtractor->uniqueTake(
            array_values(array_filter(
                is_array($merchant['products'] ?? null) ? $merchant['products'] : [],
                fn ($product) => is_array($product)
            )),
            max(count($merchant['products'] ?? []), 1)
        );

        if (! $productFocus && $usableProducts === [] && empty($merchant['pricing_offers'])) {
            $merchant['pricing_offers'] = $this->discoverPricingOffers($websiteUrl, $html);
        }

        return $merchant;
    }

    /**
     * Latest store hero / banner image from homepage HTML (not logos/icons).
     */
    public function extractBannerImage(?string $html, string $baseUrl): ?string
    {
        if (! $html) {
            return null;
        }

        $candidates = [];

        if (preg_match_all('/<img[^>]+>/i', $html, $imgTags)) {
            foreach ($imgTags[0] as $tag) {
                $haystack = strtolower($tag);

                if (! preg_match('/(?:banner|hero|slider|carousel|swiper|masthead|promo|cover|jumbotron|slideshow)/i', $haystack)) {
                    continue;
                }

                if (! preg_match('/(?:src|data-src|data-lazy-src|data-bg)=["\']([^"\']+)["\']/i', $tag, $srcMatch)) {
                    continue;
                }

                $url = $this->absolutizeUrl($baseUrl, html_entity_decode($srcMatch[1]));

                if ($this->looksLikeBannerUrl($url)) {
                    $candidates[] = $url;
                }
            }
        }

        // CSS background-image on hero/banner containers
        if (preg_match_all(
            '/<(?:div|section|header|a)[^>]*(?:banner|hero|slider|carousel|masthead)[^>]*style=["\'][^"\']*background(?:-image)?:\s*url\((["\']?)([^"\')]+)\1\)/i',
            $html,
            $bgMatches,
            PREG_SET_ORDER
        )) {
            foreach ($bgMatches as $match) {
                $url = $this->absolutizeUrl($baseUrl, html_entity_decode(trim($match[2])));

                if ($this->looksLikeBannerUrl($url)) {
                    $candidates[] = $url;
                }
            }
        }

        foreach ([
            '/<meta[^>]+property=["\']og:image(?::secure_url)?["\'][^>]+content=["\']([^"\']+)["\']/i',
            '/<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:image(?::secure_url)?["\']/i',
            '/<meta[^>]+name=["\']twitter:image(?::src)?["\'][^>]+content=["\']([^"\']+)["\']/i',
            '/<meta[^>]+content=["\']([^"\']+)["\'][^>]+name=["\']twitter:image(?::src)?["\']/i',
        ] as $pattern) {
            if (preg_match($pattern, $html, $match)) {
                $url = $this->absolutizeUrl($baseUrl, html_entity_decode($match[1]));

                if ($this->looksLikeBannerUrl($url)) {
                    $candidates[] = $url;
                }
            }
        }

        return $candidates[0] ?? null;
    }

    private function looksLikeBannerUrl(string $url): bool
    {
        if ($url === '' || ! preg_match('#^https?://#i', $url)) {
            return false;
        }

        if (preg_match('/(logo|icon|favicon|sprite|avatar|badge|payment|pixel|1x1|spacer|blank|apple-touch)/i', $url)) {
            return false;
        }

        if (preg_match('/\.(svg)(\?|$)/i', $url)) {
            return false;
        }

        return true;
    }

    /**
     * Extract a single product from the affiliate / landing page only (no shop/catalog crawl).
     *
     * @return array<int, array{name: string, description: ?string, price: ?string, image: ?string, url: ?string, features?: list<string>}>
     */
    public function discoverFocusedProduct(string $pageUrl, ?string $html = null): array
    {
        $html ??= $this->fetchHtml($pageUrl);

        if (! $html) {
            return [];
        }

        $products = $this->productExtractor->uniqueTake(
            $this->productExtractor->extract($html, $pageUrl),
            1
        );

        if ($products === []) {
            $title = $this->extractTitle($html);
            $description = $this->extractMetaDescription($html);

            if (filled($title)) {
                $products = [[
                    'name' => Str::limit(HtmlCleaner::decodeEntities($title), 120),
                    'description' => filled($description)
                        ? Str::limit(HtmlCleaner::textFromHtml($description), 500)
                        : null,
                    'price' => null,
                    'image' => $this->productExtractor->extractPrimaryProductImage($html, $pageUrl),
                    'url' => $pageUrl,
                    'features' => [],
                ]];
            }
        } else {
            $products[0]['url'] = $products[0]['url'] ?: $pageUrl;
            $products[0] = $this->productExtractor->enrichFromPage($html, $products[0], $pageUrl);
        }

        return $products;
    }

    /**
     * When a merchant has no catalog products (SaaS / pricing-page sites), scrape /pricing
     * for Free Trial and annual "Save X%" style deals to seed coupons.
     *
     * @return list<array{code: null, title: string, description: ?string, coupon_type: string, discount_label: ?string, expires_at: null, source: string}>
     */
    public function discoverPricingOffers(string $baseUrl, ?string $homepageHtml = null): array
    {
        $baseUrl = trim($baseUrl);
        if ($baseUrl === '') {
            return [];
        }

        $homepageHtml ??= $this->fetchHtml($baseUrl);
        $candidates = $this->pricingOfferExtractor->candidateUrls($baseUrl, $homepageHtml);

        foreach ($candidates as $url) {
            $html = $this->fetchHtml($url);
            if (! $html) {
                continue;
            }

            $offers = $this->pricingOfferExtractor->extract($html, $url);
            if ($offers !== []) {
                return $offers;
            }
        }

        // Last resort: homepage itself may embed pricing copy.
        if ($homepageHtml) {
            return $this->pricingOfferExtractor->extract($homepageHtml, $baseUrl);
        }

        return [];
    }

    /**
     * Discover featured products: AI picks best SKUs + images when Gemini is enabled,
     * otherwise fall back to homepage/catalog scrape ranking.
     *
     * @param  array{store_name?: ?string, category_name?: ?string, meta_description?: ?string, page_title?: ?string, domain?: ?string}  $context
     * @return array<int, array{name: string, description: ?string, price: ?string, image: ?string, url: ?string}>
     */
    private function discoverProducts(string $baseUrl, ?string $html, array $context = []): array
    {
        $candidates = $this->collectProductCandidates($baseUrl, $html);
        $domain = preg_replace(
            '/^www\./',
            '',
            strtolower((string) ($context['domain'] ?? parse_url($baseUrl, PHP_URL_HOST) ?? ''))
        );

        if ($this->geminiWriter->isEnabled() && $candidates !== []) {
            $storeName = filled($context['store_name'] ?? null)
                ? (string) $context['store_name']
                : $this->guessStoreName($domain, $this->extractTitle($html));

            $aiProducts = $this->geminiWriter->pickBestProducts([
                'store_name' => $storeName,
                'domain' => $domain,
                'category_name' => $context['category_name'] ?? null,
                'meta_description' => $context['meta_description'] ?? $this->extractMetaDescription($html),
                'page_title' => $context['page_title'] ?? $this->extractTitle($html),
                'base_url' => $baseUrl,
                'candidates' => $candidates,
                'html_excerpt' => $this->htmlExcerptForAi($html),
            ]);

            if (is_array($aiProducts) && $aiProducts !== []) {
                return $this->productEnricher->enrich(
                    $aiProducts,
                    fn (string $url) => $this->fetchHtml($url),
                    5
                );
            }
        }

        return $this->discoverProductsByScrape($baseUrl, $html, $candidates);
    }

    /**
     * Broad candidate pool for AI ranking (and scrape fallback).
     *
     * @return array<int, array{name: string, description: ?string, price: ?string, image: ?string, url: ?string}>
     */
    private function collectProductCandidates(string $baseUrl, ?string $html): array
    {
        $products = $this->productExtractor->extract($html, $baseUrl, 24);
        $products = $this->productExtractor->uniqueTake($products, 24);

        $paths = ['/collections/all', '/collections/frontpage', '/shop', '/products', '/catalog', '/store'];

        foreach ($paths as $path) {
            if (count($products) >= 12) {
                break;
            }

            $shopUrl = rtrim($baseUrl, '/').$path;
            $shopHtml = $this->fetchHtml($shopUrl);

            if (! $shopHtml) {
                continue;
            }

            $products = $this->productExtractor->uniqueTake(
                array_merge($products, $this->productExtractor->extract($shopHtml, $shopUrl, 24)),
                24
            );
        }

        return $products;
    }

    /**
     * Legacy homepage/catalog ranking used when AI is unavailable or returns nothing.
     *
     * @param  array<int, array{name: string, description: ?string, price: ?string, image: ?string, url: ?string}>  $candidates
     * @return array<int, array{name: string, description: ?string, price: ?string, image: ?string, url: ?string}>
     */
    private function discoverProductsByScrape(string $baseUrl, ?string $html, array $candidates = []): array
    {
        $products = $candidates !== []
            ? $this->productExtractor->uniqueTake($candidates, 5)
            : $this->productExtractor->extract($html, $baseUrl, 5);

        if (count($products) < 2) {
            $paths = ['/collections/all', '/shop', '/products', '/catalog', '/store'];

            foreach ($paths as $path) {
                $shopUrl = rtrim($baseUrl, '/').$path;
                $shopHtml = $this->fetchHtml($shopUrl);

                if (! $shopHtml) {
                    continue;
                }

                $products = $this->productExtractor->uniqueTake(
                    array_merge($products, $this->productExtractor->extract($shopHtml, $shopUrl, 5)),
                    5
                );

                if (count($products) >= 2) {
                    break;
                }
            }
        }

        return $this->productEnricher->enrich(
            $products,
            fn (string $url) => $this->fetchHtml($url),
            5
        );
    }

    private function htmlExcerptForAi(?string $html): ?string
    {
        if (! $html) {
            return null;
        }

        $stripped = preg_replace('/<script\b[^>]*>.*?<\/script>/is', ' ', $html) ?? $html;
        $stripped = preg_replace('/<style\b[^>]*>.*?<\/style>/is', ' ', $stripped) ?? $stripped;
        $stripped = preg_replace('/<!--.*?-->/s', ' ', $stripped) ?? $stripped;

        return Str::limit(trim(html_entity_decode(strip_tags($stripped), ENT_QUOTES | ENT_HTML5)), 10000, '');
    }

    private function unwrapAffiliateUrl(string $url): string
    {
        $parsed = parse_url($url);

        if (empty($parsed['query'])) {
            return $url;
        }

        parse_str($parsed['query'], $params);

        foreach (['url', 'u', 'dest', 'destination', 'redirect', 'murl', 'ued', 'target', 'link', 'r'] as $key) {
            if (empty($params[$key]) || ! is_string($params[$key])) {
                continue;
            }

            $candidate = urldecode($params[$key]);

            if (filter_var($candidate, FILTER_VALIDATE_URL)) {
                return $candidate;
            }
        }

        return $url;
    }

    private function followRedirects(string $url): string
    {
        if ($url === '') {
            return '';
        }

        if (function_exists('curl_init')) {
            $curlFinal = $this->followRedirectsWithCurl($url);

            if ($curlFinal !== null) {
                return $curlFinal;
            }
        }

        try {
            $client = Http::withOptions([
                'allow_redirects' => ['max' => 10, 'track_redirects' => true],
            ])
                ->timeout(12)
                ->withoutVerifying()
                ->withHeaders([
                    'User-Agent' => config('site.bot_user_agent'),
                ]);

            $response = $client->head($url);

            if (! $response->successful() && in_array($response->status(), [405, 501], true)) {
                $response = $client->get($url);
            }

            if ($response->successful()) {
                return (string) ($response->effectiveUri() ?? $url);
            }
        } catch (\Throwable) {
            // Fall back to the original URL when the merchant blocks automated requests.
        }

        return $url;
    }

    private function followRedirectsWithCurl(string $url): ?string
    {
        $ch = curl_init($url);

        if ($ch === false) {
            return null;
        }

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_NOBODY => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_TIMEOUT => 12,
            CURLOPT_USERAGENT => (string) config('site.bot_user_agent', 'Mozilla/5.0'),
        ]);

        curl_exec($ch);

        $finalUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        $error = curl_errno($ch);

        curl_close($ch);

        if ($error !== 0 || ! is_string($finalUrl) || $finalUrl === '') {
            return null;
        }

        return $finalUrl;
    }

    private function merchantDomain(string $finalUrl, string $seedUrl, string $affiliateUrl): string
    {
        foreach ([$finalUrl, $seedUrl, $affiliateUrl] as $url) {
            $host = parse_url($url, PHP_URL_HOST);

            if (! $host) {
                continue;
            }

            $host = preg_replace('/^www\./', '', $host);

            if ($this->isAffiliateHost($host)) {
                continue;
            }

            return $host;
        }

        $host = parse_url($finalUrl, PHP_URL_HOST) ?: parse_url($affiliateUrl, PHP_URL_HOST);

        return preg_replace('/^www\./', '', (string) $host);
    }

    private function isAffiliateHost(string $host): bool
    {
        $needles = [
            'awin1.com',
            'linksynergy.com',
            'rakuten.com',
            'viglink.com',
            'skimresources.com',
            'shareasale.com',
            'impactradius.com',
            'pjtra.com',
            'clickbank.net',
            'anrdoezrs.net',
            'dpbolvw.net',
            'jdoqocy.com',
            'tkqlhce.com',
            'kqzyfj.com',
            'bit.ly',
            't.co',
        ];

        foreach ($needles as $needle) {
            if ($host === $needle || str_ends_with($host, '.'.$needle)) {
                return true;
            }
        }

        return false;
    }

    private function fetchHtml(string $url): ?string
    {
        try {
            $response = Http::timeout(12)
                ->withHeaders([
                    'User-Agent' => config('site.bot_user_agent'),
                    'Accept' => 'text/html,application/xhtml+xml',
                ])
                ->get($url);

            if ($response->successful() && str_contains(strtolower($response->header('Content-Type', '')), 'html')) {
                return $response->body();
            }
        } catch (\Throwable) {
            return null;
        }

        return null;
    }

    private function resolveLogo(string $domain, string $finalUrl, ?string $html): ?string
    {
        if ($domain === '') {
            return null;
        }

        $candidates = [];

        if ($html) {
            $candidates = array_merge($candidates, $this->extractLogoCandidatesFromHtml($html, $finalUrl));
        }

        // build logo từ favicon, thảo nào có nhiều logo nhỏ thế. 
        $scheme = parse_url($finalUrl, PHP_URL_SCHEME) ?: 'https';
        $candidates[] = "{$scheme}://{$domain}/apple-touch-icon.png";
        $candidates[] = "{$scheme}://{$domain}/favicon.ico";
        $candidates[] = "https://www.google.com/s2/favicons?domain={$domain}&sz=128";
        $candidates[] = "https://icons.duckduckgo.com/ip3/{$domain}.ico";

        $candidates = array_values(array_unique(array_filter($candidates)));

        $valid = [];

        foreach ($candidates as $candidate) {
            if ($this->isValidLogoUrl($candidate)) {
                $valid[] = $candidate;
            }
        }

        return $this->pickPreferredLogo($valid, $domain);
    }

    /**
     * @param  list<string>  $valid
     */
    private function pickPreferredLogo(array $valid, string $domain): ?string
    {
        foreach ($valid as $url) {
            if (! $this->isSvgUrl($url)) {
                return $url;
            }
        }

        if ($valid !== []) {
            return $valid[0];
        }

        $fallback = "https://www.google.com/s2/favicons?domain={$domain}&sz=128";

        return $this->isValidLogoUrl($fallback) ? $fallback : null;
    }

    private function isSvgUrl(string $url): bool
    {
        return (bool) preg_match('/\.svg(\?|$)/i', $url);
    }

    /**
     * @return list<string>
     */
    private function extractLogoCandidatesFromHtml(string $html, string $baseUrl): array
    {
        $candidates = [];

        if (preg_match('/<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']/i', $html, $match)
            || preg_match('/<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\']/i', $html, $match)) {
            $candidates[] = $this->absolutizeUrl($baseUrl, html_entity_decode($match[1]));
        }

        if (preg_match_all('/"@type"\s*:\s*"Organization"[^}]*"logo"\s*:\s*"([^"]+)"/is', $html, $matches)) {
            foreach ($matches[1] as $logo) {
                $candidates[] = $this->absolutizeUrl($baseUrl, html_entity_decode($logo));
            }
        }

        if (preg_match_all('/<link[^>]+rel=["\'](?:apple-touch-icon(?:-precomposed)?|icon|shortcut icon)["\'][^>]*>/i', $html, $linkTags)) {
            $icons = [];

            foreach ($linkTags[0] as $tag) {
                if (! preg_match('/href=["\']([^"\']+)["\']/i', $tag, $hrefMatch)) {
                    continue;
                }

                $size = 0;
                if (preg_match('/sizes=["\'](\d+)x\d+["\']/i', $tag, $sizeMatch)) {
                    $size = (int) $sizeMatch[1];
                }

                $icons[] = [
                    'size' => $size,
                    'url' => $this->absolutizeUrl($baseUrl, html_entity_decode($hrefMatch[1])),
                ];
            }

            usort($icons, fn (array $a, array $b) => $b['size'] <=> $a['size']);

            foreach ($icons as $icon) {
                $candidates[] = $icon['url'];
            }
        }

        if (preg_match('/<meta[^>]+property=["\']og:logo["\'][^>]+content=["\']([^"\']+)["\']/i', $html, $match)
            || preg_match('/<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:logo["\']/i', $html, $match)) {
            $candidates[] = $this->absolutizeUrl($baseUrl, html_entity_decode($match[1]));
        }

        return $candidates;
    }

    private function absolutizeUrl(string $baseUrl, string $path): string
    {
        $path = trim($path);

        if ($path === '') {
            return $baseUrl;
        }

        if (preg_match('/^https?:\/\//i', $path)) {
            return $path;
        }

        $parts = parse_url($baseUrl);
        $scheme = $parts['scheme'] ?? 'https';
        $host = $parts['host'] ?? '';

        if (str_starts_with($path, '//')) {
            return $scheme.':'.$path;
        }

        if (str_starts_with($path, '/')) {
            return "{$scheme}://{$host}{$path}";
        }

        $dir = rtrim(dirname($parts['path'] ?? '/'), '/');

        return "{$scheme}://{$host}{$dir}/{$path}";
    }

    private function isValidLogoUrl(string $url): bool
    {
        try {
            $response = Http::timeout(8)
                ->withHeaders([
                    'User-Agent' => config('site.bot_user_agent'),
                    'Accept' => 'image/*,*/*',
                ])
                ->get($url);

            if (! $response->successful()) {
                return false;
            }

            $type = strtolower((string) $response->header('Content-Type', ''));

            if ($type !== '' && ! str_starts_with($type, 'image/') && ! str_contains($type, 'icon')) {
                return false;
            }

            return strlen($response->body()) > 120;
        } catch (\Throwable) {
            return false;
        }
    }

    private function extractTitle(?string $html): ?string
    {
        if (! $html || ! preg_match('/<title[^>]*>(.*?)<\/title>/is', $html, $matches)) {
            return null;
        }

        $title = html_entity_decode(trim(strip_tags($matches[1])), ENT_QUOTES | ENT_HTML5, 'UTF-8');

        return $title !== '' ? Str::limit($title, 180) : null;
    }

    private function extractMetaDescription(?string $html): ?string
    {
        if (! $html) {
            return null;
        }

        if (preg_match('/<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']+)["\']/i', $html, $matches)
            || preg_match('/<meta[^>]+content=["\']([^"\']+)["\'][^>]+name=["\']description["\']/i', $html, $matches)) {
            $description = html_entity_decode(trim($matches[1]), ENT_QUOTES | ENT_HTML5, 'UTF-8');

            return $description !== '' ? Str::limit($description, 500) : null;
        }

        return null;
    }

    /**
     * @return array<int, array{question: string, answer: string}>
     */
    private function extractFaqs(?string $html): array
    {
        if (! $html) {
            return [];
        }

        $faqs = [];

        if (preg_match_all('/<script[^>]+type=["\']application\/ld\+json["\'][^>]*>(.*?)<\/script>/is', $html, $blocks)) {
            foreach ($blocks[1] as $json) {
                $decoded = json_decode(html_entity_decode(trim($json)), true);

                if (is_array($decoded)) {
                    $faqs = array_merge($faqs, $this->faqsFromSchema($decoded));
                }
            }
        }

        return array_values(array_slice($faqs, 0, 10));
    }

    /**
     * @return array<int, array{question: string, answer: string}>
     */
    private function faqsFromSchema(mixed $data): array
    {
        if (! is_array($data)) {
            return [];
        }

        if (isset($data['@graph']) && is_array($data['@graph'])) {
            $merged = [];

            foreach ($data['@graph'] as $node) {
                $merged = array_merge($merged, $this->faqsFromSchema($node));
            }

            return $merged;
        }

        $type = $data['@type'] ?? null;
        $types = is_array($type) ? $type : [$type];

        if (in_array('FAQPage', $types, true) && ! empty($data['mainEntity']) && is_array($data['mainEntity'])) {
            $faqs = [];

            foreach ($data['mainEntity'] as $entity) {
                if (! is_array($entity)) {
                    continue;
                }

                $question = $entity['name'] ?? null;
                $answer = is_array($entity['acceptedAnswer'] ?? null)
                    ? ($entity['acceptedAnswer']['text'] ?? null)
                    : null;

                if ($question && $answer) {
                    $faqs[] = [
                        'question' => Str::limit(strip_tags((string) $question), 220),
                        'answer' => Str::limit(strip_tags((string) $answer), 600),
                    ];
                }
            }

            return $faqs;
        }

        if (in_array('Question', $types, true)) {
            $question = $data['name'] ?? null;
            $answer = is_array($data['acceptedAnswer'] ?? null)
                ? ($data['acceptedAnswer']['text'] ?? null)
                : null;

            if ($question && $answer) {
                return [[
                    'question' => Str::limit(strip_tags((string) $question), 220),
                    'answer' => Str::limit(strip_tags((string) $answer), 600),
                ]];
            }
        }

        return [];
    }

    private function guessStoreName(string $domain, ?string $pageTitle): string
    {
        if ($domain !== '') {
            $parts = explode('.', $domain);
            $label = $parts[count($parts) - 2] ?? $parts[0] ?? $domain;

            if (! in_array(strtolower($label), ['shop', 'store', 'www', 'm', 'app'], true)) {
                return Str::title(str_replace(['-', '_'], ' ', $label));
            }
        }

        if ($pageTitle) {
            $clean = preg_replace('/\s*[|\-–—:].*$/u', '', $pageTitle);

            return Str::limit(trim((string) $clean), 80) ?: 'New Store';
        }

        return $domain !== '' ? Str::title(str_replace(['-', '_'], ' ', explode('.', $domain)[0])) : 'New Store';
    }

    private function guessCategory(string $domain, ?string $pageTitle, ?string $metaDescription, string $finalUrl): ?Category
    {
        $haystack = Str::lower(implode(' ', array_filter([$domain, $pageTitle, $metaDescription, $finalUrl])));

        $keywords = [
            'Fashion' => ['fashion', 'clothing', 'apparel', 'shoes', 'dress', 'wear', 'nike', 'adidas', 'zara'],
            'Electronics' => ['electronics', 'tech', 'computer', 'laptop', 'phone', 'gadget', 'bestbuy', 'apple'],
            'Beauty' => ['beauty', 'cosmetic', 'skincare', 'makeup', 'fragrance', 'sephora', 'ulta'],
            'Food & Dining' => ['food', 'grocery', 'restaurant', 'dining', 'meal', 'pizza', 'coffee', 'doordash', 'ubereats'],
            'Travel' => ['travel', 'hotel', 'flight', 'airline', 'booking', 'vacation', 'expedia', 'airbnb'],
            'Health' => ['health', 'pharmacy', 'vitamin', 'supplement', 'wellness', 'medical', 'cvs', 'walgreens'],
        ];

        $categories = Category::active()->orderBy('name')->get()->keyBy('name');

        foreach ($keywords as $categoryName => $terms) {
            foreach ($terms as $term) {
                if (str_contains($haystack, $term) && $categories->has($categoryName)) {
                    return $categories->get($categoryName);
                }
            }
        }

        return null;
    }

    public function categories(): Collection
    {
        return Category::active()->orderBy('name')->get();
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Coupon;
use App\Models\Post;
use App\Models\Store;
use Illuminate\Http\Request;
use Illuminate\View\View;

class HomeController extends Controller
{
    public function index(): View
    {
        $categories = Category::active()->orderBy('sort_order')->take(36)->get();
        $stores = Store::homeFeaturedQuery(12)->get();

        $latestPosts = Post::homeFeaturedQuery(8)->get();

        $stats = [
            'coupons' => Coupon::valid()->count(),
            'stores' => Store::active()->count(),
            'categories' => Category::active()->count(),
        ];

        $hotCoupons = Coupon::with(['store.category'])
            ->valid()
            ->orderByDesc('is_featured')
            ->latest()
            ->take(9)
            ->get();

        return view('home', compact(
            'categories',
            'stores',
            'latestPosts',
            'stats',
            'hotCoupons'
        ));
    }

    public function search(Request $request): View
    {
        $q = trim($request->get('q', ''));

        $coupons = Coupon::with(['store.category'])
            ->valid()
            ->when($q, function ($query) use ($q) {
                $query->where(function ($sub) use ($q) {
                    $sub->where('title', 'like', "%{$q}%")
                        ->orWhere('code', 'like', "%{$q}%")
                        ->orWhere('description', 'like', "%{$q}%")
                        ->orWhereHas('store', fn ($s) => $s->where('name', 'like', "%{$q}%"));
                });
            })
            ->latest()
            ->paginate(16)
            ->withQueryString();

        $posts = $q
            ? Post::published()
                ->with('user')
                ->where(function ($query) use ($q) {
                    $query->where('title', 'like', "%{$q}%")
                        ->orWhere('excerpt', 'like', "%{$q}%")
                        ->orWhere('content', 'like', "%{$q}%");
                })
                ->orderByDesc('published_at')
                ->take(12)
                ->get()
            : collect();

        return view('search', compact('coupons', 'posts', 'q'));
    }
}

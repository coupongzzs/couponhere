<?php

namespace App\Http\Controllers\Member;

use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Support\PublicImage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class PostController extends Controller
{
    public function index(Request $request): View
    {
        $this->authorize('viewAny', Post::class);

        $q = trim((string) $request->query('q', ''));

        $query = Post::ownedBy(auth()->id())
            ->orderByDesc('created_at');

        if ($q !== '') {
            $query->where('title', 'like', '%'.$q.'%');
        }

        $posts = $query->paginate(20)->withQueryString();

        return view('member.posts.index', compact('posts', 'q'));
    }

    public function create(): View
    {
        $this->authorize('create', Post::class);

        return view('member.posts.form', ['post' => new Post()]);
    }

    public function store(Request $request): RedirectResponse
    {
        $this->authorize('create', Post::class);

        $data = $this->validated($request);
        $data['slug'] = $this->uniqueSlug($data['title']);
        $data['featured_image'] = $this->resolveFeaturedImage($request, $data['featured_image'] ?? null);
        $data['user_id'] = auth()->id();
        $data['author_name'] = auth()->user()->name;

        Post::create($data);

        return redirect()->route('member.posts.index')->with('success', 'Blog post created successfully.');
    }

    public function edit(Post $post): View
    {
        $this->authorize('update', $post);

        return view('member.posts.form', compact('post'));
    }

    public function update(Request $request, Post $post): RedirectResponse
    {
        $this->authorize('update', $post);

        $data = $this->validated($request);
        $data['featured_image'] = $this->resolveFeaturedImage(
            $request,
            $request->input('featured_image'),
            $post->featured_image
        );
        $data['author_name'] = auth()->user()->name;
        $post->update($data);

        return redirect()->route('member.posts.index')->with('success', 'Blog post updated successfully.');
    }

    public function destroy(Post $post): RedirectResponse
    {
        $this->authorize('delete', $post);

        PublicImage::delete($post->featured_image);
        $post->delete();

        return redirect()->route('member.posts.index')->with('success', 'Blog post deleted successfully.');
    }

    private function validated(Request $request): array
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'excerpt' => ['nullable', 'string', 'max:500'],
            'content' => ['required', 'string'],
            'meta_title' => ['nullable', 'string', 'max:70'],
            'meta_description' => ['nullable', 'string', 'max:320'],
            'featured_image' => ['nullable', 'string', 'max:500'],
            'featured_image_file' => ['nullable', 'image', 'max:5120'],
            'published_at' => ['nullable', 'date'],
            'is_published' => ['boolean'],
        ]);

        $data['is_published'] = $request->boolean('is_published');

        if ($data['is_published'] && empty($data['published_at'])) {
            $data['published_at'] = now();
        }

        unset($data['featured_image_file']);

        return $data;
    }

    private function resolveFeaturedImage(Request $request, ?string $imageUrl, ?string $existing = null): ?string
    {
        if ($request->hasFile('featured_image_file')) {
            PublicImage::delete($existing);

            return PublicImage::store($request->file('featured_image_file'), 'posts');
        }

        if (filled($imageUrl)) {
            if ($existing && PublicImage::isStored($existing) && $imageUrl !== $existing) {
                PublicImage::delete($existing);
            }

            $userId = auth()->id();

            return PublicImage::storeBlogFeaturedFromRemote($imageUrl, $userId)
                ?? PublicImage::ingestRemote($imageUrl, "posts/{$userId}");
        }

        return $existing;
    }

    private function uniqueSlug(string $title, ?int $ignoreId = null): string
    {
        $slug = Str::slug($title);
        $original = $slug;
        $i = 1;

        while (Post::where('slug', $slug)->when($ignoreId, fn ($q) => $q->where('id', '!=', $ignoreId))->exists()) {
            $slug = $original . '-' . $i++;
        }

        return $slug;
    }
}

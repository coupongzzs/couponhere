<?php

namespace App\Http\Controllers\Member;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Coupon;
use App\Models\Post;
use App\Models\Store;
use App\Support\AffiliateImportContentBuilder;
use App\Support\AffiliateLinkResolver;
use App\Support\CouponSpeakClient;
use App\Support\HtmlCleaner;
use App\Support\MerchantProductExtractor;
use App\Support\PublicImage;
use App\Support\SiteImportSettings;
use App\Support\StoreSlug;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\View\View;

class ImportAffiliateController extends Controller
{
    public function create(AffiliateLinkResolver $resolver): View
    {
        $this->authorize('create', Store::class);

        return view('member.import-affiliate.form', [
            'categories' => $resolver->categories(),
            'allowReimportExistingStores' => SiteImportSettings::allowReimportExistingStores(),
        ]);
    }

    public function preview(
        Request $request,
        AffiliateLinkResolver $resolver,
        CouponSpeakClient $couponSpeak,
        AffiliateImportContentBuilder $contentBuilder,
        MerchantProductExtractor $productExtractor,
    ): JsonResponse {
        $this->authorize('create', Store::class);

        $data = $request->validate([
            'affiliate_url' => ['required', 'url', 'max:500'],
            'website' => ['nullable', 'url', 'max:500'],
            'product_focus' => ['nullable', 'boolean'],
        ]);

        $affiliateUrl = $data['affiliate_url'];
        $productFocus = $request->boolean('product_focus');
        $finalUrl = $resolver->finalUrl($affiliateUrl);
        $storeQuery = $couponSpeak->hostFromUrl($finalUrl)
            ?? $couponSpeak->hostFromUrl($affiliateUrl)
            ?? '';
        $bundle = $couponSpeak->fetchStoreBundle($storeQuery);
        $detectSource = 'local';

        if ($couponSpeak->profileIsUsable($bundle['store_profile']) && ! $productFocus) {
            $merchant = $couponSpeak->merchantFromProfile($bundle['store_profile'], $affiliateUrl);
            $detectSource = 'scan_cache';
        } else {
            $merchant = $resolver->resolve($affiliateUrl, $productFocus);
        }

        if (filled($data['website'] ?? null)) {
            $merchant = $resolver->enrichFromWebsite($merchant, trim($data['website']), $productFocus);
        }

        if ($productFocus) {
            $focusedProducts = $resolver->discoverFocusedProduct($finalUrl);
            $merchant['products'] = $focusedProducts;
            $merchant['product_focus'] = true;

            if ($focusedProducts !== [] && filled($focusedProducts[0]['name'] ?? null)) {
                $merchant['name'] = Str::limit((string) $focusedProducts[0]['name'], 100, '');
            }
        } else {
            $merchant['product_focus'] = false;
        }

        if (empty($merchant['banner'])) {
            $bannerSource = filled($data['website'] ?? null)
                ? trim((string) $data['website'])
                : (filled($merchant['domain'] ?? null) ? 'https://'.$merchant['domain'] : $finalUrl);
            $merchant = $resolver->enrichFromWebsite($merchant, $bannerSource, $productFocus);
        }

        if ($bundle['scan_logo'] !== null) {
            $merchant['logo'] = $bundle['scan_logo'];
        } elseif (
            ! filled($merchant['logo'] ?? null)
            && $couponSpeak->profileIsUsable($bundle['store_profile'])
        ) {
            $merchant['logo'] = $resolver->resolve($affiliateUrl)['logo'] ?? null;
        }

        $merchant['category_id'] = $this->resolveCategoryId($merchant);
        $merchant['affiliate_url'] = $affiliateUrl;
        $merchant['final_url'] = $merchant['final_url'] ?? $finalUrl;

        if (! filled($merchant['domain'] ?? null)) {
            $merchant['domain'] = $couponSpeak->hostFromUrl($finalUrl)
                ?? $couponSpeak->hostFromUrl($affiliateUrl);
        }

        $storeQuery = $merchant['domain'] ?? $storeQuery;

        $products = is_array($merchant['products'] ?? null) ? $merchant['products'] : [];
        $merchant['products'] = $productExtractor->uniqueTake(
            array_values(array_filter($products, fn ($product) => is_array($product))),
            max(count($products), 1)
        );

        if (
            ! $productFocus
            && $merchant['products'] === []
            && empty($merchant['pricing_offers'])
        ) {
            $pricingBase = filled($data['website'] ?? null)
                ? trim((string) $data['website'])
                : (filled($merchant['final_url'] ?? null)
                    ? (string) $merchant['final_url']
                    : (filled($merchant['domain'] ?? null) ? 'https://'.$merchant['domain'] : $finalUrl));

            $merchant['pricing_offers'] = $resolver->discoverPricingOffers($pricingBase);
        }

        $pricingOffers = is_array($merchant['pricing_offers'] ?? null) ? $merchant['pricing_offers'] : [];
        $suggestedOffers = $this->mergePricingOffers(
            $bundle['offers'],
            $pricingOffers,
            $merchant['products'] === []
        );

        $offers = $this->normalizeOffers(
            collect($suggestedOffers)->map(fn (array $offer) => [
                'code' => $offer['code'] ?? null,
                'title' => $offer['title'] ?? 'Featured offer',
                'description' => $offer['description'] ?? null,
                'expires_at' => $offer['expires_at'] ?? null,
            ])->whenEmpty(fn ($collection) => $collection->push([
                'code' => null,
                'title' => ($merchant['name'] ?? 'Store') . ' promo',
                'description' => $merchant['meta_description'] ?? null,
            ]))->all()
        );

        $previewStore = new Store([
            'name' => $merchant['name'] ?? 'New Store',
            'slug' => StoreSlug::make($merchant['name'] ?? 'new-store'),
            'category_id' => $merchant['category_id'] ?? null,
        ]);

        if (filled($merchant['category_id'] ?? null)) {
            $previewStore->setRelation('category', Category::find($merchant['category_id']));
        }

        $generatedBlog = null;

        try {
            $generatedBlog = $contentBuilder->generateBlogPreview($previewStore, $offers, $merchant);
        } catch (\Throwable $e) {
            report($e);
        }

        $existingStore = Store::findForMerchantImport(
            auth()->id(),
            $data['website'] ?? null,
            $affiliateUrl,
            $merchant['domain'] ?? null,
        );
        $existingPost = $existingStore
            ? Post::query()->where('store_id', $existingStore->id)->orderByDesc('updated_at')->first()
            : null;

        $allowReimport = SiteImportSettings::allowReimportExistingStores();
        $importBlocked = $existingStore !== null && ! $allowReimport;

        return response()->json([
            'ok' => true,
            'merchant' => $merchant,
            'store_query' => $storeQuery,
            'detect_source' => $detectSource,
            'product_focus' => $productFocus,
            'suggested_offers' => $suggestedOffers,
            'generated_blog' => $generatedBlog,
            'products_found' => count($merchant['products']),
            'pricing_offers_found' => count($pricingOffers),
            'allow_reimport_existing_stores' => $allowReimport,
            'import_blocked' => $importBlocked,
            'existing_import' => $existingStore ? [
                'store_id' => $existingStore->id,
                'store_name' => $existingStore->name,
                'store_slug' => $existingStore->slug,
                'post_id' => $existingPost?->id,
                'post_title' => $existingPost?->title,
                'post_slug' => $existingPost?->slug,
            ] : null,
        ]);
    }

    public function store(
        Request $request,
        AffiliateLinkResolver $resolver,
        AffiliateImportContentBuilder $contentBuilder,
        CouponSpeakClient $couponSpeak,
    ): RedirectResponse {
        $this->authorize('create', Store::class);
        $this->authorize('create', Coupon::class);
        $this->authorize('create', Post::class);

        $data = $request->validate([
            'affiliate_url' => ['required', 'url', 'max:500'],
            'store_name' => ['required', 'string', 'max:255'],
            'website' => ['nullable', 'url', 'max:500'],
            'logo_url' => ['nullable', 'url', 'max:500'],
            'category_id' => ['nullable', 'exists:categories,id'],
            'product_focus' => ['nullable', 'boolean'],
            'offers' => ['required', 'array', 'min:1'],
            'offers.*.code' => ['nullable', 'string', 'max:100'],
            'offers.*.title' => ['required', 'string', 'max:255'],
            'offers.*.description' => ['nullable', 'string'],
            'offers.*.expires_at' => ['nullable', 'date'],
            'generated_blog' => ['nullable', 'string', 'max:100000'],
        ]);

        $productFocus = $request->boolean('product_focus');
        $merchant = $resolver->resolve($data['affiliate_url'], $productFocus);

        if (filled($data['website'] ?? null)) {
            $merchant = $resolver->enrichFromWebsite($merchant, trim($data['website']), $productFocus);
        }

        if ($productFocus) {
            $finalUrl = $merchant['final_url'] ?? $resolver->finalUrl($data['affiliate_url']);
            $focusedProducts = $resolver->discoverFocusedProduct($finalUrl);
            $merchant['products'] = $focusedProducts;
            $merchant['product_focus'] = true;
        } else {
            $merchant['product_focus'] = false;
        }

        $publish = true;
        $storeName = HtmlCleaner::normalizePlainText($data['store_name']);
        $logoUrl = filled($data['logo_url'] ?? null) ? trim($data['logo_url']) : ($merchant['logo'] ?? null);
        $offers = $this->normalizeOffers($data['offers']);
        $preGeneratedBlog = $this->parseGeneratedBlog($data['generated_blog'] ?? null);
        $userId = auth()->id();
        $domain = $merchant['domain'] ?? null;
        if (! $domain && filled($data['website'] ?? null)) {
            $domain = parse_url(trim($data['website']), PHP_URL_HOST);
            $domain = $domain ? preg_replace('/^www\./', '', $domain) : null;
        }
        $storedLogo = PublicImage::ingestStoreLogo($logoUrl, $domain, $userId);

        // Prefer the locally hosted logo URL inside generated article HTML.
        if ($storedLogo && ($localLogoUrl = PublicImage::url($storedLogo))) {
            $merchant['logo'] = $localLogoUrl;
        }

        $featuredCandidate = filled($merchant['banner'] ?? null)
            ? (string) $merchant['banner']
            : (filled($merchant['products'][0]['image'] ?? null) ? (string) $merchant['products'][0]['image'] : null);

        $storedFeatured = null;

        if ($featuredCandidate) {
            $storedFeatured = PublicImage::ingestRemote($featuredCandidate, "blogs/{$userId}/featured");
        }

        if (! $storedFeatured) {
            $storedFeatured = PublicImage::isScanAssetUrl($logoUrl)
                ? $storedLogo
                : (PublicImage::storeBlogFeaturedFromRemote($logoUrl, $userId) ?? $storedLogo);
        }

        $existingStore = Store::findForMerchantImport(
            $userId,
            filled($data['website'] ?? null) ? trim($data['website']) : null,
            $data['affiliate_url'],
            $domain,
        );

        if ($existingStore !== null && ! SiteImportSettings::allowReimportExistingStores()) {
            return redirect()
                ->route('member.import-affiliate.create')
                ->withInput()
                ->with('error', 'This store already exists. Re-importing existing stores is disabled in site settings.');
        }

        $result = DB::transaction(function () use (
            $data,
            $merchant,
            $publish,
            $storeName,
            $storedLogo,
            $storedFeatured,
            $offers,
            $contentBuilder,
            $logoUrl,
            $preGeneratedBlog,
            $existingStore,
            $userId,
        ) {
            $isUpdate = $existingStore !== null;
            $storePayload = [
                'name' => $storeName,
                'logo' => $storedLogo,
                'website' => filled($data['website'] ?? null) ? trim($data['website']) : null,
                'affiliate_url' => $data['affiliate_url'],
                'description' => HtmlCleaner::clean(
                    PublicImage::localizeHtmlImages(
                        $contentBuilder->storeDescription(
                            $storeName,
                            $isUpdate ? $existingStore->slug : StoreSlug::make($storeName),
                            $data['affiliate_url'],
                            optional(Category::find($data['category_id']))?->name,
                            $offers,
                            $merchant,
                        ),
                        "stores/{$userId}/content"
                    )
                ),
                'category_id' => filled($data['category_id'] ?? null) ? $data['category_id'] : null,
                'is_active' => $publish,
            ];

            if ($isUpdate) {
                $existingStore->update($storePayload);
                $store = $existingStore->fresh();
                Coupon::query()
                    ->where('store_id', $store->id)
                    ->where('user_id', $userId)
                    ->delete();
            } else {
                $store = Store::create([
                    'user_id' => $userId,
                    'slug' => StoreSlug::make($storeName),
                    ...$storePayload,
                ]);
            }

            if (! $storedLogo) {
                $store->ensureLogoStored($logoUrl);
            }

            $createdCoupons = [];
            $offerCount = count($offers);

            foreach ($offers as $index => $offer) {
                $sortOrder = max(1, $offerCount - $index);

                $createdCoupons[] = Coupon::create([
                    'user_id' => $userId,
                    'store_id' => $store->id,
                    'title' => $offer['title'],
                    'slug' => $this->uniqueCouponSlug($offer['title']),
                    'description' => HtmlCleaner::clean($offer['description']),
                    'code' => $offer['code'],
                    'type' => $offer['type'],
                    'expires_at' => $offer['expires_at'],
                    'is_active' => $publish,
                    'store_sort_order' => $sortOrder,
                    'coupons_sort_order' => $sortOrder,
                ]);
            }

            $blog = $contentBuilder->blogPost($store->load('category'), $offers, $merchant, $preGeneratedBlog);
            $blog['content'] = HtmlCleaner::clean(
                PublicImage::localizeHtmlImages($blog['content'] ?? '', "blogs/{$userId}/content")
            ) ?? ($blog['content'] ?? '');
            $postPayload = [
                'user_id' => $userId,
                'store_id' => $store->id,
                'title' => $blog['title'],
                'excerpt' => $blog['excerpt'],
                'content' => $blog['content'],
                'meta_title' => $blog['meta_title'],
                'meta_description' => $blog['meta_description'],
                'featured_image' => $storedFeatured,
                'author_name' => auth()->user()->name,
                'published_at' => $publish ? now() : null,
                'is_published' => $publish,
            ];

            $existingPost = Post::query()
                ->where('store_id', $store->id)
                ->orderByDesc('updated_at')
                ->first();

            if ($existingPost) {
                Post::query()
                    ->where('store_id', $store->id)
                    ->where('id', '!=', $existingPost->id)
                    ->delete();
                $existingPost->update($postPayload);
                $post = $existingPost->fresh();
            } else {
                $post = Post::create([
                    ...$postPayload,
                    'slug' => Post::stableReviewPostSlug($store),
                ]);
            }

            return compact('store', 'createdCoupons', 'post', 'isUpdate');
        });

        $syncResult = $couponSpeak->syncImportedStore(
            $result['store'],
            $result['createdCoupons'],
            $data['affiliate_url'],
            [
                'website' => filled($data['website'] ?? null) ? trim($data['website']) : $result['store']->website,
                'logo' => $logoUrl,
                'meta_description' => $merchant['meta_description'] ?? null,
                'category_name' => optional(Category::find($data['category_id'] ?? null))?->name
                    ?? ($merchant['category_name'] ?? null),
                'page_title' => $merchant['page_title'] ?? null,
                'final_url' => $merchant['final_url'] ?? null,
                'faqs' => $merchant['faqs'] ?? [],
                'products' => $merchant['products'] ?? [],
            ],
        );

        $status = 'published';
        $couponCount = count($result['createdCoupons']);
        $isAdmin = auth()->user()->isAdmin();
        $postAction = $result['isUpdate'] ? 'updated' : 'created';
        $successMessage = "Import complete ({$status}): {$storeName} — {$couponCount} offer(s) and 1 blog post {$postAction}.";

        if ($syncResult !== null) {
            $syncedCount = (int) data_get($syncResult, 'stats.active_coupons', $couponCount);
            $successMessage .= " Synced {$syncedCount} offer(s) to Coupons Peak.";
        }

        return redirect()
            ->route('member.import-affiliate.create')
            ->with('success', $successMessage)
            ->with('import_links', [
                'store_public' => route('stores.show', $result['store']->slug),
                'store' => $isAdmin
                    ? route('admin.stores.edit', $result['store'])
                    : route('member.stores.edit', $result['store']),
                'post' => $isAdmin
                    ? route('admin.posts.edit', $result['post'])
                    : route('member.posts.edit', $result['post']),
                'coupons' => $isAdmin
                    ? route('admin.coupons.index')
                    : route('member.coupons.index'),
            ]);
    }

    /**
     * @param  array<string, mixed>  $merchant
     */
    private function resolveCategoryId(array $merchant): ?int
    {
        if (filled($merchant['category_id'] ?? null)) {
            return (int) $merchant['category_id'];
        }

        $name = trim((string) ($merchant['category_name'] ?? ''));

        if ($name === '') {
            return null;
        }

        return Category::query()->where('name', $name)->value('id');
    }

    /**
     * @param  array<int, array{code?: ?string, title: string, description?: ?string, expires_at?: ?string}>  $offers
     * @return array<int, array{code: ?string, title: string, description: ?string, type: string, expires_at: ?string}>
     */
    private function normalizeOffers(array $offers): array
    {
        return collect($offers)
            ->map(function (array $offer) {
                $code = filled($offer['code'] ?? null) ? trim((string) $offer['code']) : null;

                return [
                    'code' => $code,
                    'title' => HtmlCleaner::normalizePlainText($offer['title']),
                    'description' => filled($offer['description'] ?? null)
                        ? HtmlCleaner::normalizePlainText((string) $offer['description'])
                        : null,
                    'type' => filled($code) ? 'coupon' : 'discount',
                    'expires_at' => filled($offer['expires_at'] ?? null) ? $offer['expires_at'] : null,
                ];
            })
            ->values()
            ->all();
    }

    /**
     * Prefer pricing-page Free Trial / Save X% deals when the merchant has no catalog products.
     *
     * @param  list<array<string, mixed>>  $existing
     * @param  list<array<string, mixed>>  $pricingOffers
     * @return list<array<string, mixed>>
     */
    private function mergePricingOffers(array $existing, array $pricingOffers, bool $noProducts): array
    {
        if ($pricingOffers === [] || ! $noProducts) {
            return $existing;
        }

        if ($existing === []) {
            return array_values($pricingOffers);
        }

        $merged = [];
        $seenTitles = [];

        foreach (array_merge($pricingOffers, $existing) as $offer) {
            if (! is_array($offer)) {
                continue;
            }

            $title = Str::lower(trim((string) ($offer['title'] ?? '')));
            if ($title === '' || isset($seenTitles[$title])) {
                continue;
            }

            $seenTitles[$title] = true;
            $merged[] = $offer;
        }

        return $merged;
    }

    private function uniqueCouponSlug(string $title): string
    {
        $slug = Str::slug($title);
        $original = $slug;
        $i = 1;

        while (Coupon::where('slug', $slug)->exists()) {
            $slug = $original . '-' . $i++;
        }

        return $slug;
    }

    private function uniquePostSlug(string $title): string
    {
        $slug = Str::slug($title);
        $original = $slug;
        $i = 1;

        while (Post::where('slug', $slug)->exists()) {
            $slug = $original . '-' . $i++;
        }

        return $slug;
    }

    /**
     * @return array{title: string, excerpt: string, meta_title: string, meta_description: string, content: string}|null
     */
    private function parseGeneratedBlog(?string $json): ?array
    {
        if (! filled($json)) {
            return null;
        }

        $decoded = json_decode($json, true);

        if (! is_array($decoded)) {
            return null;
        }

        foreach (['title', 'excerpt', 'content'] as $required) {
            if (! filled($decoded[$required] ?? null)) {
                return null;
            }
        }

        return [
            'title' => trim((string) $decoded['title']),
            'excerpt' => trim((string) $decoded['excerpt']),
            'meta_title' => trim((string) ($decoded['meta_title'] ?? $decoded['title'])),
            'meta_description' => trim((string) ($decoded['meta_description'] ?? $decoded['excerpt'])),
            'content' => trim((string) $decoded['content']),
        ];
    }
}

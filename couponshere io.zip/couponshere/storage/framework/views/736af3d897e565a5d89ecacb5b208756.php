<article class="sp-coupon-card coupon-card <?php echo e($coupon->is_featured ? 'featured sp-coupon-card--featured' : ''); ?><?php echo e(($linkCardToDetail ?? false) ? ' coupon-card--clickable' : ''); ?>" <?php if($coupon->code): ?> data-code-reveal <?php endif; ?>>
    <?php if($linkCardToDetail ?? false): ?>
        <a href="<?php echo e(route('coupons.show', $coupon->slug)); ?>" class="coupon-card-overlay" aria-label="View <?php echo e($coupon->title); ?>"></a>
    <?php endif; ?>
    <div class="sp-coupon-card-head">
        <?php echo $__env->make('partials.store-logo', ['store' => $coupon->store, 'size' => 'md', 'showVerified' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <span class="sp-verified-badge">Verified</span>
    </div>
    <?php if($coupon->code): ?>
        <div class="sp-coupon-code-preview">
            <?php echo $__env->make('partials.coupon-code-masked', ['coupon' => $coupon], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php endif; ?>
    <div class="sp-coupon-discount"><?php echo e($coupon->discountLabelWithStore()); ?></div>
    <h3 class="coupon-title sp-coupon-title">
        <?php if($linkCardToDetail ?? false): ?>
            <?php echo e($coupon->title); ?>

        <?php else: ?>
            <a href="<?php echo e(route('coupons.show', $coupon->slug)); ?>"><?php echo e($coupon->title); ?></a>
        <?php endif; ?>
    </h3>
    <?php if($showDescription ?? false): ?>
        <p class="coupon-description sp-coupon-description">
            <?php if(filled($coupon->description)): ?>
                <?php echo e(\Illuminate\Support\Str::limit(strip_tags($coupon->description), 120)); ?>

            <?php endif; ?>
        </p>
    <?php endif; ?>
    <?php if($coupon->expires_at): ?>
        <p class="coupon-expire sp-coupon-expire"><?php echo e($coupon->expiresLabel()); ?></p>
    <?php endif; ?>
    <div class="coupon-actions sp-coupon-actions">
        <?php if($coupon->code): ?>
            <button type="button"
                class="sp-code-copy sp-code-copy--solo"
                data-reveal-url="<?php echo e(route('coupons.reveal', $coupon->slug)); ?>"
                data-affiliate-url="<?php echo e($coupon->affiliateClickUrl()); ?>"
                data-coupon-title="<?php echo e($coupon->title); ?>"
                data-coupon-discount="<?php echo e($coupon->discountLabel()); ?>"
                data-coupon-store="<?php echo e($coupon->store?->name); ?>"
                data-coupon-expires="<?php echo e($coupon->expiresLabel()); ?>"
                data-shop-url="<?php echo e(route('coupons.go', $coupon->slug)); ?>"
                aria-label="Copy promo code">
                Copy Code
            </button>
        <?php else: ?>
            <a href="<?php echo e(route('coupons.go', $coupon->slug)); ?>" class="btn btn-primary sp-get-deal-btn" target="_blank" rel="noopener sponsored">Get Deal</a>
        <?php endif; ?>
    </div>
</article>
<?php /**PATH /var/www/couponshere/resources/views/themes/savingspro/coupon-card.blade.php ENDPATH**/ ?>
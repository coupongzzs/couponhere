<?php
    use App\Support\Seo;

    $pageTitle = trim($__env->yieldContent('title') ?: 'Coupons & Discount Codes');
    $metaTitle = Seo::title($pageTitle);
    $metaDescription = trim($__env->yieldContent('meta_description'))
        ?: Seo::description(config('site.default_description'));

    $ogTitle = trim($__env->yieldContent('og_title'))
        ?: $pageTitle;
    $ogDescription = trim($__env->yieldContent('og_description'))
        ?: $metaDescription;

    $canonical = trim($__env->yieldContent('canonical')) ?: Seo::canonical();
    $ogUrl = trim($__env->yieldContent('og_url')) ?: $canonical;
    if (! preg_match('#^https?://#i', $ogUrl)) {
        $ogUrl = Seo::absoluteUrl($ogUrl);
    }
    if (! preg_match('#^https?://#i', $canonical)) {
        $canonical = Seo::absoluteUrl($canonical);
    }

    $robots = trim($__env->yieldContent('meta_robots')) ?: 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1';
    $ogType = trim($__env->yieldContent('og_type')) ?: 'website';
    $ogImage = Seo::ogImage(trim($__env->yieldContent('og_image')) ?: null);
    $ogImageAlt = trim($__env->yieldContent('og_image_alt')) ?: $ogTitle;
?>
<title><?php echo e($metaTitle); ?></title>
<meta name="description" content="<?php echo e($metaDescription); ?>">
<meta name="robots" content="<?php echo e($robots); ?>">
<meta name="convertiser-verification" content="ff67d94429cb7d3afb3aebdf954a104d1908cecd" />
<?php echo $__env->make('partials.favicon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="canonical" href="<?php echo e($canonical); ?>">

<meta property="og:locale" content="<?php echo e(str_replace('_', '-', config('site.locale'))); ?>">
<meta property="og:type" content="<?php echo e($ogType); ?>">
<meta property="og:site_name" content="<?php echo e($siteName); ?>">
<meta property="og:title" content="<?php echo e($ogTitle); ?>">
<meta property="og:description" content="<?php echo e($ogDescription); ?>">
<meta property="og:url" content="<?php echo e($ogUrl); ?>">
<meta property="og:image" content="<?php echo e($ogImage); ?>">
<meta property="og:image:alt" content="<?php echo e($ogImageAlt); ?>">
<?php echo $__env->yieldPushContent('og_meta'); ?>

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo e($ogTitle); ?>">
<meta name="twitter:description" content="<?php echo e($ogDescription); ?>">
<meta name="twitter:image" content="<?php echo e($ogImage); ?>">
<?php if(config('site.twitter_handle')): ?>
<meta name="twitter:site" content="<?php echo e(config('site.twitter_handle')); ?>">
<?php endif; ?>

<?php echo $__env->yieldPushContent('head_links'); ?>
<?php /**PATH /var/www/couponshere/resources/views/partials/seo-head.blade.php ENDPATH**/ ?>
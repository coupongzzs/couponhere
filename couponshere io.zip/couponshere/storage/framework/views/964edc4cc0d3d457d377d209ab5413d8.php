<?php
    $themeCard = 'themes.'.($activeTheme ?? '').'.coupon-card';
?>
<?php if(view()->exists($themeCard)): ?>
    <?php echo $__env->make($themeCard, get_defined_vars(), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<article class="coupon-card <?php echo e($coupon->is_featured ? 'featured' : ''); ?><?php echo e(($linkCardToDetail ?? false) ? ' coupon-card--clickable' : ''); ?>" <?php if($coupon->code): ?> data-code-reveal <?php endif; ?>>
    <?php if($linkCardToDetail ?? false): ?>
        <a href="<?php echo e(route('coupons.show', $coupon->slug)); ?>" class="coupon-card-overlay" aria-label="View <?php echo e($coupon->title); ?>"></a>
    <?php endif; ?>
    <div class="coupon-card-top">
        <?php echo $__env->make('partials.store-logo', ['store' => $coupon->store, 'size' => 'md', 'showVerified' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="coupon-card-badges">
            <?php if($coupon->code): ?>
                <div class="coupon-code-preview">
                    <?php echo $__env->make('partials.coupon-code-masked', ['coupon' => $coupon], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            <?php endif; ?>
            <div class="coupon-badge"><?php echo e($coupon->discountLabel()); ?></div>
            <div class="coupon-type"><?php echo e($coupon->typeLabel()); ?></div>
        </div>
    </div>
    <h3 class="coupon-title">
        <?php if($linkCardToDetail ?? false): ?>
            <?php echo e($coupon->title); ?> at <?php echo e($coupon->store?->name); ?>

        <?php else: ?>
            <a href="<?php echo e(route('coupons.show', $coupon->slug)); ?>"><?php echo e($coupon->title); ?> at <?php echo e($coupon->store?->name); ?></a>
        <?php endif; ?>
    </h3>
    <?php if($showDescription ?? false): ?>
        <p class="coupon-description">
            <?php if(filled($coupon->description)): ?>
                <?php echo e(\Illuminate\Support\Str::limit(strip_tags($coupon->description), 160)); ?>

            <?php endif; ?>
        </p>
    <?php endif; ?>
    <?php if($coupon->expires_at): ?>
        <p class="coupon-expire">Expires: <?php echo e($coupon->expires_at->format('m/d/Y')); ?></p>
    <?php endif; ?>
    <div class="coupon-actions">
        <?php if($coupon->code): ?>
            <button type="button" class="btn btn-copy"
                data-reveal-url="<?php echo e(route('coupons.reveal', $coupon->slug)); ?>"
                data-affiliate-url="<?php echo e($coupon->affiliateClickUrl()); ?>"
                data-shop-url="<?php echo e(route('coupons.go', $coupon->slug)); ?>"
                data-coupon-title="<?php echo e($coupon->title); ?>"
                data-coupon-discount="<?php echo e($coupon->discountLabel()); ?>"
                data-coupon-store="<?php echo e($coupon->store?->name); ?>"
                data-coupon-expires="<?php echo e($coupon->expiresLabel()); ?>"
            >
                Copy Code
            </button>
            <a href="<?php echo e(route('coupons.go', $coupon->slug)); ?>" class="btn btn-outline" target="_blank" rel="noopener sponsored">Shop Now</a>
        <?php else: ?>
            <a href="<?php echo e(route('coupons.go', $coupon->slug)); ?>" class="btn btn-outline" target="_blank" rel="noopener sponsored">Shop Now</a>
        <?php endif; ?>
    </div>
</article>
<?php endif; ?>
<?php /**PATH /var/www/couponshere/resources/views/partials/coupon-card.blade.php ENDPATH**/ ?>
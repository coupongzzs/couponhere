<section class="section pch-stores-section">
    <div class="container">
        <p class="pch-deals-eyebrow">Stores in focus</p>
        <h2 class="pch-deals-title">Featured destinations</h2>
        <p class="pch-deals-subtitle">
            Tap a logo to jump straight into coupons and campaign details for that brand.
        </p>

        <?php if($stores->isNotEmpty()): ?>
            <div class="pch-store-tray" aria-label="Featured stores">
                <div class="pch-store-tray-track">
                    <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('stores.show', $store->slug)); ?>" class="pch-store-item">
                            <span class="pch-store-logo">
                                <?php echo $__env->make('partials.store-logo', [
                                    'store' => $store,
                                    'size' => 'lg',
                                    'showVerified' => false,
                                    'linked' => false,
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </span>
                            <span class="pch-store-name"><?php echo e($store->name); ?></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php else: ?>
            <p class="pch-deals-empty">No featured stores yet.</p>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH /var/www/couponshere/resources/views/themes/prime/home-stores.blade.php ENDPATH**/ ?>
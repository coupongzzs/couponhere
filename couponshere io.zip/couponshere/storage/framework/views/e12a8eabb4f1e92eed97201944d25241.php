<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<h1 style="margin-bottom:1.5rem;">Dashboard</h1>
<p style="margin-bottom:1.5rem;display:flex;flex-wrap:wrap;gap:.75rem;">
    <a href="<?php echo e(route('member.import-affiliate.create')); ?>" class="btn btn-primary">Import from Affiliate Link</a>
    <a href="<?php echo e(route('admin.domain-change.index')); ?>" class="btn btn-outline">Change Domain</a>
    <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-outline">Manage Categories</a>
    <a href="<?php echo e(route('admin.stores.index')); ?>" class="btn btn-outline">Manage Stores</a>
    <a href="<?php echo e(route('admin.themes.index')); ?>" class="btn btn-outline">Frontend Theme</a>
    <a href="<?php echo e(route('admin.tracking.index')); ?>" class="btn btn-outline">Tracking Scripts</a>
    <?php if(config('affiliate.enabled') && $stats['pending_affiliate_payouts'] > 0): ?>
        <a href="<?php echo e(route('admin.affiliate.payouts.index')); ?>" class="btn btn-primary">Affiliate Payouts (<?php echo e($stats['pending_affiliate_payouts']); ?> pending)</a>
    <?php endif; ?>
</p>
<div class="stats-grid">
    <div class="stat-card"><strong><?php echo e($stats['coupons']); ?></strong> Total Coupons</div>
    <div class="stat-card"><strong><?php echo e($stats['active_coupons']); ?></strong> Active</div>
    <div class="stat-card"><strong><?php echo e($stats['stores']); ?></strong> Stores</div>
    <div class="stat-card"><strong><?php echo e($stats['categories']); ?></strong> Categories</div>
    <div class="stat-card"><strong><?php echo e($stats['published_posts']); ?></strong> Blog Posts</div>
    <div class="stat-card"><strong><?php echo e(number_format($stats['clicks'])); ?></strong> Clicks</div>
    <?php if(config('affiliate.enabled') && $stats['pending_affiliate_payouts'] > 0): ?>
    <div class="stat-card"><strong><?php echo e($stats['pending_affiliate_payouts']); ?></strong> Pending Payouts</div>
    <?php endif; ?>
</div>
<h2 style="margin-bottom:1rem;">
    <?php if(($sort ?? 'clicks') === 'latest'): ?>
        Latest Coupons
    <?php elseif(($sort ?? 'clicks') === 'title'): ?>
        Coupons by Title
    <?php else: ?>
        Top Coupons by Clicks
    <?php endif; ?>
</h2>
<table class="admin-table">
    <thead>
        <tr>
            <?php echo $__env->make('partials.table-sort-th', ['column' => 'title', 'label' => 'Title', 'currentSort' => $sort ?? 'clicks', 'currentDir' => $dir ?? 'desc'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <th>Store</th>
            <th>Type</th>
            <?php echo $__env->make('partials.table-sort-th', ['column' => 'clicks', 'label' => 'Clicks', 'currentSort' => $sort ?? 'clicks', 'currentDir' => $dir ?? 'desc'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $recentCoupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><a href="<?php echo e(route('admin.coupons.edit', $c)); ?>"><?php echo e($c->title); ?></a></td>
            <td><?php echo e($c->store?->name); ?></td>
            <td><?php echo e($c->typeLabel()); ?></td>
            <td><?php echo e(number_format($c->click_count)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>
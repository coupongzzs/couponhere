<?php
    $fromSaved = $fromSaved ?? false;
    $savedAt = $savedAt ?? null;
    $exportCsvUrl = $exportCsvUrl ?? null;
    $exportAssetsCsvUrl = $exportAssetsCsvUrl ?? null;
    $exportTargetingCsvUrl = $exportTargetingCsvUrl ?? null;
?>
<div class="import-card keyword-results-card" style="margin-top:1.5rem;" id="keyword-results">
    <div class="import-card-header">
        <h2>Generated Keywords (<?php echo e(count($result['all'])); ?>)</h2>
        <div style="display:flex;gap:.5rem;flex-wrap:wrap;">
            <?php if($exportCsvUrl): ?>
                <a href="<?php echo e($exportCsvUrl); ?>" class="btn btn-primary btn-sm download-csv-btn">Download Keywords CSV</a>
            <?php endif; ?>
            <?php if($exportAssetsCsvUrl): ?>
                <a href="<?php echo e($exportAssetsCsvUrl); ?>" class="btn btn-outline btn-sm download-assets-csv-btn">Download Assets CSV</a>
            <?php endif; ?>
            <?php if($exportTargetingCsvUrl): ?>
                <a href="<?php echo e($exportTargetingCsvUrl); ?>" class="btn btn-outline btn-sm download-targeting-csv-btn">Download Targeting CSV</a>
            <?php endif; ?>
            <button type="button" class="btn btn-outline btn-sm copy-all-btn">Copy all</button>
            <a href="#" class="btn btn-outline btn-sm download-txt-btn">Download .txt</a>
        </div>
    </div>
    <?php if($fromSaved && $savedAt): ?>
        <p class="alert alert-success" style="margin-bottom:1rem;padding:.65rem .85rem;font-size:.9rem;">
            Loaded saved keyword set (last updated <?php echo e($savedAt); ?>). Edit products and click Generate to replace.
        </p>
    <?php endif; ?>
    <p class="form-hint">
        Brand: <strong><?php echo e($brandLabel); ?></strong> —
        <?php echo e(count($result['brand'])); ?> brand keywords
        <?php if(count($result['by_product']) > 0): ?>
            + <?php echo e(count($result['by_product'])); ?> product(s) × <?php echo e(count($engine->productTemplates())); ?> each
        <?php endif; ?>
    </p>

    <?php if($exportCsvUrl): ?>
        <p class="form-hint" style="margin-top:.5rem;">
            <strong>Keywords CSV:</strong> <code><?php echo e(implode('</code>, <code>', \App\Support\GoogleAdsKeywordExport::HEADERS)); ?></code><br>
            <strong>Assets CSV:</strong> sitelinks &amp; callouts from <a href="<?php echo e(route('admin.ads-settings.index')); ?>">Ads Settings</a>
            (<code><?php echo e(implode('</code>, <code>', \App\Support\GoogleAdsKeywordExport::ASSET_HEADERS)); ?></code>).<br>
            <strong>Targeting CSV:</strong> per-store locations, languages &amp; networks
            (<code><?php echo e(implode('</code>, <code>', \App\Support\GoogleAdsKeywordExport::TARGETING_HEADERS)); ?></code>).
            Import in Google Ads Editor → Account → Import.
        </p>
    <?php endif; ?>

    <h3 style="font-size:1rem;margin:1.25rem 0 .5rem;">Brand keywords</h3>
    <ul class="keyword-result-list">
        <?php $__currentLoopData = $result['brand']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($keyword); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <?php $__currentLoopData = $result['by_product']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product => $keywords): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3 style="font-size:1rem;margin:1.25rem 0 .5rem;"><?php echo e($brandLabel); ?> — <?php echo e($product); ?></h3>
        <ul class="keyword-result-list">
            <?php $__currentLoopData = $keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($keyword); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <h3 style="font-size:1rem;margin:1.25rem 0 .5rem;">All keywords (one per line)</h3>
    <textarea class="keyword-export-area keywords-export" readonly rows="12"><?php echo e(collect($result['all'])->map(fn ($k) => '"' . str_replace('"', '\"', $k) . '"')->implode("\n")); ?></textarea>
</div>
<?php /**PATH /var/www/couponshere/resources/views/member/keywords/partials/results.blade.php ENDPATH**/ ?>
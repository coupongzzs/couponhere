<article
    class="pch-coupon-card coupon-card<?php echo e($coupon->is_featured ? ' featured' : ''); ?><?php echo e(($linkCardToDetail ?? false) ? ' coupon-card--clickable' : ''); ?>"
    <?php if($coupon->code): ?> data-code-reveal <?php endif; ?>
>
    <?php if($linkCardToDetail ?? false): ?>
        <a href="<?php echo e(route('coupons.show', $coupon->slug)); ?>" class="coupon-card-overlay" aria-label="View <?php echo e($coupon->title); ?>"></a>
    <?php endif; ?>

    <div class="pch-coupon-rail" aria-hidden="true">
        <span class="pch-coupon-rail-icon">%</span>
        <span class="pch-coupon-rail-label"><?php echo e($coupon->code ? 'Code' : 'Deal'); ?></span>
    </div>

    <div class="pch-coupon-body">
        <div class="pch-coupon-store">
            <?php echo $__env->make('partials.store-logo', [
                'store' => $coupon->store,
                'size' => 'md',
                'showVerified' => false,
                'linked' => !($linkCardToDetail ?? false),
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if($coupon->store): ?>
                <a href="<?php echo e(route('stores.show', $coupon->store->slug)); ?>" class="pch-coupon-store-name">
                    <?php echo e($coupon->store->name); ?>

                </a>
            <?php endif; ?>
        </div>

        <h3 class="pch-coupon-title">
            <?php if($linkCardToDetail ?? false): ?>
                <?php echo e($coupon->title); ?>

            <?php else: ?>
                <a href="<?php echo e(route('coupons.show', $coupon->slug)); ?>"><?php echo e($coupon->title); ?></a>
            <?php endif; ?>
        </h3>

        <div class="pch-coupon-actions">
            <div class="pch-code-box<?php echo e($coupon->code ? '' : ' pch-code-box--deal'); ?>">
                <?php if($coupon->code): ?>
                    <?php echo $__env->make('partials.coupon-code-masked', ['coupon' => $coupon, 'class' => 'pch-code-masked'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <button
                        type="button"
                        class="pch-code-copy"
                        data-reveal-url="<?php echo e(route('coupons.reveal', $coupon->slug)); ?>"
                        data-affiliate-url="<?php echo e($coupon->affiliateClickUrl()); ?>"
                        data-shop-url="<?php echo e(route('coupons.go', $coupon->slug)); ?>"
                        data-coupon-title="<?php echo e($coupon->title); ?>"
                        data-coupon-discount="<?php echo e($coupon->discountLabel()); ?>"
                        data-coupon-store="<?php echo e($coupon->store?->name); ?>"
                        data-coupon-expires="<?php echo e($coupon->expiresLabel()); ?>"
                    >Copy</button>
                <?php else: ?>
                    <span class="pch-code-plain">No Need Code</span>
                <?php endif; ?>
            </div>

            <a
                href="<?php echo e(route('coupons.go', $coupon->slug)); ?>"
                class="pch-get-deal"
                target="_blank"
                rel="noopener sponsored"
            >Get Deal</a>
        </div>
    </div>
</article>
<?php /**PATH /var/www/couponshere/resources/views/themes/prime/coupon-card.blade.php ENDPATH**/ ?>
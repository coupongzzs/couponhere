<?php
    $panel = $panel ?? 'member';
    $isAdmin = auth()->user()->isAdmin();
    $showGoogleAdsBuilder = (bool) config('site.google_ads_builder_enabled', false);

    $siteConfigOpen = request()->routeIs(
        'admin.branding.*',
        'admin.integrations.*',
        'admin.domain-change.*',
        'admin.account.*',
        'admin.tracking.*',
        'admin.themes.*',
    );
    $contentOpen = request()->routeIs(
        'admin.posts.*',
        'admin.categories.*',
        'admin.stores.*',
        'admin.coupons.*',
        'member.import-affiliate.*',
        'admin.affiliate-excel-import.*',
        'member.posts.*',
        'member.stores.*',
        'member.coupons.*',
    );
    $affiliateOpen = request()->routeIs(
        'admin.affiliate-signups.*',
        'admin.affiliate.*',
        'member.affiliate.*',
    );
    $googleAdsOpen = request()->routeIs('member.keywords.*', 'admin.ads-settings.*');
?>
<nav class="sidebar-nav" aria-label="Dashboard menu">
    <div class="sidebar-nav-group">
        <?php if($panel === 'admin'): ?>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('admin.dashboard')]); ?>">Dashboard</a>
        <?php else: ?>
            <a href="<?php echo e(route('member.dashboard')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('member.dashboard')]); ?>">Dashboard</a>
        <?php endif; ?>
    </div>

    <hr class="sidebar-divider" aria-hidden="true">

    <?php if($panel === 'admin'): ?>
        <div class="sidebar-nav-group">
            <?php echo $__env->make('partials.dashboard-sidebar-collapsible-section-start', [
                'sectionId' => 'site-config',
                'sectionLabel' => 'Site Configuration',
                'sectionOpen' => $siteConfigOpen,
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <a href="<?php echo e(route('admin.branding.index')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.branding.*')]); ?>">Logo &amp; Social</a>
                <a href="<?php echo e(route('admin.integrations.index')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.integrations.*')]); ?>">Integrations</a>
                <a href="<?php echo e(route('admin.domain-change.index')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.domain-change.*')]); ?>">Change Domain</a>
                <a href="<?php echo e(route('admin.account.edit')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.account.*')]); ?>">Account</a>
                <a href="<?php echo e(route('admin.tracking.index')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.tracking.*')]); ?>">Tracking Scripts</a>
                <a href="<?php echo e(route('admin.themes.index')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.themes.*')]); ?>">Frontend Theme</a>
            <?php echo $__env->make('partials.dashboard-sidebar-collapsible-section-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <hr class="sidebar-divider" aria-hidden="true">

        <div class="sidebar-nav-group">
            <?php echo $__env->make('partials.dashboard-sidebar-collapsible-section-start', [
                'sectionId' => 'content',
                'sectionLabel' => 'Content',
                'sectionOpen' => $contentOpen,
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <a href="<?php echo e(route('admin.posts.index')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.posts.*')]); ?>">Blogs</a>
                <a href="<?php echo e(route('admin.categories.index')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.categories.*')]); ?>">Categories</a>
                <a href="<?php echo e(route('admin.stores.index')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.stores.*')]); ?>">Stores</a>
                <a href="<?php echo e(route('admin.coupons.index')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.coupons.*')]); ?>">Coupons</a>
                <a href="<?php echo e(route('member.import-affiliate.create')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('member.import-affiliate.*')]); ?>">Import from Affiliate Link</a>
                <a href="<?php echo e(route('admin.affiliate-excel-import.index')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.affiliate-excel-import.*')]); ?>">Auto Import (Excel)</a>
            <?php echo $__env->make('partials.dashboard-sidebar-collapsible-section-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <hr class="sidebar-divider" aria-hidden="true">

        <div class="sidebar-nav-group">
            <?php echo $__env->make('partials.dashboard-sidebar-collapsible-section-start', [
                'sectionId' => 'affiliate',
                'sectionLabel' => 'Affiliate',
                'sectionOpen' => $affiliateOpen,
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <a href="<?php echo e(route('admin.affiliate-signups.index')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.affiliate-signups.*')]); ?>">Affiliate Signups</a>
                <?php if(config('affiliate.enabled')): ?>
                    <a href="<?php echo e(route('admin.affiliate.orders.index')); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.affiliate.*')]); ?>">Referral Program</a>
                <?php endif; ?>
            <?php echo $__env->make('partials.dashboard-sidebar-collapsible-section-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php else: ?>
        <?php if($isAdmin): ?>
            <div class="sidebar-nav-group">
                <?php echo $__env->make('partials.dashboard-sidebar-collapsible-section-start', [
                    'sectionId' => 'site-config',
                    'sectionLabel' => 'Site Configuration',
                    'sectionOpen' => $siteConfigOpen,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <a href="<?php echo e(route('admin.branding.index')); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.branding.*')]); ?>">Logo &amp; Social</a>
                    <a href="<?php echo e(route('admin.integrations.index')); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.integrations.*')]); ?>">Integrations</a>
                    <a href="<?php echo e(route('admin.domain-change.index')); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.domain-change.*')]); ?>">Change Domain</a>
                    <a href="<?php echo e(route('admin.tracking.index')); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.tracking.*')]); ?>">Tracking Scripts</a>
                    <a href="<?php echo e(route('admin.themes.index')); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.themes.*')]); ?>">Frontend Theme</a>
                <?php echo $__env->make('partials.dashboard-sidebar-collapsible-section-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <hr class="sidebar-divider" aria-hidden="true">
        <?php endif; ?>

        <div class="sidebar-nav-group">
            <?php echo $__env->make('partials.dashboard-sidebar-collapsible-section-start', [
                'sectionId' => 'content',
                'sectionLabel' => 'Content',
                'sectionOpen' => $contentOpen,
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <a href="<?php echo e(route('member.posts.index')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('member.posts.*')]); ?>">Blogs</a>
                <?php if($isAdmin): ?>
                    <a href="<?php echo e(route('admin.categories.index')); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.categories.*')]); ?>">Categories</a>
                <?php endif; ?>
                <a href="<?php echo e(route('member.stores.index')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('member.stores.*')]); ?>">Stores</a>
                <a href="<?php echo e(route('member.coupons.index')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('member.coupons.*')]); ?>">Coupons</a>
                <a href="<?php echo e(route('member.import-affiliate.create')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('member.import-affiliate.*')]); ?>">Import from Affiliate Link</a>
                <?php if($isAdmin): ?>
                    <a href="<?php echo e(route('admin.affiliate-excel-import.index')); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.affiliate-excel-import.*')]); ?>">Auto Import (Excel)</a>
                <?php endif; ?>
            <?php echo $__env->make('partials.dashboard-sidebar-collapsible-section-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <?php if($isAdmin): ?>
            <hr class="sidebar-divider" aria-hidden="true">

            <div class="sidebar-nav-group">
                <?php echo $__env->make('partials.dashboard-sidebar-collapsible-section-start', [
                    'sectionId' => 'affiliate',
                    'sectionLabel' => 'Affiliate',
                    'sectionOpen' => $affiliateOpen,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <a href="<?php echo e(route('admin.affiliate-signups.index')); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.affiliate-signups.*')]); ?>">Affiliate Signups</a>
                    <?php if(config('affiliate.enabled')): ?>
                        <a href="<?php echo e(route('admin.affiliate.orders.index')); ?>"
                            class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.affiliate.*')]); ?>">Referral Program</a>
                    <?php endif; ?>
                <?php echo $__env->make('partials.dashboard-sidebar-collapsible-section-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php elseif(config('affiliate.enabled')): ?>
            <hr class="sidebar-divider" aria-hidden="true">

            <div class="sidebar-nav-group">
                <a href="<?php echo e(route('member.affiliate.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('member.affiliate.*')]); ?>">Referral Program</a>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if($showGoogleAdsBuilder): ?>
        <hr class="sidebar-divider" aria-hidden="true">

        <div class="sidebar-nav-group">
            <?php echo $__env->make('partials.dashboard-sidebar-collapsible-section-start', [
                'sectionId' => 'google-ads',
                'sectionLabel' => 'Google Ads Builder',
                'sectionOpen' => $googleAdsOpen,
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <a href="<?php echo e(route('member.keywords.create')); ?>"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('member.keywords.*')]); ?>">Keyword Generator</a>
                <?php if($isAdmin): ?>
                    <a href="<?php echo e(route('admin.ads-settings.index')); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.ads-settings.*')]); ?>">Ads Settings</a>
                <?php endif; ?>
            <?php echo $__env->make('partials.dashboard-sidebar-collapsible-section-end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php endif; ?>

    <hr class="sidebar-divider" aria-hidden="true">

    <div class="sidebar-nav-group sidebar-nav-group--footer">
        <a href="<?php echo e(route('home')); ?>">← Back to site</a>
        <form action="<?php echo e(route('logout')); ?>" method="POST" class="sidebar-logout-form">
            <?php echo csrf_field(); ?>
            <button type="submit" class="sidebar-logout-btn">Sign Out</button>
        </form>
    </div>
</nav>

<?php if (! $__env->hasRenderedOnce('d9e3515f-a2fd-43db-bf53-62f4492aa631')): $__env->markAsRenderedOnce('d9e3515f-a2fd-43db-bf53-62f4492aa631'); ?>
    <?php $__env->startPush('scripts'); ?>
    <script>
    (() => {
        const storageKey = 'hako-sidebar-sections';
        let saved = {};

        try {
            saved = JSON.parse(localStorage.getItem(storageKey) || '{}') || {};
        } catch (error) {
            saved = {};
        }

        document.querySelectorAll('[data-sidebar-section]').forEach((section) => {
            const id = section.dataset.sidebarSection;
            const toggle = section.querySelector('.sidebar-nav-section-toggle');
            const hasActiveLink = !!section.querySelector('.sidebar-nav-sublink.active, a.active');
            const defaultOpen = section.hasAttribute('data-sidebar-open-default') || hasActiveLink;
            const open = Object.prototype.hasOwnProperty.call(saved, id) ? !!saved[id] : defaultOpen;

            section.classList.toggle('is-open', open);
            if (toggle) {
                toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            }

            toggle?.addEventListener('click', () => {
                const nextOpen = !section.classList.contains('is-open');
                section.classList.toggle('is-open', nextOpen);
                toggle.setAttribute('aria-expanded', nextOpen ? 'true' : 'false');
                saved[id] = nextOpen;
                localStorage.setItem(storageKey, JSON.stringify(saved));
            });
        });
    })();
    </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /var/www/couponshere/resources/views/partials/dashboard-sidebar-nav.blade.php ENDPATH**/ ?>
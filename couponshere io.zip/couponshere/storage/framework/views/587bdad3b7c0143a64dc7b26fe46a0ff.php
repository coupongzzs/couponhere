<?php
    $store = $store ?? null;
?>
<?php if($store && $store->clickOpensExternal()): ?>
target="_blank" rel="noopener sponsored"
<?php endif; ?>
<?php /**PATH /var/www/couponshere/resources/views/partials/store-link-attrs.blade.php ENDPATH**/ ?>
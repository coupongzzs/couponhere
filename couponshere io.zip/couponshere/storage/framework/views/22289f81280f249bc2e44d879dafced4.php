<?php ($trackingHead = \App\Support\TrackingScripts::headHtml()); ?>
<?php if($trackingHead !== ''): ?>
<?php echo $trackingHead; ?>

<?php endif; ?>
<?php /**PATH /var/www/couponshere/resources/views/partials/tracking-head.blade.php ENDPATH**/ ?>
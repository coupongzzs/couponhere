<?php $__env->startSection('title', 'Contact Us'); ?>
<?php $__env->startSection('meta_description', 'Contact ' . config('site.name') . ' for partnership inquiries, coupon submissions, or support. We respond to U.S. shoppers and publishers.'); ?>
<?php $__env->startSection('canonical', route('pages.contact')); ?>

<?php $__env->startSection('page_title', 'Contact Us'); ?>

<?php $__env->startSection('page_subtitle'); ?>
    We typically respond within 2–3 business days.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
<div class="contact-grid">
    <div class="contact-info">
        <h2>Get in Touch</h2>
        <p>
            For general questions, press inquiries, merchant partnerships, or help with an offer listed on
            <?php echo e($siteDomain); ?>, use the form or contact us directly.
        </p>

        <div class="contact-card">
            <h3>General Inquiries</h3>
            <p><a href="mailto:<?php echo e($contactEmail); ?>"><?php echo e($contactEmail); ?></a></p>
        </div>

        <div class="contact-card">
            <h3>Privacy Requests</h3>
            <p>
                For privacy-related questions or data requests (CCPA/CPRA), email
                <a href="mailto:<?php echo e($privacyEmail); ?>"><?php echo e($privacyEmail); ?></a>.
            </p>
        </div>

        <?php if(!empty($siteSocialLinks)): ?>
            <div class="contact-card">
                <h3>Follow Us</h3>
                <p>Connect with <?php echo e($siteName); ?> on social media.</p>
                <?php echo $__env->make('partials.site-social-links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endif; ?>

        <div class="contact-card">
            <h3>Mailing Address</h3>
            <p>
                <?php echo e($siteName); ?><br>
                c/o Customer Support<br>
                <?php echo e($siteDomain); ?><br>
                United States
            </p>
            <p class="text-muted"><small>Please use email for the fastest response.</small></p>
        </div>

        <h2>Before You Write</h2>
        <ul>
            <li><strong>Coupon not working?</strong> Offers expire frequently—check the retailer’s site for current terms.</li>
            <li><strong>Order issues?</strong> Contact the store where you purchased; we do not process orders.</li>
            <li><strong>Remove a listing?</strong> Merchants may request updates via the form below.</li>
        </ul>
    </div>

    <div class="contact-form-wrap">
        <h2>Send a Message</h2>
        <form method="POST" action="<?php echo e(route('pages.contact.submit')); ?>" class="contact-form">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Full Name *</label>
                <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" required maxlength="100">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="email">Email Address *</label>
                <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required maxlength="255">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="subject">Subject *</label>
                <select id="subject" name="subject" required>
                    <option value="">Select a topic</option>
                    <option value="General Question" <?php if(old('subject') === 'General Question'): echo 'selected'; endif; ?>>General Question</option>
                    <option value="Coupon / Offer Issue" <?php if(old('subject') === 'Coupon / Offer Issue'): echo 'selected'; endif; ?>>Coupon / Offer Issue</option>
                    <option value="Merchant / Partnership" <?php if(old('subject') === 'Merchant / Partnership'): echo 'selected'; endif; ?>>Merchant / Partnership</option>
                    <option value="Privacy / Data Request" <?php if(old('subject') === 'Privacy / Data Request'): echo 'selected'; endif; ?>>Privacy / Data Request</option>
                    <option value="Report Incorrect Content" <?php if(old('subject') === 'Report Incorrect Content'): echo 'selected'; endif; ?>>Report Incorrect Content</option>
                    <option value="Other" <?php if(old('subject') === 'Other'): echo 'selected'; endif; ?>>Other</option>
                </select>
                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="message">Message *</label>
                <textarea id="message" name="message" rows="6" required maxlength="5000"><?php echo e(old('message')); ?></textarea>
                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-check">
                <input type="checkbox" name="consent" id="consent" value="1" <?php if(old('consent')): echo 'checked'; endif; ?> required>
                <label for="consent">
                    I agree to the <a href="<?php echo e(route('pages.privacy')); ?>" target="_blank">Privacy Policy</a>
                    and consent to <?php echo e($siteName); ?> processing my information to respond to this inquiry. *
                </label>
            </div>
            <?php $__errorArgs = ['consent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <button type="submit" class="btn btn-primary" style="width:100%;padding:.75rem;margin-top:.5rem;">Send Message</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/pages/contact.blade.php ENDPATH**/ ?>
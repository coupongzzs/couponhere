<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<h1 style="margin-bottom:1.5rem;">My Dashboard</h1>
<p style="color:var(--muted);margin-bottom:1rem;">Statistics for content you created only.</p>
<p style="margin-bottom:1.5rem;display:flex;flex-wrap:wrap;gap:.75rem;">
    <a href="<?php echo e(route('member.import-affiliate.create')); ?>" class="btn btn-primary">Import from Affiliate Link</a>
    <?php if(auth()->user()->isAdmin()): ?>
        <a href="<?php echo e(route('admin.tracking.index')); ?>" class="btn btn-outline">Tracking Scripts</a>
        <a href="<?php echo e(route('admin.themes.index')); ?>" class="btn btn-outline">Frontend Theme</a>
    <?php endif; ?>
    <?php if(config('affiliate.enabled')): ?>
    <a href="<?php echo e(route('member.affiliate.index')); ?>" class="btn btn-outline">Referral Program</a>
    <?php endif; ?>
</p>
<div class="stats-grid">
    <div class="stat-card"><strong><?php echo e($stats['coupons']); ?></strong> My Coupons</div>
    <div class="stat-card"><strong><?php echo e($stats['active_coupons']); ?></strong> Active</div>
    <div class="stat-card"><strong><?php echo e($stats['stores']); ?></strong> My Stores</div>
    <div class="stat-card"><strong><?php echo e($stats['published_posts']); ?></strong> Published Posts</div>
    <div class="stat-card"><strong><?php echo e(number_format($stats['clicks'])); ?></strong> Coupon Clicks</div>
    <div class="stat-card"><strong><?php echo e(number_format($stats['store_views'])); ?></strong> Store Page Views</div>
</div>
<h2 style="margin:1.5rem 0 1rem;">
    <?php if(($sort ?? 'clicks') === 'latest'): ?>
        Latest Coupons
    <?php elseif(($sort ?? 'clicks') === 'title'): ?>
        Coupons by Title
    <?php else: ?>
        Top Coupons by Clicks
    <?php endif; ?>
</h2>
<?php if($recentCoupons->isEmpty()): ?>
    <p>No coupons yet. <a href="<?php echo e(route('member.coupons.create')); ?>">Create your first coupon</a>.</p>
<?php else: ?>
<table class="admin-table">
    <thead>
        <tr>
            <?php echo $__env->make('partials.table-sort-th', ['column' => 'title', 'label' => 'Title', 'currentSort' => $sort ?? 'clicks', 'currentDir' => $dir ?? 'desc'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <th>Store</th>
            <th>Type</th>
            <?php echo $__env->make('partials.table-sort-th', ['column' => 'clicks', 'label' => 'Clicks', 'currentSort' => $sort ?? 'clicks', 'currentDir' => $dir ?? 'desc'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $recentCoupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><a href="<?php echo e(route('member.coupons.edit', $c)); ?>"><?php echo e($c->title); ?></a></td>
            <td><?php echo e($c->store?->name); ?></td>
            <td><?php echo e($c->typeLabel()); ?></td>
            <td><?php echo e(number_format($c->click_count)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/member/dashboard.blade.php ENDPATH**/ ?>
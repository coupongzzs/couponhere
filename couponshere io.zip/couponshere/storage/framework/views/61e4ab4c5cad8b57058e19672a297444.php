<?php $__env->startSection('title', 'My Blog Posts'); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;">
    <h1>My Blog Posts</h1>
    <a href="<?php echo e(route('member.posts.create')); ?>" class="btn btn-primary">+ New Post</a>
</div>

<?php echo $__env->make('partials.admin-list-search', [
    'action' => route('member.posts.index'),
    'value' => $q ?? '',
    'placeholder' => 'Search by title…',
    'clearUrl' => route('member.posts.index'),
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<table class="admin-table">
    <thead>
        <tr>
            <th>Image</th>
            <th>Title</th>
            <th>Status</th>
            <th>Published</th>
            <th>Views</th>
            <th class="table-actions-col">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <?php if($post->featuredImageUrl()): ?>
                        <img src="<?php echo e($post->featuredImageUrl()); ?>" alt="" class="admin-thumb admin-thumb--wide" loading="lazy">
                    <?php else: ?>
                        <span class="admin-thumb-empty">—</span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($post->title); ?></td>
                <td><?php echo e($post->is_published ? 'Published' : 'Draft'); ?></td>
                <td><?php echo e($post->published_at?->format('m/d/Y') ?? '—'); ?></td>
                <td><?php echo e(number_format($post->view_count)); ?></td>
                <td>
                    <?php echo $__env->make('partials.post-table-actions', ['post' => $post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6">
                    <?php if(filled($q ?? null)): ?>
                        No blog posts match your search.
                    <?php else: ?>
                        No blog posts yet. <a href="<?php echo e(route('member.posts.create')); ?>">Write your first post</a>.
                    <?php endif; ?>
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php echo e($posts->links()); ?>


<?php echo $__env->make('partials.table-actions-assets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/member/posts/index.blade.php ENDPATH**/ ?>
<?php if($store->shopUrl()): ?>
    <div class="store-shop-cta">
        <a href="<?php echo e($store->shopUrl()); ?>" class="btn btn-primary store-shop-cta-btn" target="_blank" rel="noopener sponsored">
            Shop at <?php echo e($store->name); ?>

        </a>
        <?php if($store->publicWebsiteLabel()): ?>
            <p class="store-page-website">
                <a href="<?php echo e($store->shopUrl()); ?>" target="_blank" rel="noopener sponsored"><?php echo e($store->shopLinkLabel()); ?></a>
            </p>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH /var/www/couponshere/resources/views/partials/store-shop-cta.blade.php ENDPATH**/ ?>
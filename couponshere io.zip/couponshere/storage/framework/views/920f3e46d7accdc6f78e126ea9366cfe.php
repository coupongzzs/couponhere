<section class="section pch-categories-section">
    <div class="container">
        <div class="pch-categories-intro">
            <p class="pch-deals-eyebrow">Topics</p>
            <h2 class="pch-deals-title">Browse by category</h2>
            <p class="pch-deals-subtitle">
                Jump into the verticals we cover most — each link filters the featured strip.
            </p>
        </div>

        <div class="pch-category-pills">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('categories.show', $category->slug)); ?>" class="pch-category-pill">
                    <?php echo e($category->name); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH /var/www/couponshere/resources/views/themes/prime/home-categories.blade.php ENDPATH**/ ?>
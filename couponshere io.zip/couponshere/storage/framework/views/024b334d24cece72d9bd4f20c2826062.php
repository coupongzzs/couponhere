<footer class="site-footer pch-footer">
    <div class="container pch-footer-grid">
        <div class="pch-footer-brand">
            <a href="<?php echo e(route('home')); ?>" class="pch-footer-logo">
                <?php echo e($siteDisplayName ?: $siteName); ?><span class="pch-footer-dot">.</span>
            </a>
            <p class="pch-footer-tagline">
                Coupons, promotions and trusted store reviews. Updated regularly.
            </p>
        </div>

        <div>
            <h4>Explore</h4>
            <a href="<?php echo e(route('home')); ?>">Home</a>
            <a href="<?php echo e(route('blog.index')); ?>">Review Blog</a>
            <a href="<?php echo e(route('stores.index')); ?>">Stores</a>
            <a href="<?php echo e(route('coupons.index')); ?>">Coupons</a>
        </div>

        <div>
            <h4>Legal</h4>
            <a href="<?php echo e(route('pages.about')); ?>">About Us</a>
            <a href="<?php echo e(route('pages.contact')); ?>">Contact</a>
            <a href="<?php echo e(route('pages.privacy')); ?>">Privacy Policy</a>
            <a href="<?php echo e(route('pages.cookies')); ?>">Cookie Policy</a>
            <a href="<?php echo e(route('pages.terms')); ?>">Terms of Use</a>
        </div>

        <div>
            <h4>Links</h4>
            <a href="<?php echo e(route('pages.contact')); ?>">Feedback</a>
            <a href="<?php echo e(route('coupons.index', ['type' => 'discount'])); ?>">Deals</a>
            <a href="<?php echo e(route('pages.disclaimer')); ?>">Affiliate Disclosure</a>
        </div>
    </div>

    <div class="container pch-footer-bottom">
        <p class="pch-footer-disclaimer">
            We may earn a commission when you use our links, at no extra cost to you.
            See our <a href="<?php echo e(route('pages.disclaimer')); ?>">Affiliate Disclosure</a>
            and <a href="<?php echo e(route('pages.privacy')); ?>">Privacy Policy</a>.
        </p>
        <p class="pch-footer-copy">
            &copy; <?php echo e(date('Y')); ?> <?php echo e($siteDisplayName ?: $siteName); ?>. All rights reserved.
        </p>
    </div>
</footer>
<?php /**PATH /var/www/couponshere/resources/views/themes/prime/footer.blade.php ENDPATH**/ ?>
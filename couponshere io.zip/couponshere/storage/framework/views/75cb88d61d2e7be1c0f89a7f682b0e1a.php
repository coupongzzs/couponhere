<?php $__env->startSection('title', $category->seoTitle()); ?>
<?php $__env->startSection('meta_description', $category->seoDescription()); ?>
<?php $__env->startSection('canonical', $coupons->currentPage() > 1 ? $coupons->url($coupons->currentPage()) : route('categories.show', $category->slug)); ?>

<?php $__env->startPush('head_links'); ?>
    <?php echo $__env->make('partials.pagination-seo', ['paginator' => $coupons], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('structured_data'); ?>
<?php echo $__env->make('partials.breadcrumb-schema', ['breadcrumbs' => [
    ['name' => 'Home', 'url' => route('home')],
    ['name' => 'Categories', 'url' => route('categories.index')],
    ['name' => $category->name, 'url' => route('categories.show', $category->slug)],
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-header">
        <h1 class="category-page-title">
            <?php echo $__env->make('partials.category-icon', ['category' => $category, 'size' => 'lg'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <span><?php echo e($category->name); ?></span>
        </h1>
        <?php if($category->description): ?><p><?php echo e($category->description); ?></p><?php endif; ?>
    </div>
    <div class="coupon-grid">
        <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo $__env->make('partials.coupon-card', ['coupon' => $coupon], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No offers in this category yet.</p>
        <?php endif; ?>
    </div>
    <div class="pagination"><?php echo e($coupons->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/categories/show.blade.php ENDPATH**/ ?>
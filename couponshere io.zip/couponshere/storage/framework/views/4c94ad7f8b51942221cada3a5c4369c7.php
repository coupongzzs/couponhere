<article class="pch-blog-card">
    <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="pch-blog-card-media" aria-hidden="<?php echo e($post->featuredImageUrl() ? 'false' : 'true'); ?>">
        <?php if($post->featuredImageUrl()): ?>
            <img src="<?php echo e($post->featuredImageUrl()); ?>" alt="" loading="lazy">
        <?php else: ?>
            <span class="pch-blog-card-placeholder"><?php echo e(\Illuminate\Support\Str::upper(\Illuminate\Support\Str::substr($post->cardTitle(), 0, 1))); ?></span>
        <?php endif; ?>
    </a>
    <div class="pch-blog-card-body">
        <h3 class="pch-blog-card-title">
            <a href="<?php echo e(route('blog.show', $post->slug)); ?>" <?php if($post->title !== $post->cardTitle()): ?> title="<?php echo e($post->title); ?>" <?php endif; ?>>
                <?php echo e($post->cardTitle()); ?>

            </a>
        </h3>
        <?php if($post->published_at): ?>
            <time class="pch-blog-card-date" datetime="<?php echo e($post->published_at->toDateString()); ?>">
                <?php echo e($post->published_at->format('j M Y')); ?>

            </time>
        <?php endif; ?>
        <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="pch-blog-card-link">Open story</a>
    </div>
</article>
<?php /**PATH /var/www/couponshere/resources/views/themes/prime/blog-card.blade.php ENDPATH**/ ?>
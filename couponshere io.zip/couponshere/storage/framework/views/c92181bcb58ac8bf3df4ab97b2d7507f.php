<?php $__env->startSection('title', 'Integrations'); ?>

<?php $__env->startSection('content'); ?>
<h1>Integrations</h1>
<p class="form-hint" style="margin-bottom:1.25rem;">
    Configure Gemini AI and site import settings. Settings are stored in the database per site.
</p>

<form action="<?php echo e(route('admin.integrations.update')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="integrations-section">
        <h2>Gemini AI</h2>
        <div class="form-group">
            <label for="gemini_api_key">Gemini API key</label>
            <?php if($geminiConfigured): ?>
                <p class="form-hint" style="margin-bottom:.5rem;">Current key: <code><?php echo e($geminiMasked); ?></code></p>
            <?php endif; ?>
            <input type="password" id="gemini_api_key" name="gemini_api_key" value="" maxlength="500" autocomplete="new-password" placeholder="<?php echo e($geminiConfigured ? 'Leave blank to keep current key' : 'Paste API key'); ?>">
            <p class="form-hint">Used for AI blog generation on affiliate import.</p>
            <?php $__errorArgs = ['gemini_api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <?php if($geminiConfigured): ?>
            <label class="form-check integrations-clear-key">
                <input type="hidden" name="clear_gemini_api_key" value="0">
                <input type="checkbox" name="clear_gemini_api_key" value="1">
                Remove saved Gemini API key
            </label>
        <?php endif; ?>
    </div>

    <div class="integrations-section">
        <h2>Affiliate Import</h2>
        <label class="form-check integrations-clear-key">
            <input type="hidden" name="import_allow_reimport_existing_stores" value="0">
            <input type="checkbox" name="import_allow_reimport_existing_stores" value="1" <?php if(old('import_allow_reimport_existing_stores', $allowReimportExistingStores)): echo 'checked'; endif; ?>>
            Allow re-importing existing stores
        </label>
        <p class="form-hint" style="margin-top:.5rem;">
            When enabled, importing the same merchant again updates the store, replaces offers, and refreshes the blog post.
            When disabled, the import button is blocked if that store already exists on your site.
        </p>
    </div>

    <div class="integrations-section">
        <h2>Coupon redirect flow</h2>
        <p class="form-hint" style="margin-bottom:.85rem;">
            Flow 1 keeps the coupon popup (destination opens when it closes).
            Flow 2/3 copy the code first, then open the merchant tab immediately — no coupon popup.
            On mobile, Flow 2/3 open the merchant right away (same-tab fallback if the browser blocks a new tab).
        </p>
        <div class="form-group coupon-redirect-options">
            <?php $__currentLoopData = $couponRedirectOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="form-check integrations-clear-key">
                    <input
                        type="radio"
                        name="coupon_redirect_flow"
                        value="<?php echo e($value); ?>"
                        <?php if(old('coupon_redirect_flow', $couponRedirectFlow) === $value): echo 'checked'; endif; ?>
                    >
                    <?php echo e($label); ?>

                </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__errorArgs = ['coupon_redirect_flow'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <button type="submit" class="btn btn-primary">Save settings</button>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.integrations-section {
    background: #fff;
    border: 1px solid var(--border, #e5e7eb);
    border-radius: 8px;
    padding: 1.25rem;
    margin-bottom: 1.25rem;
}
.integrations-section h2 {
    margin: 0 0 1rem;
    font-size: 1.05rem;
}
.integrations-clear-key {
    display: flex;
    align-items: center;
    gap: .5rem;
    margin-top: .75rem;
    font-size: .92rem;
}
.coupon-redirect-options .integrations-clear-key {
    align-items: flex-start;
    margin-top: .55rem;
}
.coupon-redirect-options .integrations-clear-key input {
    margin-top: .2rem;
}
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/admin/integrations/index.blade.php ENDPATH**/ ?>
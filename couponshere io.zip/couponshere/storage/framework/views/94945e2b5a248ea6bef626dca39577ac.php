<?php if(!empty($siteFaviconUrl)): ?>
<link rel="icon" href="<?php echo e($siteFaviconUrl); ?>" type="image/png" sizes="32x32">
<link rel="icon" href="<?php echo e($siteFaviconUrl); ?>" type="image/png" sizes="192x192">
<link rel="apple-touch-icon" href="<?php echo e($siteFaviconUrl); ?>">
<?php endif; ?>
<?php /**PATH /var/www/couponshere/resources/views/partials/favicon.blade.php ENDPATH**/ ?>
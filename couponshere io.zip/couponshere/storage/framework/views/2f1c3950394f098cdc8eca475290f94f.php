<?php
    $featureSlides = [
        [
            'eyebrow' => 'Why shoppers stay',
            'title' => 'Curated',
            'body' => 'Human-reviewed paths to real savings — fewer dead codes, clearer next steps.',
        ],
        [
            'eyebrow' => 'Why shoppers stay',
            'title' => 'Verified',
            'body' => 'Fresh checks on active offers so you spend less time hunting and more time saving.',
        ],
        [
            'eyebrow' => 'Why shoppers stay',
            'title' => 'Editorial',
            'body' => 'Honest store picks and guides written for shoppers — not just another coupon dump.',
        ],
    ];
?>

<section class="pch-hero">
    <div class="container pch-hero-grid">
        <div class="pch-hero-copy">
            <span class="pch-trust-badge">Deals you can trust</span>
            <h1><?php echo e($siteHomeH1 === ($siteName ?? '') ? 'Save smarter with curated coupons & honest store picks' : $siteHomeH1); ?></h1>
            <p class="pch-hero-subtitle">
                <?php echo e(str_contains($siteHeroSubtitle, 'not affiliated')
                    ? 'Search verified promotions, explore top stores, and read updates from our blog — refreshed often so you never miss a strong offer.'
                    : $siteHeroSubtitle); ?>

            </p>
            <p class="pch-disclosure">
                We may earn a commission when you use our links.
                <a href="<?php echo e(route('pages.disclaimer')); ?>">Read our disclosure</a>.
            </p>
            <form action="<?php echo e(route('search')); ?>" method="GET" class="search-form pch-hero-search">
                <input type="search" name="q" placeholder="Search brands, stores, or offers..." value="<?php echo e(request('q')); ?>" aria-label="Search brands, stores, or offers">
                <button type="submit">Search</button>
            </form>
        </div>

        <div class="pch-feature" data-pch-feature data-autoplay="5000" aria-roledescription="carousel" aria-label="Why shoppers stay">
            <div class="pch-feature-slides">
                <?php $__currentLoopData = $featureSlides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="pch-feature-slide<?php echo e($index === 0 ? ' is-active' : ''); ?>" data-pch-slide <?php if($index !== 0): ?> hidden <?php endif; ?>>
                        <p class="pch-feature-eyebrow"><?php echo e($slide['eyebrow']); ?></p>
                        <h2 class="pch-feature-title"><?php echo e($slide['title']); ?></h2>
                        <p class="pch-feature-body"><?php echo e($slide['body']); ?></p>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="pch-feature-dots" role="tablist" aria-label="Feature slides">
                <?php $__currentLoopData = $featureSlides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button
                        type="button"
                        class="pch-feature-dot<?php echo e($index === 0 ? ' is-active' : ''); ?>"
                        data-pch-dot
                        data-slide-index="<?php echo e($index); ?>"
                        role="tab"
                        aria-label="Slide <?php echo e($index + 1); ?>: <?php echo e($slide['title']); ?>"
                        aria-selected="<?php echo e($index === 0 ? 'true' : 'false'); ?>"
                    ></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /var/www/couponshere/resources/views/themes/prime/home-hero.blade.php ENDPATH**/ ?>
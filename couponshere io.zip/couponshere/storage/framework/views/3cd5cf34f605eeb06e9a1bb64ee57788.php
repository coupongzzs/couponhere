<?php
    /** @var \App\Models\Store $store */
    /** @var \Illuminate\Support\Collection|\App\Models\Coupon[] $coupons */
    $coupons = $coupons ?? collect();
?>
<section class="embedded-coupon-list" data-store-coupons="<?php echo e($store->slug); ?>">
    <?php if($coupons->isEmpty()): ?>
        <p class="embedded-coupon-list__empty">No active coupons for <?php echo e($store->name); ?> right now. Check back soon.</p>
    <?php else: ?>
        <div class="embedded-coupon-list__grid">
            <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials.coupon-card', [
                    'coupon' => $coupon,
                    'showDescription' => false,
                    'openAffiliateOnCopy' => true,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if($showMoreLink ?? true): ?>
            <p class="embedded-coupon-list__more">
                <a href="<?php echo e(route('stores.show', $store->slug)); ?>">View all <?php echo e($store->name); ?> offers →</a>
            </p>
        <?php endif; ?>
    <?php endif; ?>
</section>
<style>
.embedded-coupon-list {
    margin: 1.5rem 0 2rem;
    max-width: 100%;
    min-width: 0;
}
.embedded-coupon-list__grid {
    display: grid;
    gap: 1rem;
    grid-template-columns: minmax(0, 1fr);
}
@media (min-width: 720px) {
    .embedded-coupon-list__grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}
.embedded-coupon-list__more { margin: 1rem 0 0; }
.embedded-coupon-list__empty { margin: 0; color: #64748b; }
body.theme-googlycodes .embedded-coupon-list__empty { color: #1d3557; }
body.theme-googlycodes .embedded-coupon-list__more a { color: #e63946; font-weight: 600; }
</style>
<?php /**PATH /var/www/couponshere/resources/views/partials/embedded-coupon-list.blade.php ENDPATH**/ ?>
<?php
    $publicUrl = route('categories.show', $category->slug);
    $editUrl = $editUrl ?? route('admin.categories.edit', $category);
    $destroyUrl = $destroyUrl ?? route('admin.categories.destroy', $category);
    $deleteConfirm = $deleteConfirm ?? 'Delete category "' . $category->name . '"?';
?>
<div class="table-actions">
    <?php if($category->is_active): ?>
        <a href="<?php echo e($publicUrl); ?>" class="table-action-btn" target="_blank" rel="noopener" title="View public page" aria-label="View public page">
            <?php echo $__env->make('partials.icons.eye', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </a>
    <?php else: ?>
        <span class="table-action-btn is-disabled" title="Category is hidden" aria-label="Category is hidden">
            <?php echo $__env->make('partials.icons.eye', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </span>
    <?php endif; ?>
    <button
        type="button"
        class="table-action-btn js-copy-link"
        data-copy-url="<?php echo e($publicUrl); ?>"
        data-copy-title="Copy category link"
        title="Copy category link"
        aria-label="Copy category link"
    >
        <?php echo $__env->make('partials.icons.copy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </button>
    <a href="<?php echo e($editUrl); ?>" class="table-action-btn" title="Edit category" aria-label="Edit category">
        <?php echo $__env->make('partials.icons.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </a>
    <form action="<?php echo e($destroyUrl); ?>" method="POST" class="table-action-form" onsubmit="return confirm(<?php echo json_encode($deleteConfirm, 15, 512) ?>)">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="table-action-btn table-action-btn-danger" title="Delete category" aria-label="Delete category">
            <?php echo $__env->make('partials.icons.trash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </button>
    </form>
</div>
<?php /**PATH /var/www/couponshere/resources/views/partials/category-table-actions.blade.php ENDPATH**/ ?>
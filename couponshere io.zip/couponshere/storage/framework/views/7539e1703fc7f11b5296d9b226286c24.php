<?php
    $searchValue = $value ?? '';
    $clearUrl = $clearUrl ?? url()->current();
    $hiddenFields = $hiddenFields ?? [];
?>
<form action="<?php echo e($action); ?>" method="GET" class="admin-list-search" data-live-search>
    <?php $__currentLoopData = $hiddenFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $fieldValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(filled($fieldValue)): ?>
            <input type="hidden" name="<?php echo e($name); ?>" value="<?php echo e($fieldValue); ?>">
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="admin-search-field">
        <input
            type="search"
            name="q"
            value="<?php echo e($searchValue); ?>"
            placeholder="<?php echo e($placeholder ?? 'Search…'); ?>"
            maxlength="120"
            autocomplete="off"
            class="admin-search-input"
            data-live-search-input
        >
        <button
            type="button"
            class="admin-search-clear"
            data-live-search-clear
            data-clear-url="<?php echo e($clearUrl); ?>"
            aria-label="Clear search"
            <?php if(! filled($searchValue)): ?> hidden <?php endif; ?>
        >×</button>
    </div>
</form>

<?php if (! $__env->hasRenderedOnce('83ba31bf-74b4-4d4c-9b76-de050877c9e8')): $__env->markAsRenderedOnce('83ba31bf-74b4-4d4c-9b76-de050877c9e8'); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/admin-list-search.js')); ?>?v=<?php echo e(filemtime(public_path('js/admin-list-search.js'))); ?>" defer></script>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /var/www/couponshere/resources/views/partials/admin-list-search.blade.php ENDPATH**/ ?>
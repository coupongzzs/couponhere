<?php $__env->startSection('title', $coupon->seoTitle()); ?>
<?php $__env->startSection('meta_description', $coupon->seoDescription()); ?>
<?php $__env->startSection('og_title', $coupon->store->name.' — '.$coupon->title); ?>
<?php $__env->startSection('og_description', $coupon->seoDescription()); ?>
<?php $__env->startSection('canonical', route('coupons.show', $coupon->slug)); ?>
<?php $__env->startSection('og_url', route('coupons.show', $coupon->slug)); ?>
<?php $__env->startSection('og_type', 'article'); ?>
<?php if($coupon->ogImageUrl()): ?>
<?php $__env->startSection('og_image', $coupon->ogImageUrl()); ?>
<?php endif; ?>
<?php $__env->startSection('og_image_alt', $coupon->store->name); ?>

<?php $__env->startPush('og_meta'); ?>
<?php if($coupon->ogImageUrl()): ?>
<meta property="og:image:secure_url" content="<?php echo e(\App\Support\Seo::absoluteUrl($coupon->ogImageUrl())); ?>">
<?php endif; ?>
<meta property="article:section" content="<?php echo e($coupon->store->category?->name ?? 'Coupons'); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('structured_data'); ?>
<?php echo $__env->make('partials.breadcrumb-schema', ['breadcrumbs' => [
    ['name' => 'Home', 'url' => route('home')],
    ['name' => 'Coupons', 'url' => route('coupons.index')],
    ['name' => $coupon->title, 'url' => route('coupons.show', $coupon->slug)],
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="application/ld+json">
<?php echo json_encode($coupon->structuredData(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE, 512) ?>
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <article class="coupon-detail" <?php if($coupon->code): ?> data-code-reveal <?php endif; ?>>
        <div class="coupon-detail-brand">
            <?php echo $__env->make('partials.store-logo', ['store' => $coupon->store, 'size' => 'lg', 'showName' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <span class="coupon-type"><?php echo e($coupon->typeLabel()); ?></span>
        <?php if($coupon->code): ?>
            <div class="code-box-wrap coupon-detail-code">
                <div class="code-box" id="coupon-code">
                    <?php echo $__env->make('partials.coupon-code-masked', ['coupon' => $coupon], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        <?php endif; ?>
        <div class="badge-lg"><?php echo e($coupon->discountLabelWithStore()); ?></div>
        <h1><?php echo e($coupon->title); ?></h1>
        <p class="coupon-detail-meta">
            <?php if($coupon->store?->category): ?>
                <span class="category-inline"><?php echo $__env->make('partials.category-icon', ['category' => $coupon->store->category, 'size' => 'sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php echo e($coupon->store->category->name); ?></span>
            <?php endif; ?>
        </p>
        <?php if($coupon->description): ?>
            <p style="margin:1rem 0;color:var(--muted);"><?php echo e($coupon->description); ?></p>
        <?php endif; ?>
        <?php if($coupon->expires_at): ?>
            <p><small>Expires: <?php echo e($coupon->expires_at->format('m/d/Y g:i A')); ?></small></p>
        <?php endif; ?>

        <?php echo $__env->make('partials.social-share', [
            'url' => route('coupons.show', $coupon->slug),
            'title' => $coupon->seoTitle(),
            'description' => $coupon->seoDescription(),
            'store' => $coupon->store,
            'label' => 'Share this deal',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if($coupon->code): ?>
            <button type="button" class="btn btn-copy btn-primary" data-reveal-url="<?php echo e(route('coupons.reveal', $coupon->slug)); ?>" data-affiliate-url="<?php echo e($coupon->affiliateClickUrl()); ?>" data-shop-url="<?php echo e(route('coupons.go', $coupon->slug)); ?>" data-coupon-title="<?php echo e($coupon->title); ?>" data-coupon-discount="<?php echo e($coupon->discountLabel()); ?>" data-coupon-store="<?php echo e($coupon->store->name); ?>" data-coupon-expires="<?php echo e($coupon->expiresLabel()); ?>" style="width:100%;margin-bottom:.5rem;">
                Copy Code
            </button>
        <?php endif; ?>

        <a href="<?php echo e(route('coupons.go', $coupon->slug)); ?>" class="btn btn-primary" style="width:100%;padding:.75rem;" target="_blank" rel="noopener">
            Shop Now at <?php echo e($coupon->store->name); ?>

        </a>
        <p class="coupon-trust-note">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z"/></svg>
            Offer listed for <?php echo e($coupon->store->name); ?> on <?php echo e(config('site.name')); ?>. Not affiliated with the merchant. Terms apply on their site.
        </p>
    </article>

    <?php if($related->isNotEmpty()): ?>
    <section class="section">
        <h2 class="section-title">More from <?php echo e($coupon->store->name); ?></h2>
        <div class="coupon-grid">
            <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials.coupon-card', ['coupon' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/coupons/show.blade.php ENDPATH**/ ?>
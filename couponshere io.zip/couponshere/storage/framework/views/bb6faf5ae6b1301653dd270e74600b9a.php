<?php
    $forceBrandText = ($activeTheme ?? '') === 'prime';
    $brandName = !empty($siteDisplayName) ? $siteDisplayName : ($forceBrandText ? ($siteName ?? config('site.name')) : null);
    $showBrandText = !empty($siteBrandShowText) || ($forceBrandText && filled($brandName));
?>
<a href="<?php echo e(route('home')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
    'site-brand',
    'site-brand--logo-only' => ! $showBrandText,
]); ?>">
    <?php if(!empty($siteLogoUrl)): ?>
        <img src="<?php echo e($siteLogoUrl); ?>" alt="<?php echo e($siteName); ?>" class="site-brand-logo">
    <?php else: ?>
        <span class="site-brand-icon">%</span>
    <?php endif; ?>
    <?php if($showBrandText): ?>
        <span class="site-brand-text">
            <?php if(filled($brandName)): ?>
                <strong><?php echo e($brandName); ?><?php echo e($forceBrandText && ! str_ends_with($brandName, '.') ? '.' : ''); ?></strong>
            <?php endif; ?>
            <?php if(!empty($siteDisplayTagline) && ! $forceBrandText): ?>
                <small><?php echo e($siteDisplayTagline); ?></small>
            <?php endif; ?>
        </span>
    <?php endif; ?>
</a>
<?php /**PATH /var/www/couponshere/resources/views/partials/site-brand.blade.php ENDPATH**/ ?>
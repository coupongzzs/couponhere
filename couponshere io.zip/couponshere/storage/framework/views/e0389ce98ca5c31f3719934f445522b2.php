<?php
    $publicUrl = route('coupons.show', $coupon->slug);
    $editUrl = $editUrl ?? route('member.coupons.edit', $coupon);
    $destroyUrl = $destroyUrl ?? route('member.coupons.destroy', $coupon);
    $showCopy = $showCopy ?? true;
    $deleteConfirm = $deleteConfirm ?? 'Delete this coupon?';
?>
<div class="table-actions">
    <?php if($coupon->is_active): ?>
        <a href="<?php echo e($publicUrl); ?>" class="table-action-btn" target="_blank" rel="noopener" title="View public page" aria-label="View public page">
            <?php echo $__env->make('partials.icons.eye', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </a>
    <?php else: ?>
        <span class="table-action-btn is-disabled" title="Coupon is inactive" aria-label="Coupon is inactive">
            <?php echo $__env->make('partials.icons.eye', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </span>
    <?php endif; ?>
    <?php if($showCopy): ?>
        <button
            type="button"
            class="table-action-btn js-copy-link"
            data-copy-url="<?php echo e($publicUrl); ?>"
            data-copy-title="Copy coupon link"
            title="Copy coupon link"
            aria-label="Copy coupon link"
        >
            <?php echo $__env->make('partials.icons.copy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </button>
    <?php endif; ?>
    <a href="<?php echo e($editUrl); ?>" class="table-action-btn" title="Edit coupon" aria-label="Edit coupon">
        <?php echo $__env->make('partials.icons.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </a>
    <form action="<?php echo e($destroyUrl); ?>" method="POST" class="table-action-form" onsubmit="return confirm(<?php echo json_encode($deleteConfirm, 15, 512) ?>)">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="table-action-btn table-action-btn-danger" title="Delete coupon" aria-label="Delete coupon">
            <?php echo $__env->make('partials.icons.trash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </button>
    </form>
</div>
<?php /**PATH /var/www/couponshere/resources/views/partials/coupon-table-actions.blade.php ENDPATH**/ ?>
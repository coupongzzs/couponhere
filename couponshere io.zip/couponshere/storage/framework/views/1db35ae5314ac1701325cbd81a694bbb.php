<?php
    $store = $post->resolveStore();
?>
<?php if($store): ?>
    <div class="sidebar-box blog-store-box">
        <div class="blog-store-box-brand">
            <?php echo $__env->make('partials.store-logo', ['store' => $store, 'size' => 'md', 'showVerified' => false, 'linked' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <h3><?php echo e($store->name); ?></h3>
        </div>
        <p>Browse verified coupon codes and deals for <?php echo e($store->name); ?>.</p>
        <a href="<?php echo e(route('stores.show', $store->slug)); ?>" class="btn btn-outline" style="width:100%;text-align:center;margin-bottom:.5rem;">View <?php echo e($store->name); ?> Coupons</a>
        <?php echo $__env->make('partials.store-shop-cta', ['store' => $store], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php endif; ?>
<?php /**PATH /var/www/couponshere/resources/views/blog/partials/store-box.blade.php ENDPATH**/ ?>
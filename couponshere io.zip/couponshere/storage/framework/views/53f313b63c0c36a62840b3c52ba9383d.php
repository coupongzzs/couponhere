<tr class="affiliate-signup-row<?php echo e(! empty($project['is_registered']) ? ' is-registered' : ''); ?>"
    data-project-id="<?php echo e((int) $project['id']); ?>">
    <td>
        <strong><?php echo e($project['project'] ?: '—'); ?></strong>
        <?php if(! empty($project['is_registered'])): ?>
            <span class="badge badge-success affiliate-signup-status">Đã đăng ký</span>
        <?php endif; ?>
    </td>
    <td>
        <?php if(! empty($project['domain_link'])): ?>
            <a href="<?php echo e($project['domain_link']); ?>" target="_blank" rel="noopener"><?php echo e($project['domain_link']); ?></a>
        <?php else: ?>
            —
        <?php endif; ?>
    </td>
    <td class="small">
        <a href="<?php echo e($project['signup_link']); ?>" target="_blank" rel="noopener" class="affiliate-signup-link"><?php echo e($project['signup_link']); ?></a>
    </td>
    <td><?php echo e($project['category'] ?: '—'); ?></td>
    <td class="small text-muted affiliate-signup-date">
        <?php if(! empty($project['is_registered']) && ! empty($project['registered_at'])): ?>
            <?php echo e($project['registered_at']); ?>

        <?php else: ?>
            <?php echo e($project['created_at'] ?: '—'); ?>

        <?php endif; ?>
    </td>
    <td>
        <?php if(! empty($project['is_registered'])): ?>
            <button type="button" class="btn btn-outline btn-sm" disabled>Đã đăng ký</button>
        <?php else: ?>
            <button type="button"
                class="btn btn-primary btn-sm js-affiliate-signup-register"
                data-id="<?php echo e((int) $project['id']); ?>"
                data-project="<?php echo e($project['project'] ?? ''); ?>"
                data-signup-url="<?php echo e($project['signup_link']); ?>"
                data-register-url="<?php echo e(route('admin.affiliate-signups.register', (int) $project['id'])); ?>">
                Đăng ký
            </button>
        <?php endif; ?>
    </td>
</tr>
<?php /**PATH /var/www/couponshere/resources/views/admin/affiliate-signups/_row.blade.php ENDPATH**/ ?>
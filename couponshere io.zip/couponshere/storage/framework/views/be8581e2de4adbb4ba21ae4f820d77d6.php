<?php $__env->startSection('title', $order->exists ? 'Edit Affiliate Order' : 'Log Affiliate Order'); ?>

<?php $__env->startSection('content'); ?>
<h1 style="margin-bottom:1.5rem;"><?php echo e($order->exists ? 'Edit Affiliate Order' : 'Log Affiliate Order'); ?></h1>

<form method="POST" action="<?php echo e($order->exists ? route('admin.affiliate.orders.update', $order) : route('admin.affiliate.orders.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($order->exists): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <?php if($order->exists): ?>
    <div class="form-group">
        <label>Order Number</label>
        <input type="text" value="<?php echo e($order->order_number); ?>" readonly>
    </div>
    <?php endif; ?>

    <div class="form-group">
        <label for="referrer_user_id">Referrer (affiliate member) *</label>
        <select id="referrer_user_id" name="referrer_user_id" required>
            <option value="">— Select —</option>
            <?php $__currentLoopData = $referrers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referrer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($referrer->id); ?>" <?php if(old('referrer_user_id', $order->referrer_user_id) == $referrer->id): echo 'selected'; endif; ?>>
                    <?php echo e($referrer->name); ?> (<?php echo e($referrer->referral_code); ?>) — <?php echo e($referrer->email); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['referrer_user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="referred_user_id">Registered User (optional)</label>
        <select id="referred_user_id" name="referred_user_id">
            <option value="">— None —</option>
            <?php $__currentLoopData = $referrers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referrer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($referrer->id); ?>" <?php if(old('referred_user_id', $order->referred_user_id) == $referrer->id): echo 'selected'; endif; ?>>
                    <?php echo e($referrer->name); ?> — <?php echo e($referrer->email); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-row">
        <div class="form-group">
            <label for="customer_name">Customer Name</label>
            <input type="text" id="customer_name" name="customer_name" value="<?php echo e(old('customer_name', $order->customer_name)); ?>">
        </div>
        <div class="form-group">
            <label for="customer_email">Customer Email</label>
            <input type="email" id="customer_email" name="customer_email" value="<?php echo e(old('customer_email', $order->customer_email)); ?>">
        </div>
    </div>

    <div class="form-group">
        <label for="description">Description</label>
        <input type="text" id="description" name="description" value="<?php echo e(old('description', $order->description)); ?>" placeholder="e.g. Annual membership">
    </div>

    <div class="form-row">
        <div class="form-group">
            <label for="amount">Order Amount (<?php echo e($currency); ?>) *</label>
            <input type="number" step="0.01" min="0" id="amount" name="amount" value="<?php echo e(old('amount', $order->amount)); ?>" required>
            <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="commission_rate">Commission Rate (%) *</label>
            <input type="number" step="0.01" min="0" max="100" id="commission_rate" name="commission_rate" value="<?php echo e(old('commission_rate', $order->commission_rate)); ?>" required>
        </div>
    </div>

    <div class="form-group">
        <label for="status">Status *</label>
        <select id="status" name="status" required>
            <?php $__currentLoopData = \App\Models\AffiliateOrder::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($status); ?>" <?php if(old('status', $order->status) === $status): echo 'selected'; endif; ?>><?php echo e(ucfirst($status)); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <p class="form-hint">Set to <strong>Paid</strong> after payment is confirmed to credit commission to the referrer's balance.</p>
        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="notes">Admin Notes</label>
        <textarea id="notes" name="notes" rows="3"><?php echo e(old('notes', $order->notes)); ?></textarea>
    </div>

    <?php if($order->exists && $order->commission_credited): ?>
        <p class="form-hint" style="margin-bottom:1rem;">Commission credited: <strong><?php echo e(number_format($order->commission_amount, 2)); ?> <?php echo e($currency); ?></strong></p>
    <?php endif; ?>

    <div style="display:flex;gap:.75rem;">
        <button type="submit" class="btn btn-primary"><?php echo e($order->exists ? 'Update Order' : 'Log Order'); ?></button>
        <a href="<?php echo e(route('admin.affiliate.orders.index')); ?>" class="btn btn-outline">Cancel</a>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/admin/affiliate/orders/form.blade.php ENDPATH**/ ?>
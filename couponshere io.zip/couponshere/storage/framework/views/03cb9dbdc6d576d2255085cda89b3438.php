<?php
    $currentSort = $currentSort ?? 'clicks';
    $currentDir = $currentDir ?? 'desc';
    $isActive = $currentSort === $column;

    if ($column === 'latest' || $column === 'order') {
        $url = request()->fullUrlWithQuery(['sort' => null, 'dir' => null]);
    } else {
        $nextDir = $isActive && $currentDir === 'desc' ? 'asc' : 'desc';
        $url = request()->fullUrlWithQuery(['sort' => $column, 'dir' => $nextDir]);
    }
?>
<th <?php if($isActive): ?> aria-sort="<?php echo e($currentDir === 'asc' ? 'ascending' : 'descending'); ?>" <?php endif; ?>>
    <a href="<?php echo e($url); ?>" class="table-sort-link<?php echo e($isActive ? ' is-active' : ''); ?>">
        <span><?php echo e($label); ?></span>
        <?php if($isActive && ! in_array($column, ['latest', 'order'], true)): ?>
            <span class="table-sort-indicator" aria-hidden="true"><?php echo e($currentDir === 'desc' ? '↓' : '↑'); ?></span>
        <?php endif; ?>
    </a>
</th>
<?php /**PATH /var/www/couponshere/resources/views/partials/table-sort-th.blade.php ENDPATH**/ ?>
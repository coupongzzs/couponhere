<?php $__env->startSection('title', $author->name . ' — Author at ' . config('site.name')); ?>
<?php $__env->startSection('meta_description', Str::limit($author->bio ?: "Articles by {$author->name} at " . config('site.name'), 160)); ?>
<?php $__env->startSection('canonical', $author->url()); ?>

<?php $__env->startPush('structured_data'); ?>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "ProfilePage",
    "mainEntity": {
        "@type": "Person",
        "name": <?php echo json_encode($author->name, 15, 512) ?>,
        "description": <?php echo json_encode($author->bio, 15, 512) ?>,
        "jobTitle": <?php echo json_encode($author->title, 15, 512) ?>,
        "url": <?php echo json_encode($author->url(), 15, 512) ?>
    }
}
</script>
<?php echo $__env->make('partials.breadcrumb-schema', ['breadcrumbs' => [
    ['name' => 'Home', 'url' => route('home')],
    ['name' => 'Authors', 'url' => route('authors.index')],
    ['name' => $author->name, 'url' => $author->url()],
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="author-profile-hero">
    <div class="container">
        <a href="<?php echo e(route('authors.index')); ?>" class="blog-back">← All Authors</a>
        <div class="author-profile-header">
            <div class="author-profile-avatar" aria-hidden="true">
                <?php if($author->avatarUrl): ?>
                    <img src="<?php echo e($author->avatarUrl); ?>" alt="<?php echo e($author->name); ?>">
                <?php else: ?>
                    <?php echo e($author->initials()); ?>

                <?php endif; ?>
            </div>
            <div>
                <h1><?php echo e($author->name); ?></h1>
                <?php if($author->title): ?>
                    <p class="author-profile-title"><?php echo e($author->title); ?></p>
                <?php endif; ?>
                <?php if($author->bio): ?>
                    <p class="author-profile-bio"><?php echo e($author->bio); ?></p>
                <?php endif; ?>
                <p class="author-profile-meta"><?php echo e($author->publishedPostCount()); ?> published articles on <?php echo e(config('site.name')); ?></p>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <h2 class="section-title">Articles by <?php echo e($author->name); ?></h2>

        <?php if($posts->isEmpty()): ?>
            <p class="blog-empty">No published articles yet.</p>
        <?php else: ?>
            <div class="blog-grid">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('blog.partials.card', ['post' => $post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="pagination"><?php echo e($posts->links()); ?></div>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/authors/show.blade.php ENDPATH**/ ?>
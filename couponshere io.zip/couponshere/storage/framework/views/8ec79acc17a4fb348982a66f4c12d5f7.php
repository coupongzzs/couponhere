<?php ($author = $post->authorProfile()); ?>
<a href="<?php echo e($author->url()); ?>" class="author-link">
    <span class="author-avatar" aria-hidden="true">
        <?php if($author->avatarUrl): ?>
            <img src="<?php echo e($author->avatarUrl); ?>" alt="">
        <?php else: ?>
            <?php echo e($author->initials()); ?>

        <?php endif; ?>
    </span>
    <span><?php echo e($author->name); ?></span>
</a>
<?php /**PATH /var/www/couponshere/resources/views/blog/partials/author-link.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'My Coupons'); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;">
    <h1>My Coupons &amp; Deals</h1>
    <a href="<?php echo e(route('member.coupons.create')); ?>" class="btn btn-primary">+ Add Coupon</a>
</div>

<?php echo $__env->make('partials.coupon-index-filters', ['action' => route('member.coupons.index'), 'stores' => $stores], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<table class="admin-table">
    <thead>
        <tr>
            <th>Title</th>
            <th>Store</th>
            <th>Code</th>
            <th>Type</th>
            <th>On /coupons</th>
            <th>Status</th>
            <th>Clicks</th>
            <th class="table-actions-col">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($coupon->title); ?></td>
                <td><?php echo e($coupon->store?->name); ?></td>
                <td><code><?php echo e($coupon->code ?? '—'); ?></code></td>
                <td><?php echo e($coupon->typeLabel()); ?></td>
                <td><?php echo e($coupon->show_on_coupons ? 'Yes' : 'No'); ?></td>
                <td><?php echo e($coupon->is_active ? 'Active' : 'Inactive'); ?></td>
                <td><strong><?php echo e(number_format($coupon->click_count)); ?></strong></td>
                <td>
                    <?php echo $__env->make('partials.coupon-table-actions', ['coupon' => $coupon], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="8">
                    <?php if(request()->hasAny(['title', 'store_id'])): ?>
                        No coupons match your search.
                    <?php else: ?>
                        No coupons yet. <a href="<?php echo e(route('member.coupons.create')); ?>">Create one</a> (add a store first if needed).
                    <?php endif; ?>
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php echo e($coupons->links()); ?>


<?php echo $__env->make('partials.table-actions-assets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/member/coupons/index.blade.php ENDPATH**/ ?>
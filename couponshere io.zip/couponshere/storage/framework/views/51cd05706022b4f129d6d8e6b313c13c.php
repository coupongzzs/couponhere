<?php
    $category = $category ?? null;
    $class = $class ?? '';
    $fallback = $fallback ?? '🏷️';
    $size = $size ?? 'md';
    $iconUrl = $category?->iconUrl();
    $emoji = $category?->iconEmoji();
?>
<?php if($iconUrl): ?>
    <img src="<?php echo e($iconUrl); ?>" alt="" class="category-icon category-icon--img category-icon--<?php echo e($size); ?> <?php echo e($class); ?>" loading="lazy">
<?php elseif($emoji): ?>
    <span class="category-icon category-icon--emoji category-icon--<?php echo e($size); ?> <?php echo e($class); ?>" aria-hidden="true"><?php echo e($emoji); ?></span>
<?php else: ?>
    <span class="category-icon category-icon--emoji category-icon--<?php echo e($size); ?> <?php echo e($class); ?>" aria-hidden="true"><?php echo e($fallback); ?></span>
<?php endif; ?>
<?php /**PATH /var/www/couponshere/resources/views/partials/category-icon.blade.php ENDPATH**/ ?>
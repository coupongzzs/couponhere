<?php $__env->startSection('title', $post->exists ? 'Edit Post' : 'New Post'); ?>

<?php $__env->startSection('content'); ?>
<h1 style="margin-bottom:1.5rem;"><?php echo e($post->exists ? 'Edit' : 'Create'); ?> Blog Post</h1>
<form method="POST" enctype="multipart/form-data" action="<?php echo e($post->exists ? route('member.posts.update', $post) : route('member.posts.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($post->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <div class="form-group">
        <label>Title *</label>
        <input type="text" name="title" value="<?php echo e(old('title', $post->title)); ?>" required>
    </div>
    <div class="form-group">
        <label>Excerpt (summary for listings &amp; SEO)</label>
        <textarea name="excerpt" rows="2" maxlength="500"><?php echo e(old('excerpt', $post->excerpt)); ?></textarea>
    </div>
    <?php echo $__env->make('partials.ckeditor-editor', [
        'editorId' => 'member-post-content',
        'fieldName' => 'content',
        'value' => $post->content,
        'label' => 'Content *',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h3 style="margin:1.5rem 0 .75rem;">SEO</h3>
    <div class="form-group">
        <label>Meta title (max 70 chars)</label>
        <input type="text" name="meta_title" value="<?php echo e(old('meta_title', $post->meta_title)); ?>" maxlength="70">
    </div>
    <div class="form-group">
        <label>Meta description (max 320 chars)</label>
        <textarea name="meta_description" rows="2" maxlength="320"><?php echo e(old('meta_description', $post->meta_description)); ?></textarea>
    </div>
    <div class="form-group">
        <label>Featured image</label>
        <?php if($post->featuredImageUrl()): ?>
            <div class="admin-image-preview">
                <img src="<?php echo e($post->featuredImageUrl()); ?>" alt="<?php echo e($post->title); ?>" class="admin-preview-img admin-preview-img--blog">
            </div>
        <?php endif; ?>
        <input type="file" name="featured_image_file" accept="image/*" style="margin-top:.5rem;">
        <p class="form-hint">Upload JPG, PNG or WebP (max 5MB). Or paste an image URL below.</p>
        <input type="url" name="featured_image" value="<?php echo e(old('featured_image', $post->hasStoredFeaturedImage() ? '' : $post->featured_image)); ?>" placeholder="https://example.com/image.jpg" style="margin-top:.5rem;">
    </div>
    <div class="form-group">
        <label>Publish date</label>
        <input type="datetime-local" name="published_at" value="<?php echo e(old('published_at', $post->published_at?->format('Y-m-d\TH:i'))); ?>">
    </div>
    <div class="form-check">
        <input type="checkbox" name="is_published" value="1" id="published" <?php if(old('is_published', $post->is_published)): echo 'checked'; endif; ?>>
        <label for="published">Published</label>
    </div>
    <?php if($post->exists): ?>
        <p class="form-hint" style="margin-top:1rem;">Article views: <strong><?php echo e(number_format($post->view_count)); ?></strong></p>
    <?php endif; ?>
    <button type="submit" class="btn btn-primary" style="margin-top:1rem;">Save Post</button>
    <a href="<?php echo e(route('member.posts.index')); ?>" class="btn btn-outline">Cancel</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/member/posts/form.blade.php ENDPATH**/ ?>
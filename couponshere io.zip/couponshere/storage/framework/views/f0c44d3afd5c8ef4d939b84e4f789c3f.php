<?php ($author = $post->authorProfile()); ?>
<div class="author-box">
    <a href="<?php echo e($author->url()); ?>" class="author-box-avatar" aria-hidden="true">
        <?php if($author->avatarUrl): ?>
            <img src="<?php echo e($author->avatarUrl); ?>" alt="<?php echo e($author->name); ?>">
        <?php else: ?>
            <?php echo e($author->initials()); ?>

        <?php endif; ?>
    </a>
    <div class="author-box-copy">
        <span class="author-box-label">Written by</span>
        <a href="<?php echo e($author->url()); ?>" class="author-box-name"><?php echo e($author->name); ?></a>
        <?php if($author->title): ?>
            <p class="author-box-title"><?php echo e($author->title); ?></p>
        <?php endif; ?>
        <?php if($author->bio): ?>
            <p class="author-box-bio"><?php echo e(Str::limit($author->bio, 180)); ?></p>
        <?php endif; ?>
        <a href="<?php echo e($author->url()); ?>" class="author-box-more">View author profile →</a>
    </div>
</div>
<?php /**PATH /var/www/couponshere/resources/views/blog/partials/author-box.blade.php ENDPATH**/ ?>
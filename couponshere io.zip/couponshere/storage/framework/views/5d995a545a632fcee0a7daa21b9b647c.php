<?php
    use App\Support\Seo;

    $shareStore = $store ?? null;
    $shareUrl = $url ?? url()->current();
    $shareTitle = $title ?? ($shareStore?->seoTitle()) ?? config('site.name');
    $shareDescription = $description ?? ($shareStore?->seoDescription()) ?? config('site.default_description');
    $shareImage = $image ?? ($shareStore?->ogImageUrl());
    $shareLabel = $label ?? 'Share';
    $shareMeta = $shareStore?->shareMeta();

    $shareSummaryParts = array_filter([
        $shareTitle,
        $shareDescription !== $shareTitle ? $shareDescription : null,
    ]);
    if ($shareMeta) {
        $storeFacts = array_filter([
            $shareMeta['category'] ?? null,
            ($shareMeta['coupon_count'] ?? 0) > 0
                ? $shareMeta['coupon_count'].' active '.str('coupon')->plural($shareMeta['coupon_count'])
                : null,
            $shareMeta['website_label'] ?? null,
        ]);
        if ($storeFacts !== []) {
            $shareSummaryParts[] = implode(' · ', $storeFacts);
        }
    }
    $shareSummaryParts[] = $shareUrl;
    $shareText = implode("\n\n", $shareSummaryParts);

    $encodedUrl = rawurlencode($shareUrl);
    $encodedTitle = rawurlencode($shareTitle);
    $encodedText = rawurlencode($shareText);
    $encodedWhatsApp = rawurlencode($shareText);
    $shareImageAbsolute = $shareImage ? Seo::absoluteUrl($shareImage) : null;
?>

<div class="social-share<?php echo e(!empty($compact) ? ' social-share--compact' : ''); ?><?php echo e($shareStore ? ' social-share--with-preview' : ''); ?>" data-social-share>
    <?php if($shareStore): ?>
        <div class="social-share-preview">
            <div class="social-share-preview-media">
                <?php echo $__env->make('partials.store-logo', ['store' => $shareStore, 'size' => 'md', 'linked' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="social-share-preview-body">
                <strong class="social-share-preview-title"><?php echo e($shareStore->name); ?></strong>
                <?php if($shareMeta): ?>
                    <p class="social-share-preview-meta">
                        <?php if(!empty($shareMeta['category'])): ?>
                            <span><?php echo e($shareMeta['category']); ?></span>
                        <?php endif; ?>
                        <?php if(($shareMeta['coupon_count'] ?? 0) > 0): ?>
                            <span><?php echo e($shareMeta['coupon_count']); ?> active <?php echo e(str('coupon')->plural($shareMeta['coupon_count'])); ?></span>
                        <?php endif; ?>
                        <?php if(!empty($shareMeta['website_label'])): ?>
                            <span><?php echo e($shareMeta['website_label']); ?></span>
                        <?php endif; ?>
                    </p>
                <?php endif; ?>
                <p class="social-share-preview-desc"><?php echo e(\Illuminate\Support\Str::limit(strip_tags($shareDescription), 140)); ?></p>
            </div>
        </div>
    <?php elseif($shareImageAbsolute): ?>
        <div class="social-share-preview social-share-preview--image-only">
            <img src="<?php echo e($shareImageAbsolute); ?>" alt="" class="social-share-preview-img" loading="lazy">
            <div class="social-share-preview-body">
                <strong class="social-share-preview-title"><?php echo e($shareTitle); ?></strong>
                <?php if($shareDescription): ?>
                    <p class="social-share-preview-desc"><?php echo e(\Illuminate\Support\Str::limit(strip_tags($shareDescription), 140)); ?></p>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <span class="social-share-label"><?php echo e($shareLabel); ?></span>
    <div class="social-share-buttons" role="group" aria-label="<?php echo e($shareLabel); ?>">
        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($encodedUrl); ?>&quote=<?php echo e($encodedTitle); ?>"
            class="social-share-btn social-share-btn--facebook"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Share on Facebook">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073c0 6.02 4.388 11.012 10.125 11.908v-8.42H7.078v-3.488h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.234 2.686.234v2.953h-1.513c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.488h-2.796v8.42C19.612 23.085 24 18.093 24 12.073z"/></svg>
        </a>
        <a href="https://twitter.com/intent/tweet?url=<?php echo e($encodedUrl); ?>&text=<?php echo e($encodedTitle); ?>"
            class="social-share-btn social-share-btn--x"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Share on X">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
        </a>
        <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo e($encodedUrl); ?>"
            class="social-share-btn social-share-btn--linkedin"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Share on LinkedIn">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
        </a>
        <a href="https://wa.me/?text=<?php echo e($encodedWhatsApp); ?>"
            class="social-share-btn social-share-btn--whatsapp"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Share on WhatsApp">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.435 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
        </a>
        <button type="button"
            class="social-share-btn social-share-btn--copy"
            data-share-copy="<?php echo e($shareUrl); ?>"
            data-share-text='<?php echo json_encode($shareText, 15, 512) ?>'
            aria-label="Copy link">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
        </button>
        <button type="button"
            class="social-share-btn social-share-btn--native"
            data-share-native
            data-share-title='<?php echo json_encode($shareTitle, 15, 512) ?>'
            data-share-text='<?php echo json_encode($shareText, 15, 512) ?>'
            data-share-url='<?php echo json_encode($shareUrl, 15, 512) ?>'
            hidden
            aria-label="Share">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92-1.31-2.92-2.92-2.92z"/></svg>
        </button>
    </div>
</div>
<?php /**PATH /var/www/couponshere/resources/views/partials/social-share.blade.php ENDPATH**/ ?>
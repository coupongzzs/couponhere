<?php if(isset($paginator) && $paginator instanceof \Illuminate\Contracts\Pagination\Paginator): ?>
    <?php if($paginator->previousPageUrl()): ?>
        <link rel="prev" href="<?php echo e($paginator->previousPageUrl()); ?>">
    <?php endif; ?>
    <?php if($paginator->hasMorePages()): ?>
        <link rel="next" href="<?php echo e($paginator->nextPageUrl()); ?>">
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH /var/www/couponshere/resources/views/partials/pagination-seo.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Tracking Scripts'); ?>

<?php $__env->startSection('content'); ?>
<h1 style="margin-bottom:.5rem;">Tracking Scripts</h1>
<p style="color:#64748b;margin-bottom:2rem;">
    Manage Google tag and per-page conversion tracking for the public site.
</p>

<form action="<?php echo e(route('admin.tracking.update')); ?>" method="POST" id="tracking-form">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="tracking-section">
        <h2>Global tag (all public pages)</h2>
        <p class="form-hint" style="margin-bottom:.75rem;">
            Paste your Google tag (gtag.js) snippet. Injected immediately after <code>&lt;head&gt;</code> on every public page.
        </p>
        <div class="form-group">
            <label for="tracking_head">Google tag snippet</label>
            <textarea
                id="tracking_head"
                name="tracking_head"
                rows="12"
                class="tracking-code-input"
                placeholder="<!-- Google tag (gtag.js) -->&#10;&lt;script async src=&quot;https://www.googletagmanager.com/gtag/js?id=AW-XXXXXXXX&quot;&gt;&lt;/script&gt;&#10;..."
            ><?php echo e(old('tracking_head', $trackingHead)); ?></textarea>
            <?php $__errorArgs = ['tracking_head'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="tracking-section">
        <div class="tracking-section-head">
            <div>
                <h2>Conversion events (per page)</h2>
                <p class="form-hint" style="margin:.35rem 0 0;">
                    Add one row per page or section. Each row has its own page link and conversion snippet.
                    Use <code>/</code> for homepage, <code>/coupons/*</code> for all coupon pages, or an exact path like <code>/stores/jennibag</code>.
                </p>
            </div>
            <button type="button" class="btn btn-outline" id="add-conversion-rule">+ Add page</button>
        </div>

        <div id="conversion-rules-list" class="conversion-rules-list">
            <?php ($rules = old('conversion_rules', $conversionRules)); ?>
            <?php $__currentLoopData = $rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('admin.tracking.partials.conversion-rule-row', ['index' => $index, 'rule' => $rule], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php $__errorArgs = ['conversion_rules'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['conversion_rules.*.path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['conversion_rules.*.html'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div style="display:flex;gap:.75rem;flex-wrap:wrap;">
        <button type="submit" class="btn btn-primary">Save Scripts</button>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-outline" target="_blank" rel="noopener">View public site →</a>
    </div>
</form>

<template id="conversion-rule-template">
    <?php echo $__env->make('admin.tracking.partials.conversion-rule-row', ['index' => '__INDEX__', 'rule' => ['path' => '', 'html' => '']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</template>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.tracking-section {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 1.25rem 1.35rem;
    margin-bottom: 1.25rem;
}
.tracking-section h2 {
    margin: 0 0 .35rem;
    font-size: 1.05rem;
}
.tracking-section-head {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 1rem;
    margin-bottom: 1rem;
}
.tracking-code-input {
    width: 100%;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: .85rem;
    line-height: 1.45;
    padding: .85rem 1rem;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    background: #0f172a;
    color: #e2e8f0;
    resize: vertical;
    min-height: 180px;
}
.tracking-code-input--compact {
    min-height: 140px;
}
.tracking-code-input:focus {
    outline: 2px solid var(--primary);
    outline-offset: 1px;
}
.conversion-rules-list {
    display: grid;
    gap: 1rem;
}
.conversion-rule-row {
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 1rem;
    background: #f8fafc;
}
.conversion-rule-row-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: .75rem;
    margin-bottom: .75rem;
}
.conversion-rule-row-head strong {
    font-size: .92rem;
}
.conversion-rule-path {
    width: 100%;
    padding: .55rem .7rem;
    border: 1px solid var(--border);
    border-radius: 8px;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: .88rem;
    margin-bottom: .65rem;
}
.form-hint code {
    font-size: .82em;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(() => {
    const list = document.getElementById('conversion-rules-list');
    const template = document.getElementById('conversion-rule-template');
    const addBtn = document.getElementById('add-conversion-rule');
    let nextIndex = list.querySelectorAll('.conversion-rule-row').length;

    addBtn.addEventListener('click', () => {
        const html = template.innerHTML.replaceAll('__INDEX__', String(nextIndex++));
        list.insertAdjacentHTML('beforeend', html);
        renumberRows();
    });

    list.addEventListener('click', (event) => {
        if (!event.target.classList.contains('remove-conversion-rule')) {
            return;
        }

        const rows = list.querySelectorAll('.conversion-rule-row');
        if (rows.length <= 1) {
            const row = rows[0];
            row.querySelector('.conversion-rule-path').value = '';
            row.querySelector('.tracking-code-input').value = '';
            return;
        }

        event.target.closest('.conversion-rule-row').remove();
        renumberRows();
    });

    function renumberRows() {
        list.querySelectorAll('.conversion-rule-row').forEach((row, index) => {
            row.querySelector('.conversion-rule-number').textContent = index + 1;
            row.querySelectorAll('[name]').forEach((input) => {
                input.name = input.name.replace(/conversion_rules\[\d+\]/, `conversion_rules[${index}]`);
            });
        });
        nextIndex = list.querySelectorAll('.conversion-rule-row').length;
    }
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/admin/tracking/index.blade.php ENDPATH**/ ?>
<?php if(!empty($scrollPopup) && !empty($scrollPopup['coupons'])): ?>
<div class="scroll-coupon-popup" id="scroll-coupon-popup" hidden aria-hidden="true">
    <div class="scroll-coupon-popup-backdrop" data-scroll-popup-close></div>
    <div class="scroll-coupon-popup-dialog" role="dialog" aria-modal="true" aria-labelledby="scroll-coupon-popup-title">
        <button type="button" class="scroll-coupon-popup-close" data-scroll-popup-close aria-label="Close">&times;</button>

        <div class="scroll-coupon-popup-header">
            <?php if(!empty($scrollPopup['storeLogo'])): ?>
                <img src="<?php echo e($scrollPopup['storeLogo']); ?>" alt="<?php echo e($scrollPopup['storeName']); ?>" class="scroll-coupon-popup-logo" width="56" height="56">
            <?php endif; ?>
            <div>
                <span class="scroll-coupon-popup-badge">Exclusive Offers</span>
                <h2 class="scroll-coupon-popup-title" id="scroll-coupon-popup-title">
                    <?php echo e($scrollPopup['storeName']); ?> Coupons
                </h2>
                <p class="scroll-coupon-popup-subtitle">Save with these verified promo codes</p>
            </div>
        </div>

        <ul class="scroll-coupon-popup-list">
            <?php $__currentLoopData = $scrollPopup['coupons']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="scroll-coupon-popup-item" <?php if(!empty($coupon['hasCode'])): ?> data-code-reveal <?php endif; ?>>
                    <div class="scroll-coupon-popup-item-main">
                        <?php if(!empty($coupon['hasCode']) || !empty($coupon['discount'])): ?>
                            <div class="scroll-coupon-popup-offer-meta">
                                <?php if(!empty($coupon['hasCode']) && !empty($coupon['codeMasked'])): ?>
                                    <span class="scroll-coupon-popup-code-preview">
                                        <span class="coupon-code-masked" data-masked-code>
                                            <span class="coupon-code-visible"><?php echo e($coupon['codeMasked']['visible']); ?></span><span class="coupon-code-blur"><?php echo e($coupon['codeMasked']['hidden']); ?></span>
                                        </span>
                                    </span>
                                <?php endif; ?>
                                <?php if(!empty($coupon['discount'])): ?>
                                    <span class="scroll-coupon-popup-discount"><?php echo e($coupon['discount']); ?></span>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <div>
                            <strong class="scroll-coupon-popup-item-title"><?php echo e($coupon['title']); ?></strong>
                            <?php if(!empty($coupon['expires'])): ?>
                                <span class="scroll-coupon-popup-expires"><?php echo e($coupon['expires']); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="scroll-coupon-popup-item-action">
                        <?php if(!empty($coupon['hasCode'])): ?>
                            <div class="scroll-coupon-popup-code">
                                <button type="button"
                                    class="scroll-coupon-popup-copy"
                                    data-reveal-url="<?php echo e($coupon['revealUrl']); ?>"
                                    data-go-url="<?php echo e($coupon['goUrl']); ?>"
                                    data-shop-url="<?php echo e($coupon['goUrl']); ?>"
                                    data-affiliate-url="<?php echo e($coupon['affiliateUrl'] ?? $scrollPopup['affiliateUrl']); ?>"
                                    data-coupon-title="<?php echo e($coupon['title']); ?>"
                                    data-coupon-discount="<?php echo e($coupon['discount'] ?? ''); ?>"
                                    data-coupon-store="<?php echo e($scrollPopup['storeName']); ?>"
                                    data-coupon-expires="<?php echo e($coupon['expires'] ?? ''); ?>">
                                    Copy Code
                                </button>
                            </div>
                        <?php else: ?>
                            <button type="button"
                                class="btn btn-primary scroll-coupon-popup-deal"
                                data-scroll-popup-deal
                                data-open-url="<?php echo e($coupon['goUrl']); ?>">
                                Get Deal
                            </button>
                        <?php endif; ?>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <button type="button"
            class="btn btn-primary scroll-coupon-popup-shop"
            data-scroll-popup-deal
            data-open-url="<?php echo e($scrollPopup['affiliateUrl']); ?>">
            Shop at <?php echo e($scrollPopup['storeName']); ?>

        </button>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    window.__scrollCouponPopup = <?php echo json_encode($scrollPopup, 15, 512) ?>;
</script>
<script src="<?php echo e(asset('js/scroll-coupon-popup.js')); ?>?v=<?php echo e(filemtime(public_path('js/scroll-coupon-popup.js'))); ?>"></script>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /var/www/couponshere/resources/views/partials/scroll-coupon-popup.blade.php ENDPATH**/ ?>
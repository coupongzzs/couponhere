<?php
    $ads = $adsSettings
        ?? ($selectedStore ? $adsExport->defaultsForStore($selectedStore) : $adsExport->emptyDefaults());
    $singleMode = ($ads['ad_group_mode'] ?? 'brand_and_products') === 'single';
?>
<div class="import-card" id="google-ads-settings">
    <h2>Google Ads export</h2>
    <p class="form-hint" style="margin-bottom:1rem;">
        Configure standard Search keyword columns for Google Ads Editor CSV import:
        Campaign, Ad Group, Keyword, Criterion Type, Max CPC, Final URL, Status.
    </p>

    <div class="keyword-ads-grid">
        <div class="form-group">
            <label for="campaign_name">Campaign name</label>
            <input type="text" id="campaign_name" name="campaign_name" maxlength="120"
                value="<?php echo e(old('campaign_name', $ads['campaign_name'] ?? '')); ?>"
                placeholder="MoveSpeed - Search Coupons">
        </div>

        <div class="form-group">
            <label for="final_url">Final URL</label>
            <input type="url" id="final_url" name="final_url" maxlength="500"
                value="<?php echo e(old('final_url', $ads['final_url'] ?? '')); ?>"
                placeholder="https://example.com/store/movespeed">
            <p class="form-hint">Landing page for all keywords. Defaults to the store affiliate or public page.</p>
        </div>

        <div class="form-group">
            <label for="ad_group_mode">Ad group structure</label>
            <select id="ad_group_mode" name="ad_group_mode">
                <option value="brand_and_products" <?php if(old('ad_group_mode', $ads['ad_group_mode'] ?? '') === 'brand_and_products'): echo 'selected'; endif; ?>>
                    Brand ad group + one ad group per product
                </option>
                <option value="single" <?php if(old('ad_group_mode', $ads['ad_group_mode'] ?? '') === 'single'): echo 'selected'; endif; ?>>
                    Single ad group for all keywords
                </option>
            </select>
        </div>

        <div class="form-group" id="single-ad-group-wrap" <?php if(! $singleMode): ?> hidden <?php endif; ?>>
            <label for="ad_group_name">Ad group name</label>
            <input type="text" id="ad_group_name" name="ad_group_name" maxlength="120"
                value="<?php echo e(old('ad_group_name', $ads['ad_group_name'] ?? 'All Keywords')); ?>">
        </div>

        <div class="form-group" id="brand-ad-group-wrap" <?php if($singleMode): ?> hidden <?php endif; ?>>
            <label for="brand_ad_group_suffix">Brand ad group suffix</label>
            <input type="text" id="brand_ad_group_suffix" name="brand_ad_group_suffix" maxlength="80"
                value="<?php echo e(old('brand_ad_group_suffix', $ads['brand_ad_group_suffix'] ?? 'Brand')); ?>">
            <p class="form-hint">Example: <code>MoveSpeed - Brand</code></p>
        </div>

        <div class="form-group">
            <label for="match_type">Match type</label>
            <select id="match_type" name="match_type">
                <?php $__currentLoopData = $adsExport::MATCH_TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($type); ?>" <?php if(old('match_type', $ads['match_type'] ?? 'Phrase') === $type): echo 'selected'; endif; ?>><?php echo e($type); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="keyword_status">Keyword status</label>
            <select id="keyword_status" name="keyword_status">
                <?php $__currentLoopData = $adsExport::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php if(old('keyword_status', $ads['keyword_status'] ?? 'Enabled') === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="max_cpc">Max CPC (optional)</label>
            <div class="keyword-cpc-field">
                <span class="keyword-cpc-symbol" id="max_cpc_symbol" aria-hidden="true">$</span>
                <input type="text" id="max_cpc" name="max_cpc" maxlength="20"
                    value="<?php echo e(old('max_cpc', $ads['max_cpc'] ?? '')); ?>"
                    placeholder="1.50"
                    inputmode="decimal"
                    autocomplete="off">
                <select id="max_cpc_currency" name="max_cpc_currency" class="keyword-cpc-currency" aria-label="Max CPC currency">
                    <?php $__currentLoopData = $adsExport::CPC_CURRENCIES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($currency); ?>" <?php if(old('max_cpc_currency', $ads['max_cpc_currency'] ?? 'USD') === $currency): echo 'selected'; endif; ?>>
                            <?php echo e($currency === 'USD' ? 'USD ($)' : 'VND (₫)'); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <p class="form-hint">Leave blank to use the ad group default bid in Google Ads. CSV exports the numeric bid only (no currency symbol).</p>
        </div>
    </div>

    <label class="form-check keyword-ads-check">
        <input type="checkbox" name="all_match_types" value="1" <?php if(old('all_match_types', $ads['all_match_types'] ?? false)): echo 'checked'; endif; ?>>
        Export Broad, Phrase, and Exact rows for each keyword (3× rows)
    </label>
</div>
<?php /**PATH /var/www/couponshere/resources/views/member/keywords/partials/ads-settings.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Affiliate Orders'); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;flex-wrap:wrap;gap:.75rem;">
    <h1>Affiliate Orders</h1>
    <a href="<?php echo e(route('member.affiliate.index')); ?>" class="btn btn-outline">← Back to Referral Program</a>
</div>

<table class="admin-table">
    <thead>
        <tr>
            <th>Order</th>
            <th>Customer</th>
            <th>Description</th>
            <th>Amount</th>
            <th>Rate</th>
            <th>Commission</th>
            <th>Status</th>
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><code><?php echo e($order->order_number); ?></code></td>
            <td>
                <?php echo e($order->customer_name ?: ($order->referredUser?->name ?: '—')); ?>

                <?php if($order->customer_email): ?>
                    <br><small style="color:var(--muted);"><?php echo e($order->customer_email); ?></small>
                <?php endif; ?>
            </td>
            <td><?php echo e($order->description ?: '—'); ?></td>
            <td><?php echo e(number_format($order->amount, 2)); ?> <?php echo e($currency); ?></td>
            <td><?php echo e(number_format($order->commission_rate, 0)); ?>%</td>
            <td>
                <?php if($order->commission_credited): ?>
                    <?php echo e(number_format($order->commission_amount, 2)); ?> <?php echo e($currency); ?>

                <?php else: ?>
                    —
                <?php endif; ?>
            </td>
            <td><?php echo e($order->statusLabel()); ?></td>
            <td><?php echo e($order->created_at->format('M j, Y')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="8">No orders attributed to your referral link yet.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php echo e($orders->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/member/affiliate/orders.blade.php ENDPATH**/ ?>
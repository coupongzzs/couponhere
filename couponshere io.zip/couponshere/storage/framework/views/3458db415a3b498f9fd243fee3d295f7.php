<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
<div class="admin-page-header">
    <h1>Categories</h1>
    <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary">+ Add Category</a>
</div>

<p class="form-hint" style="margin-bottom:1.25rem;">
    Categories group stores on the public site. Each store belongs to one category.
</p>

<?php if($categories->isEmpty()): ?>
    <div class="import-card">
        <p style="margin:0;">No categories yet. <a href="<?php echo e(route('admin.categories.create')); ?>">Create the first category</a>.</p>
    </div>
<?php else: ?>
    <table class="admin-table">
        <thead>
            <tr>
                <th>Icon</th>
                <th>Name</th>
                <th>Slug</th>
                <th>Stores</th>
                <th>Coupons</th>
                <th>Order</th>
                <th>Status</th>
                <th class="table-actions-col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo $__env->make('partials.category-icon', ['category' => $category, 'size' => 'md'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                    <td><strong><?php echo e($category->name); ?></strong></td>
                    <td><code><?php echo e($category->slug); ?></code></td>
                    <td><?php echo e($category->stores_count); ?></td>
                    <td><?php echo e($category->coupons_count); ?></td>
                    <td><?php echo e($category->sort_order); ?></td>
                    <td>
                        <?php if($category->is_active): ?>
                            <span class="badge badge-success">Active</span>
                        <?php else: ?>
                            <span class="badge badge-muted">Hidden</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo $__env->make('partials.category-table-actions', ['category' => $category], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($categories->links()); ?>

<?php endif; ?>

<?php echo $__env->make('partials.table-actions-assets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.admin-page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 1rem;
    margin-bottom: 1.5rem;
}
.admin-page-header h1 { margin: 0; }
.badge {
    display: inline-block;
    padding: .2rem .5rem;
    border-radius: 4px;
    font-size: .75rem;
    font-weight: 600;
}
.badge-success { background: #dcfce7; color: #166534; }
.badge-muted { background: #f3f4f6; color: #6b7280; }
.import-card {
    background: var(--card, #fff);
    border: 1px solid var(--border, #e5e7eb);
    border-radius: 8px;
    padding: 1.25rem 1.5rem;
}
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/admin/categories/index.blade.php ENDPATH**/ ?>
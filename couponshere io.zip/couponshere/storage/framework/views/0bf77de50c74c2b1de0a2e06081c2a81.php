<?php
    $publicUrl = route('blog.show', $post->slug);
    $editUrl = $editUrl ?? route('member.posts.edit', $post);
    $destroyUrl = $destroyUrl ?? route('member.posts.destroy', $post);
    $deleteConfirm = $deleteConfirm ?? 'Delete this post?';
    $canView = $post->is_published;
?>
<div class="table-actions">
    <?php if($canView): ?>
        <a href="<?php echo e($publicUrl); ?>" class="table-action-btn" target="_blank" rel="noopener" title="View public page" aria-label="View public page">
            <?php echo $__env->make('partials.icons.eye', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </a>
    <?php else: ?>
        <span class="table-action-btn is-disabled" title="Post is not published" aria-label="Post is not published">
            <?php echo $__env->make('partials.icons.eye', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </span>
    <?php endif; ?>
    <?php if($canView): ?>
        <button
            type="button"
            class="table-action-btn js-copy-link"
            data-copy-url="<?php echo e($publicUrl); ?>"
            data-copy-title="Copy post link"
            title="Copy post link"
            aria-label="Copy post link"
        >
            <?php echo $__env->make('partials.icons.copy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </button>
    <?php endif; ?>
    <a href="<?php echo e($editUrl); ?>" class="table-action-btn" title="Edit post" aria-label="Edit post">
        <?php echo $__env->make('partials.icons.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </a>
    <form action="<?php echo e($destroyUrl); ?>" method="POST" class="table-action-form" onsubmit="return confirm(<?php echo json_encode($deleteConfirm, 15, 512) ?>)">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="table-action-btn table-action-btn-danger" title="Delete post" aria-label="Delete post">
            <?php echo $__env->make('partials.icons.trash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </button>
    </form>
</div>
<?php /**PATH /var/www/couponshere/resources/views/partials/post-table-actions.blade.php ENDPATH**/ ?>
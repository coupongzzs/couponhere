<article class="sp-coupon-row <?php echo e($coupon->is_featured ? 'sp-coupon-row--featured' : ''); ?>" <?php if($coupon->code): ?> data-code-reveal <?php endif; ?>>
    <?php if($coupon->is_featured): ?>
        <span class="sp-best-value-ribbon">Best Value</span>
    <?php endif; ?>
    <div class="sp-coupon-row-meta">
        <?php if($coupon->code): ?>
            <div class="sp-coupon-row-code">
                <?php echo $__env->make('partials.coupon-code-masked', ['coupon' => $coupon], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endif; ?>
        <div class="sp-coupon-row-discount"><?php echo e($coupon->discountLabelWithStore()); ?></div>
    </div>
    <div class="sp-coupon-row-body">
        <h3 class="sp-coupon-row-title">
            <a href="<?php echo e(route('coupons.show', $coupon->slug)); ?>"><?php echo e($coupon->title); ?></a>
        </h3>
        <p class="sp-coupon-row-desc">
            <?php if(($showDescription ?? true) && filled($coupon->description)): ?>
                <?php echo e(\Illuminate\Support\Str::limit(strip_tags($coupon->description), 140)); ?>

            <?php endif; ?>
        </p>
        <?php if($coupon->expires_at): ?>
            <p class="sp-coupon-row-expire"><?php echo e($coupon->expiresLabel()); ?></p>
        <?php endif; ?>
    </div>
    <div class="sp-coupon-row-action">
        <?php if($coupon->code): ?>
            <button type="button"
                class="sp-code-copy sp-code-copy--row"
                data-reveal-url="<?php echo e(route('coupons.reveal', $coupon->slug)); ?>"
                data-affiliate-url="<?php echo e($coupon->affiliateClickUrl()); ?>"
                data-coupon-title="<?php echo e($coupon->title); ?>"
                data-coupon-discount="<?php echo e($coupon->discountLabel()); ?>"
                data-coupon-store="<?php echo e($coupon->store?->name); ?>"
                data-coupon-expires="<?php echo e($coupon->expiresLabel()); ?>"
                data-shop-url="<?php echo e(route('coupons.go', $coupon->slug)); ?>"
                aria-label="Copy promo code">
                Copy Code
            </button>
        <?php else: ?>
            <a href="<?php echo e(route('coupons.go', $coupon->slug)); ?>" class="btn btn-primary sp-get-deal-btn" target="_blank" rel="noopener sponsored">Get Deal</a>
        <?php endif; ?>
    </div>
</article>
<?php /**PATH /var/www/couponshere/resources/views/themes/savingspro/coupon-row.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Coupon Categories'); ?>
<?php $__env->startSection('meta_description', 'Browse coupon categories — fashion, electronics, travel, and more. Find deals by topic on ' . config('site.name') . '.'); ?>
<?php $__env->startSection('canonical', route('categories.index')); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-header"><h1>Deal Categories</h1></div>
    <div class="category-grid" style="grid-template-columns:repeat(auto-fill,minmax(180px,1fr));">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('categories.show', $category->slug)); ?>" class="category-chip">
                <span class="icon"><?php echo $__env->make('partials.category-icon', ['category' => $category, 'size' => 'md'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
                <strong><?php echo e($category->name); ?></strong>
                <small><?php echo e($category->coupons_count); ?> <?php echo e(Str::plural('offer', $category->coupons_count)); ?></small>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/categories/index.blade.php ENDPATH**/ ?>
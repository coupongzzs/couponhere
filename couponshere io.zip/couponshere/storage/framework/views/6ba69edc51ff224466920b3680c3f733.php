<article class="blog-card">
    <?php if($post->featuredImageUrl()): ?>
        <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="blog-card-image">
            <img src="<?php echo e($post->featuredImageUrl()); ?>" alt="<?php echo e($post->title); ?>" loading="lazy">
        </a>
    <?php endif; ?>
    <div class="blog-card-body">
        <time datetime="<?php echo e($post->published_at?->toDateString()); ?>">
            <?php echo e($post->published_at?->format('F j, Y')); ?>

        </time>
        <p class="blog-card-author"><?php echo $__env->make('blog.partials.author-link', ['post' => $post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></p>
        <h2><a href="<?php echo e(route('blog.show', $post->slug)); ?>" <?php if($post->title !== $post->cardTitle()): ?> title="<?php echo e($post->title); ?>" <?php endif; ?>><?php echo e($post->cardTitle()); ?></a></h2>
        <p class="blog-card-excerpt"><?php echo e($post->excerpt ?: Str::limit(strip_tags($post->content), 160)); ?></p>
        <div class="blog-card-meta">
            <span><?php echo e($post->readingTime()); ?> min read</span>
            <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="read-more">Read article →</a>
        </div>
    </div>
</article>
<?php /**PATH /var/www/couponshere/resources/views/blog/partials/card.blade.php ENDPATH**/ ?>
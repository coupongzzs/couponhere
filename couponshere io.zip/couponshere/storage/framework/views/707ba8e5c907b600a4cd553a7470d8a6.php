<?php
    $publicUrl = route('stores.show', $store->slug);
    $editUrl = $editUrl ?? route('member.stores.edit', $store);
    $destroyUrl = $destroyUrl ?? route('member.stores.destroy', $store);
    $showCopy = $showCopy ?? true;
?>
<div class="table-actions">
    <?php if($store->is_active): ?>
        <a href="<?php echo e($publicUrl); ?>" class="table-action-btn" target="_blank" rel="noopener" title="View public page" aria-label="View public page">
            <?php echo $__env->make('partials.icons.eye', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </a>
    <?php else: ?>
        <span class="table-action-btn is-disabled" title="Store is inactive" aria-label="Store is inactive">
            <?php echo $__env->make('partials.icons.eye', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </span>
    <?php endif; ?>
    <?php if($showCopy): ?>
        <button
            type="button"
            class="table-action-btn js-copy-link"
            data-copy-url="<?php echo e($publicUrl); ?>"
            data-copy-title="Copy store link"
            title="Copy store link"
            aria-label="Copy store link"
        >
            <?php echo $__env->make('partials.icons.copy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </button>
    <?php endif; ?>
    <a href="<?php echo e($editUrl); ?>" class="table-action-btn" title="Edit store" aria-label="Edit store">
        <?php echo $__env->make('partials.icons.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </a>
    <form action="<?php echo e($destroyUrl); ?>" method="POST" class="table-action-form" onsubmit="return confirm('Delete this store and its coupons?')">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="table-action-btn table-action-btn-danger" title="Delete store" aria-label="Delete store">
            <?php echo $__env->make('partials.icons.trash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </button>
    </form>
</div>
<?php /**PATH /var/www/couponshere/resources/views/partials/store-table-actions.blade.php ENDPATH**/ ?>
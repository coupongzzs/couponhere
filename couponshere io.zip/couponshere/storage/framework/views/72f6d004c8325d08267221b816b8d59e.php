<?php
    $isAdmin = $isAdmin ?? auth()->user()->isAdmin();
?>
<div class="sidebar-nav-section">
    <span class="sidebar-nav-section-label">Google Ads Builder</span>
    <a href="<?php echo e(route('member.keywords.create')); ?>"
        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('member.keywords.*')]); ?>">
        Keyword Generator
    </a>
    <?php if($isAdmin ?? auth()->user()->isAdmin()): ?>
        <a href="<?php echo e(route('admin.ads-settings.index')); ?>"
            class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-nav-sublink', 'active' => request()->routeIs('admin.ads-settings.*')]); ?>">
            Ads Settings
        </a>
    <?php endif; ?>
</div>
<?php /**PATH /var/www/couponshere/resources/views/partials/dashboard-sidebar-google-ads.blade.php ENDPATH**/ ?>
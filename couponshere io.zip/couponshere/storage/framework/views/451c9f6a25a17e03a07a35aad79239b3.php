<?php
    $themeKey = $activeTheme ?? 'classic';
    $themeConfig = config('themes.themes.' . $themeKey, config('themes.themes.classic'));
    $themeCss = public_path('css/' . $themeConfig['css']);
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="<?php echo e($themeConfig['font']); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>?v=<?php echo e(filemtime(public_path('css/app.css'))); ?>">
<?php if(file_exists($themeCss)): ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/' . $themeConfig['css'])); ?>?v=<?php echo e(filemtime($themeCss)); ?>">
<?php endif; ?>
<?php /**PATH /var/www/couponshere/resources/views/partials/theme-styles.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en-US">
<head>
    <?php echo $__env->make('partials.tracking-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(\App\Support\TrackingScripts::conversionActiveForRequest()): ?>
        <?php echo $__env->make('partials.tracking-conversion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="google-site-verification" content="ZoEPV8YUdyhz-bdAHihGZ8aKmr0N1K3xhWsZOfZY29U">
    <?php echo $__env->make('partials.seo-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.theme-styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
    <?php echo $__env->make('partials.site-schema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('structured_data'); ?>
</head>
<body class="theme-<?php echo e($activeTheme); ?>">
    <?php
        $themeHeaderView = 'themes.' . ($activeTheme ?? 'classic') . '.partials.header';
    ?>
    <?php if(view()->exists($themeHeaderView)): ?>
        <?php echo $__env->make($themeHeaderView, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('partials.site-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success container"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-error container"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php if($activeTheme === 'prime'): ?>
        <?php echo $__env->make('themes.prime.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <footer class="site-footer">
            <div class="container footer-grid">
                <div>
                    <strong><?php echo e($siteHomeH1); ?></strong>
                    <p class="footer-tagline"><?php echo e($siteFooterTagline); ?></p>
                    <p class="footer-sub-tagline"><?php echo e($siteFooterSubTagline); ?></p>
                    <p class="footer-description-tagline"><?php echo e($siteFooterDescriptionTagline); ?></p>
                </div>
                <div>
                    <h4>Explore</h4>
                    <a href="<?php echo e(route('coupons.index')); ?>">All Coupons</a>
                    <a href="<?php echo e(route('stores.index')); ?>">Stores</a>
                    <a href="<?php echo e(route('categories.index')); ?>">Categories</a>
                    <a href="<?php echo e(route('blog.index')); ?>">Blog</a>
                    <a href="<?php echo e(route('authors.index')); ?>">Authors</a>
                </div>
                <div>
                    <h4>Company</h4>
                    <a href="<?php echo e(route('pages.about')); ?>">About Us</a>
                    <a href="<?php echo e(route('pages.contact')); ?>">Contact Us</a>
                </div>
                <div class="footer-legal-col">
                    <h4>Legal</h4>
                    <a href="<?php echo e(route('pages.privacy')); ?>">Privacy Policy</a>
                    <a href="<?php echo e(route('pages.terms')); ?>">Terms of Service</a>
                    <a href="<?php echo e(route('pages.cookies')); ?>">Cookie Policy</a>
                    <a href="<?php echo e(route('pages.disclaimer')); ?>">Disclaimer</a>
                    <?php if(!empty($siteSocialLinks)): ?>
                        <h4 class="footer-social-heading">Follow Us</h4>
                        <?php echo $__env->make('partials.site-social-links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="container footer-copy">
                &copy; <?php echo e(date('Y')); ?> <?php echo e(config('site.domain')); ?>. All rights reserved.
            </div>
        </footer>
    <?php endif; ?>

    <script>
        window.__couponRedirectFlow = <?php echo json_encode(\App\Support\SiteCouponRedirect::flow(), 15, 512) ?>;
    </script>
    <script src="<?php echo e(asset('js/app.js')); ?>?v=<?php echo e(filemtime(public_path('js/app.js'))); ?>"></script>
    <?php echo $__env->make('themes.savingspro.coupon-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php
        $themeJs = \App\Support\ThemeManager::jsPath();
    ?>
    <?php if($themeJs && file_exists(public_path($themeJs))): ?>
        <script src="<?php echo e(asset($themeJs)); ?>?v=<?php echo e(filemtime(public_path($themeJs))); ?>"></script>
    <?php endif; ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /var/www/couponshere/resources/views/layouts/app.blade.php ENDPATH**/ ?>
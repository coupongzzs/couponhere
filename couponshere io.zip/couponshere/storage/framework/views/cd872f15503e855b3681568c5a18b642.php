<div class="offer-block" data-index="<?php echo e($index); ?>">
    <div class="offer-row">
        <button
            type="button"
            class="offer-sort-handle"
            aria-label="Drag to reorder offer"
            title="Drag to reorder"
        >⠿</button>
        <span class="offer-num">#<span class="offer-block-number"><?php echo e(is_numeric($index) ? $index + 1 : 1); ?></span></span>
        <div class="offer-field offer-field-code">
            <label>Code</label>
            <input type="text" name="offers[<?php echo e($index); ?>][code]" value="<?php echo e(old("offers.$index.code", $offer['code'] ?? '')); ?>" placeholder="Optional">
        </div>
        <div class="offer-field offer-field-title">
            <label>Offer *</label>
            <input type="text" name="offers[<?php echo e($index); ?>][title]" value="<?php echo e(old("offers.$index.title", $offer['title'] ?? '')); ?>" required placeholder="e.g. 20% Off Sitewide">
        </div>
        <button type="button" class="btn btn-outline remove-offer-btn" title="Remove offer">&times;</button>
    </div>
    <div class="offer-field offer-field-desc">
        <label>Description</label>
        <textarea name="offers[<?php echo e($index); ?>][description]" rows="2" placeholder="Terms, exclusions, minimum order..."><?php echo e(old("offers.$index.description", $offer['description'] ?? '')); ?></textarea>
    </div>
    <div class="offer-meta-row">
        <div class="offer-field offer-field-expires">
            <label>Expiration (optional)</label>
            <input
                type="datetime-local"
                name="offers[<?php echo e($index); ?>][expires_at]"
                value="<?php echo e(old("offers.$index.expires_at", $offer['expires_at'] ?? '')); ?>"
            >
        </div>
    </div>
</div>
<?php /**PATH /var/www/couponshere/resources/views/member/import-affiliate/partials/offer-block.blade.php ENDPATH**/ ?>
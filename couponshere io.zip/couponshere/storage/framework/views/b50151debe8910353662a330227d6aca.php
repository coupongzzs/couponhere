<?php $__env->startSection('title', $q ? "Search: {$q}" : 'Search'); ?>
<?php $__env->startSection('meta_description', $q ? "Search results for \"{$q}\" — coupons, stores, and blog articles on " . config('site.name') . '.' : 'Search coupon codes, stores, blog articles, and deals.'); ?>
<?php $__env->startSection('meta_robots', 'noindex, follow'); ?>
<?php $__env->startSection('canonical', route('search', array_filter(['q' => $q]))); ?>

<?php $__env->startPush('head_links'); ?>
    <?php echo $__env->make('partials.pagination-seo', ['paginator' => $coupons], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php ($resultCount = $coupons->total() + $posts->count()); ?>
<div class="container">
    <div class="page-header">
        <h1>
            Search results
            <?php if($q): ?>
                : "<?php echo e($q); ?>"
            <?php endif; ?>
        </h1>
        <?php if($q): ?>
            <p><?php echo e($resultCount); ?> <?php echo e($resultCount === 1 ? 'result' : 'results'); ?> found</p>
        <?php endif; ?>
    </div>

    <?php if($posts->isNotEmpty()): ?>
        <section class="search-section">
            <h2 class="section-title">Blog articles <span><?php echo e($posts->count()); ?></span></h2>
            <div class="blog-grid">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('blog.partials.card', ['post' => $post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if($coupons->isNotEmpty()): ?>
        <section class="search-section">
            <h2 class="section-title">Coupons &amp; deals <span><?php echo e($coupons->total()); ?></span></h2>
            <div class="coupon-grid">
                <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.coupon-card', ['coupon' => $coupon], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="pagination"><?php echo e($coupons->links()); ?></div>
        </section>
    <?php endif; ?>

    <?php if($q && $posts->isEmpty() && $coupons->isEmpty()): ?>
        <p>No matching blog articles or coupons found. Try a different keyword.</p>
    <?php elseif(! $q): ?>
        <p>Enter a keyword to search blog articles, coupon codes, and stores.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.search-section + .search-section {
    margin-top: 2.5rem;
    padding-top: 2rem;
    border-top: 1px solid var(--border);
}
.search-section .section-title span {
    font-size: .9rem;
    font-weight: 600;
    color: var(--muted);
}
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/search.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Payout Requests'); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;flex-wrap:wrap;gap:.75rem;">
    <h1>Payout Requests</h1>
    <a href="<?php echo e(route('member.affiliate.index')); ?>" class="btn btn-outline">← Back to Referral Program</a>
</div>

<p style="margin-bottom:1rem;">Available balance: <strong><?php echo e(number_format($balance, 2)); ?> <?php echo e($currency); ?></strong> (minimum request: <?php echo e(number_format($minPayout, 2)); ?> <?php echo e($currency); ?>)</p>

<?php if($balance >= $minPayout): ?>
<div class="form-card" id="request-payout" style="margin-bottom:1.5rem;">
    <h2>Request Payout</h2>
    <form method="POST" action="<?php echo e(route('member.affiliate.payouts.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="amount">Amount (<?php echo e($currency); ?>) *</label>
            <input type="number" step="0.01" min="<?php echo e($minPayout); ?>" max="<?php echo e($balance); ?>" id="amount" name="amount" value="<?php echo e(old('amount', $balance)); ?>" required>
            <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="payment_method">Payment Method *</label>
            <input type="text" id="payment_method" name="payment_method" value="<?php echo e(old('payment_method')); ?>" placeholder="Bank transfer, PayPal, etc." required>
            <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="payment_details">Payment Details *</label>
            <textarea id="payment_details" name="payment_details" rows="4" required placeholder="Account number, PayPal email, etc."><?php echo e(old('payment_details')); ?></textarea>
            <?php $__errorArgs = ['payment_details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="member_note">Note (optional)</label>
            <textarea id="member_note" name="member_note" rows="2"><?php echo e(old('member_note')); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Submit Payout Request</button>
    </form>
</div>
<?php endif; ?>

<table class="admin-table">
    <thead>
        <tr>
            <th>#</th>
            <th>Amount</th>
            <th>Method</th>
            <th>Status</th>
            <th>Requested</th>
            <th>Processed</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $payouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($payout->id); ?></td>
            <td><?php echo e(number_format($payout->amount, 2)); ?> <?php echo e($currency); ?></td>
            <td><?php echo e($payout->payment_method ?: '—'); ?></td>
            <td><?php echo e($payout->statusLabel()); ?></td>
            <td><?php echo e($payout->created_at->format('M j, Y H:i')); ?></td>
            <td><?php echo e($payout->processed_at?->format('M j, Y H:i') ?: '—'); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="6">No payout requests yet.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php echo e($payouts->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/member/affiliate/payouts.blade.php ENDPATH**/ ?>
<?php
    $sectionId = $sectionId ?? 'section';
    $sectionLabel = $sectionLabel ?? 'Section';
    $sectionOpen = (bool) ($sectionOpen ?? false);
?>
<div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
    'sidebar-nav-section',
    'sidebar-nav-section--collapsible',
    'is-open' => $sectionOpen,
]); ?>" data-sidebar-section="<?php echo e($sectionId); ?>" <?php if($sectionOpen): ?> data-sidebar-open-default <?php endif; ?>>
    <button type="button" class="sidebar-nav-section-toggle" aria-expanded="<?php echo e($sectionOpen ? 'true' : 'false'); ?>">
        <span class="sidebar-nav-section-toggle-label"><?php echo e($sectionLabel); ?></span>
        <span class="sidebar-nav-chevron" aria-hidden="true"></span>
    </button>
    <div class="sidebar-nav-section-body">
<?php /**PATH /var/www/couponshere/resources/views/partials/dashboard-sidebar-collapsible-section-start.blade.php ENDPATH**/ ?>
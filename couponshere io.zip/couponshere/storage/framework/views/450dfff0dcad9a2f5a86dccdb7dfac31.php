<?php
    $statsDate = $statsDate ?? now()->toDateString();
    $period = $period ?? null;
    $action = $action ?? url()->current();
    $preserve = $preserve ?? [];
?>
<form method="GET" action="<?php echo e($action); ?>" class="click-stats-date-filter">
    <?php $__currentLoopData = $preserve; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(filled($value)): ?>
            <input type="hidden" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>">
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <label class="click-stats-date-filter__field">
        <span class="click-stats-date-filter__label">Click stats date</span>
        <input type="date" name="date" value="<?php echo e($statsDate); ?>" required>
    </label>
    <button type="submit" class="btn btn-outline">View day</button>
    <?php if(request()->filled('date') && request('date') !== now()->toDateString()): ?>
        <a href="<?php echo e($action); ?>?<?php echo e(http_build_query(array_filter(array_merge($preserve, ['date' => now()->toDateString()])))); ?>" class="btn btn-outline">Today</a>
    <?php endif; ?>
    <?php if($period): ?>
        <p class="click-stats-date-filter__hint form-hint">
            Showing clicks for
            <strong><?php echo e(\Carbon\Carbon::parse($period->day)->format('M j, Y')); ?></strong>
            · month <?php echo e(\Carbon\Carbon::parse($period->monthStart)->format('M Y')); ?>

            · year <?php echo e(\Carbon\Carbon::parse($period->yearStart)->format('Y')); ?>

        </p>
    <?php endif; ?>
</form>

<?php if (! $__env->hasRenderedOnce('b5ba63eb-09f0-4ee1-a00e-9c63086ad5d7')): $__env->markAsRenderedOnce('b5ba63eb-09f0-4ee1-a00e-9c63086ad5d7'); ?>
    <?php $__env->startPush('styles'); ?>
    <style>
    .click-stats-date-filter {
        display: flex;
        flex-wrap: wrap;
        gap: .65rem 1rem;
        align-items: flex-end;
        margin-bottom: 1rem;
        padding: .85rem 1rem;
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: .5rem;
    }
    .click-stats-date-filter__field {
        display: flex;
        flex-direction: column;
        gap: .25rem;
    }
    .click-stats-date-filter__label {
        font-size: .8rem;
        font-weight: 600;
        color: var(--muted, #64748b);
    }
    .click-stats-date-filter input[type="date"] {
        padding: .45rem .6rem;
        border: 1px solid #cbd5e1;
        border-radius: .35rem;
        background: #fff;
        min-width: 11rem;
    }
    .click-stats-date-filter__hint {
        flex: 1 1 100%;
        margin: 0;
    }
    </style>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /var/www/couponshere/resources/views/partials/click-stats-date-filter.blade.php ENDPATH**/ ?>
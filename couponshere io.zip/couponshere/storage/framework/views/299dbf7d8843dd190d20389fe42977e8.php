<?php $__env->startSection('title', 'My Stores'); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex;justify-content:space-between;margin-bottom:1.5rem;">
    <h1>My Stores</h1>
    <a href="<?php echo e(route('member.stores.create')); ?>" class="btn btn-primary">+ Add Store</a>
</div>

<?php echo $__env->make('partials.admin-list-search', [
    'action' => route('member.stores.index'),
    'value' => $q ?? '',
    'placeholder' => 'Search by store name…',
    'clearUrl' => route('member.stores.index'),
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<table class="admin-table">
    <thead>
        <tr>
            <th>Logo</th>
            <th>Name</th>
            <th>Category</th>
            <th>Coupons</th>
            <th>Page views</th>
            <th>Created</th>
            <th class="table-actions-col">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <?php if($store->logoUrl()): ?>
                        <img src="<?php echo e($store->logoUrl()); ?>" alt="<?php echo e($store->name); ?>" class="admin-thumb" loading="lazy">
                    <?php else: ?>
                        <span class="admin-thumb-fallback"><?php echo e($store->initials()); ?></span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($store->name); ?></td>
                <td>
                    <?php if($store->category): ?>
                        <span class="category-inline"><?php echo $__env->make('partials.category-icon', ['category' => $store->category, 'size' => 'sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php echo e($store->category->name); ?></span>
                    <?php else: ?>
                        <span class="text-muted">—</span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($store->coupons_count); ?></td>
                <td><strong><?php echo e(number_format($store->view_count)); ?></strong></td>
                <td><?php echo e($store->created_at?->format('M j, Y')); ?></td>
                <td>
                    <?php echo $__env->make('partials.store-table-actions', ['store' => $store], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7">
                    <?php if(filled($q ?? null)): ?>
                        No stores match your search.
                    <?php else: ?>
                        No stores yet. <a href="<?php echo e(route('member.stores.create')); ?>">Add your first store</a>.
                    <?php endif; ?>
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php echo e($stores->links()); ?>


<?php echo $__env->make('partials.table-actions-assets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>.text-muted { color: #94a3b8; }</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/member/stores/index.blade.php ENDPATH**/ ?>
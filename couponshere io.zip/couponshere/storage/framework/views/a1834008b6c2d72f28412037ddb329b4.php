<?php $__env->startSection('title', $store->seoTitle()); ?>
<?php $__env->startSection('meta_description', $store->seoDescription()); ?>
<?php $__env->startSection('og_title', $store->ogShareTitle()); ?>
<?php $__env->startSection('og_description', $store->ogShareDescription()); ?>
<?php $__env->startSection('canonical', route('stores.show', $store->slug)); ?>
<?php $__env->startSection('og_url', route('stores.show', $store->slug)); ?>
<?php if($store->ogImageUrl()): ?>
<?php $__env->startSection('og_image', $store->ogImageUrl()); ?>
<?php endif; ?>
<?php $__env->startSection('og_image_alt', $store->name); ?>

<?php $__env->startPush('og_meta'); ?>
<?php if($store->ogImageUrl()): ?>
<meta property="og:image:secure_url" content="<?php echo e(\App\Support\Seo::absoluteUrl($store->ogImageUrl())); ?>">
<?php endif; ?>
<meta property="og:updated_time" content="<?php echo e($store->updated_at?->toIso8601String()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('structured_data'); ?>
<?php echo $__env->make('partials.breadcrumb-schema', ['breadcrumbs' => [
    ['name' => 'Home', 'url' => route('home')],
    ['name' => 'Stores', 'url' => route('stores.index')],
    ['name' => $store->name, 'url' => route('stores.show', $store->slug)],
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="application/ld+json">
<?php echo json_encode($store->structuredData(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE, 512) ?>
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('head_links'); ?>
    <?php echo $__env->make('partials.pagination-seo', ['paginator' => $coupons], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- chia 2 cột ở đây -->
    <div class="store-page-layout">
        <div class="store-page-column store-page-column--posts">
            <?php echo $__env->make('partials.store-logo', ['store' => $store, 'size' => 'xl', 'showVerified' => true, 'linked' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div>
                <h1><?php echo e($store->name); ?></h1>
                <span class="store-page-verified">Coupons listed on <?php echo e(config('site.name')); ?></span>
            </div>
            <?php echo $__env->make('partials.social-share', [
                'url' => route('stores.show', $store->slug),
                'title' => $store->seoTitle(),
                'description' => $store->seoDescription(),
                'store' => $store,
                'label' => 'Share this store',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('partials.site-affiliate-notice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php if($store->description): ?>
                <div class="store-description-content"><?php echo $store->renderedDescription(); ?></div>
            <?php endif; ?>
        </div>
        <div class="store-page-column store-page-column--coupons">
            <h2 class="store-page-column-title"><?php echo e($store->name); ?> Coupons &amp; Deals</h2>
            <div class="coupon-grid coupon-grid--stack">
                <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo $__env->make('partials.coupon-card', ['coupon' => $coupon, 'showDescription' => true, 'openAffiliateOnCopy' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="store-page-empty">No coupons available for this store yet.</p>
                <?php endif; ?>
            </div>
            <div class="pagination"><?php echo e($coupons->links()); ?></div>
        </div>
    </div>
</div>

<?php echo $__env->make('partials.scroll-coupon-popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/stores/show.blade.php ENDPATH**/ ?>
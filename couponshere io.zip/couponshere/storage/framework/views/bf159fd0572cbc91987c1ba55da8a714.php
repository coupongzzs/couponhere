<?php
    $parts = $coupon->maskedCodeParts();
?>
<span class="coupon-code-masked <?php echo e($class ?? ''); ?>" data-masked-code>
    <span class="coupon-code-visible"><?php echo e($parts['visible']); ?></span><span class="coupon-code-blur"><?php echo e($parts['hidden']); ?></span>
</span>
<?php /**PATH /var/www/couponshere/resources/views/partials/coupon-code-masked.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', $store->exists ? 'Edit Store' : 'Add Store'); ?>

<?php $__env->startSection('content'); ?>
<h1 style="margin-bottom:1.5rem;"><?php echo e($store->exists ? 'Edit' : 'Add'); ?> Store</h1>
<form method="POST" enctype="multipart/form-data" action="<?php echo e($store->exists ? route('admin.stores.update', $store) : route('admin.stores.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($store->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <?php echo $__env->make('partials.store-slug-fields', ['store' => $store], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="form-group">
        <label>Logo</label>
        <?php if($store->logoUrl()): ?>
            <div class="admin-image-preview">
                <img src="<?php echo e($store->logoUrl()); ?>" alt="<?php echo e($store->name); ?>" class="admin-preview-img">
            </div>
        <?php endif; ?>
        <input type="file" name="logo_file" accept="image/*" style="margin-top:.5rem;">
        <?php $ownerId = $store->user_id ?? auth()->id() ?? 'admin'; ?>
        <p class="form-hint">Saved under <code>stores/<?php echo e($ownerId); ?>/</code> when uploaded. JPG, PNG or WebP (max 2MB).</p>
        <input name="logo" value="<?php echo e(old('logo', $store->hasStoredLogo() ? '' : $store->logo)); ?>" placeholder="https://example.com/logo.png" style="margin-top:.5rem;">
    </div>
    <?php echo $__env->make('partials.store-category-field', ['store' => $store, 'categories' => $categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.store-website-field', ['store' => $store], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.store-description-editor', ['value' => $store->description, 'editorId' => 'admin-store-description'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.store-coupon-display-fields', ['store' => $store, 'storeCoupons' => $storeCoupons ?? collect()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="form-group"><label>Sort order</label><input type="number" name="sort_order" value="<?php echo e(old('sort_order', $store->sort_order ?? 0)); ?>"></div>
    <div class="form-check">
        <input type="checkbox" name="show_on_stores" value="1" id="show_on_stores" <?php if(old('show_on_stores', $store->show_on_stores ?? true)): echo 'checked'; endif; ?>>
        <label for="show_on_stores">Show on public Stores page (/stores)</label>
    </div>
    <div class="form-group">
        <label for="stores_list_sort_order">Order on Stores page</label>
        <input type="number" id="stores_list_sort_order" name="stores_list_sort_order" min="0" max="9999" value="<?php echo e(old('stores_list_sort_order', $store->stores_list_sort_order ?? 0)); ?>" style="max-width:8rem;">
        <p class="form-hint">Higher numbers appear first on the stores listing page.</p>
    </div>
    <div class="form-check">
        <input type="checkbox" name="is_active" value="1" <?php if(old('is_active', $store->is_active ?? true)): echo 'checked'; endif; ?>>
        <label>Active</label>
    </div>
    <button type="submit" class="btn btn-primary" style="margin-top:1rem;">Save</button>
    <a href="<?php echo e(route('admin.stores.index')); ?>" class="btn btn-outline">Cancel</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/admin/stores/form.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Review Payout Request'); ?>

<?php $__env->startSection('content'); ?>
<h1 style="margin-bottom:1.5rem;">Payout Request #<?php echo e($payout->id); ?></h1>

<div class="form-card" style="margin-bottom:1.5rem;">
    <p><strong>Member:</strong> <?php echo e($payout->user?->name); ?> (<?php echo e($payout->user?->email); ?>)</p>
    <p><strong>Amount:</strong> <?php echo e(number_format($payout->amount, 2)); ?> <?php echo e($currency); ?></p>
    <p><strong>Payment Method:</strong> <?php echo e($payout->payment_method ?: '—'); ?></p>
    <p><strong>Payment Details:</strong></p>
    <pre style="white-space:pre-wrap;background:var(--bg-alt);padding:.75rem;border-radius:6px;"><?php echo e($payout->payment_details); ?></pre>
    <?php if($payout->member_note): ?>
        <p><strong>Member Note:</strong> <?php echo e($payout->member_note); ?></p>
    <?php endif; ?>
    <p><strong>Requested:</strong> <?php echo e($payout->created_at->format('M j, Y H:i')); ?></p>
    <?php if($payout->processed_at): ?>
        <p><strong>Processed:</strong> <?php echo e($payout->processed_at->format('M j, Y H:i')); ?> by <?php echo e($payout->processedBy?->name); ?></p>
    <?php endif; ?>
</div>

<form method="POST" action="<?php echo e(route('admin.affiliate.payouts.update', $payout)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="form-group">
        <label for="status">Status *</label>
        <select id="status" name="status" required>
            <?php $__currentLoopData = \App\Models\AffiliatePayoutRequest::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($status); ?>" <?php if(old('status', $payout->status) === $status): echo 'selected'; endif; ?>><?php echo e(ucfirst($status)); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <p class="form-hint">
            <strong>Pending</strong> — waiting for your payment.<br>
            <strong>Approved</strong> — approved, payment in progress.<br>
            <strong>Paid</strong> — you have sent the money (final).<br>
            <strong>Rejected</strong> — declined; amount returns to member balance.
        </p>
        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="admin_note">Admin Note</label>
        <textarea id="admin_note" name="admin_note" rows="3" placeholder="Transaction ID, payment date, reason for rejection, etc."><?php echo e(old('admin_note', $payout->admin_note)); ?></textarea>
    </div>

    <div style="display:flex;gap:.75rem;">
        <button type="submit" class="btn btn-primary">Update Status</button>
        <a href="<?php echo e(route('admin.affiliate.payouts.index')); ?>" class="btn btn-outline">Back</a>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/admin/affiliate/payouts/form.blade.php ENDPATH**/ ?>
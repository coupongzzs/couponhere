<?php if(!empty($siteSocialLinks)): ?>
    <div class="site-social-links<?php echo e(!empty($compact) ? ' site-social-links--compact' : ''); ?>" role="navigation" aria-label="Social media">
        <?php $__currentLoopData = $siteSocialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($link['url']); ?>"
                class="site-social-link site-social-link--<?php echo e($link['key']); ?>"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="<?php echo e($link['label']); ?>">
                <?php echo $__env->make('partials.site-social-icon', ['network' => $link['key']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php /**PATH /var/www/couponshere/resources/views/partials/site-social-links.blade.php ENDPATH**/ ?>
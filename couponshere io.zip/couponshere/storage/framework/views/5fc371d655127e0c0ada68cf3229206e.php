<?php $__env->startSection('title', $store->exists ? 'Edit Store' : 'Add Store'); ?>

<?php $__env->startSection('content'); ?>
<h1 style="margin-bottom:1.5rem;"><?php echo e($store->exists ? 'Edit' : 'Add'); ?> Store</h1>
<form method="POST" enctype="multipart/form-data" action="<?php echo e($store->exists ? route('member.stores.update', $store) : route('member.stores.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($store->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <?php echo $__env->make('partials.store-slug-fields', ['store' => $store], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="form-group">
        <label>Logo</label>
        <?php if($store->logoUrl()): ?>
            <div class="admin-image-preview">
                <img src="<?php echo e($store->logoUrl()); ?>" alt="<?php echo e($store->name); ?>" class="admin-preview-img">
            </div>
        <?php endif; ?>
        <input type="file" name="logo_file" accept="image/*" style="margin-top:.5rem;">
        <p class="form-hint">Upload JPG, PNG or WebP (max 2MB). Files are saved in your account folder <code>stores/<?php echo e(auth()->id()); ?>/</code>. Or paste an external image URL below.</p>
        <input name="logo" value="<?php echo e(old('logo', $store->hasStoredLogo() ? '' : $store->logo)); ?>" placeholder="https://example.com/logo.png" style="margin-top:.5rem;">
    </div>
    <?php echo $__env->make('partials.store-category-field', ['store' => $store, 'categories' => $categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.store-website-field', ['store' => $store], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.store-description-editor', ['value' => $store->description, 'editorId' => 'store-description'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.store-coupon-display-fields', ['store' => $store, 'storeCoupons' => $storeCoupons ?? collect()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="form-check">
        <input type="checkbox" name="is_active" value="1" <?php if(old('is_active', $store->is_active ?? true)): echo 'checked'; endif; ?>>
        <label>Active (visible on public site)</label>
    </div>
    <?php if($store->exists): ?>
        <p class="form-hint" style="margin-top:1rem;">Page views on your public store link: <strong><?php echo e(number_format($store->view_count)); ?></strong></p>
    <?php endif; ?>
    <button type="submit" class="btn btn-primary" style="margin-top:1rem;">Save</button>
    <a href="<?php echo e(route('member.stores.index')); ?>" class="btn btn-outline">Cancel</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/member/stores/form.blade.php ENDPATH**/ ?>
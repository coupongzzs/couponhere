<?php $__env->startSection('title', 'All Coupons & Promo Codes'); ?>
<?php $__env->startSection('meta_description', 'Browse U.S. coupon codes and discount deals. Filter by promo codes or store offers — updated daily on ' . config('site.name') . '.'); ?>
<?php $__env->startSection('canonical', $coupons->currentPage() > 1 ? $coupons->url($coupons->currentPage()) : route('coupons.index', array_filter(['type' => $type ?? null]))); ?>

<?php $__env->startPush('head_links'); ?>
    <?php echo $__env->make('partials.pagination-seo', ['paginator' => $coupons], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('structured_data'); ?>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    "name": <?php echo json_encode('Coupons & Deals — ' . config('site.name'), 15, 512) ?>,
    "url": <?php echo json_encode(route('coupons.index'), 15, 512) ?>,
    "description": <?php echo json_encode('Coupon codes and discount deals for U.S. online shoppers.', 15, 512) ?>
}
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-header">
        <h1>Coupons & Discount Deals</h1>
    </div>
    <div class="filter-tabs">
        <a href="<?php echo e(route('coupons.index')); ?>" class="<?php echo e(!$type ? 'active' : ''); ?>">All</a>
        <a href="<?php echo e(route('coupons.index', ['type' => 'coupon'])); ?>" class="<?php echo e($type === 'coupon' ? 'active' : ''); ?>">Coupon Codes</a>
        <a href="<?php echo e(route('coupons.index', ['type' => 'discount'])); ?>" class="<?php echo e($type === 'discount' ? 'active' : ''); ?>">Discount Deals</a>
    </div>
    <div class="coupon-grid">
        <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo $__env->make('partials.coupon-card', ['coupon' => $coupon, 'showDescription' => true, 'linkCardToDetail' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No offers available yet.</p>
        <?php endif; ?>
    </div>
    <div class="pagination"><?php echo e($coupons->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/coupons/index.blade.php ENDPATH**/ ?>
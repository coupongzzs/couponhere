<?php $__env->startSection('title', 'Create Account'); ?>
<?php $__env->startSection('meta_robots', 'noindex, nofollow'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="max-width:400px;padding:3rem 1rem;">
    <h1 style="margin-bottom:.5rem;">Create Account</h1>
    <p style="color:var(--muted);margin-bottom:1.5rem;">Join <?php echo e(config('site.name')); ?> to save your favorite deals.</p>
    <?php if(session('info')): ?>
        <div class="alert alert-success"><?php echo e(session('info')); ?></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-error">
            <ul style="margin:0;padding-left:1.25rem;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Full name</label>
            <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" required autofocus autocomplete="name">
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" id="password" required autocomplete="new-password">
        </div>
        <div class="form-group">
            <label for="password_confirmation">Confirm password</label>
            <input type="password" name="password_confirmation" id="password_confirmation" required autocomplete="new-password">
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;margin-top:1rem;padding:.75rem;">Create Account</button>
    </form>
    <p style="margin-top:1.25rem;text-align:center;color:var(--muted);">
        Already have an account?
        <a href="<?php echo e(route('login')); ?>">Sign in</a>
    </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/auth/register.blade.php ENDPATH**/ ?>
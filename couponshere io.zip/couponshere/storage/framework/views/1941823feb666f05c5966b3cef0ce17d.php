<?php $__env->startSection('title', 'Affiliate Payout Requests'); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex;justify-content:space-between;margin-bottom:1.5rem;flex-wrap:wrap;gap:.75rem;">
    <h1>Affiliate Payout Requests <?php if($pendingCount > 0): ?><span style="font-size:.9rem;color:var(--primary);">(<?php echo e($pendingCount); ?> pending)</span><?php endif; ?></h1>
    <a href="<?php echo e(route('admin.affiliate.orders.index')); ?>" class="btn btn-outline">Affiliate Orders</a>
</div>

<table class="admin-table">
    <thead>
        <tr>
            <th>#</th>
            <th>Member</th>
            <th>Amount</th>
            <th>Method</th>
            <th>Status</th>
            <th>Requested</th>
            <th class="table-actions-col">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $payouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($payout->id); ?></td>
            <td><?php echo e($payout->user?->name); ?><br><small style="color:var(--muted);"><?php echo e($payout->user?->email); ?></small></td>
            <td><?php echo e(number_format($payout->amount, 2)); ?> <?php echo e($currency); ?></td>
            <td><?php echo e($payout->payment_method ?: '—'); ?></td>
            <td><?php echo e($payout->statusLabel()); ?></td>
            <td><?php echo e($payout->created_at->format('M j, Y H:i')); ?></td>
            <td>
                <a href="<?php echo e(route('admin.affiliate.payouts.edit', $payout)); ?>" class="btn btn-outline btn-sm">Review</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="7">No payout requests yet.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php echo e($payouts->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/admin/affiliate/payouts/index.blade.php ENDPATH**/ ?>
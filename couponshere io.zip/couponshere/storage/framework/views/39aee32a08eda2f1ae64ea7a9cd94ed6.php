<a href="<?php echo e(route('home')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
    'sidebar-logo',
    'sidebar-logo--text-only' => empty($siteLogoUrl) && !empty($siteBrandShowText),
    'sidebar-logo--logo-only' => !empty($siteLogoUrl) && empty($siteBrandShowText),
]); ?>">
    <?php if(!empty($siteLogoUrl)): ?>
        <img src="<?php echo e($siteLogoUrl); ?>" alt="" class="sidebar-logo-img">
    <?php else: ?>
        <span class="sidebar-logo-icon" aria-hidden="true">%</span>
    <?php endif; ?>
    <?php if(!empty($siteBrandShowText)): ?>
        <span class="sidebar-logo-text">
            <?php if(!empty($siteDisplayName)): ?>
                <strong><?php echo e($siteDisplayName); ?></strong>
            <?php endif; ?>
            <?php if(!empty($showAdminBadge)): ?>
                <small>Admin</small>
            <?php elseif(!empty($siteDisplayTagline)): ?>
                <small><?php echo e($siteDisplayTagline); ?></small>
            <?php endif; ?>
        </span>
    <?php elseif(!empty($showAdminBadge)): ?>
        <span class="sidebar-logo-text">
            <strong><?php echo e($siteName); ?></strong>
            <small>Admin</small>
        </span>
    <?php endif; ?>
</a>
<?php /**PATH /var/www/couponshere/resources/views/partials/dashboard-sidebar-logo.blade.php ENDPATH**/ ?>
<div class="ads-settings-row callout-row">
    <div class="ads-settings-row-head">
        <strong>Callout <span class="ads-settings-row-number"><?php echo e((int) $index + 1); ?></span></strong>
        <button type="button" class="btn btn-outline btn-sm remove-callout-row">Remove</button>
    </div>
    <div class="ads-settings-row-grid">
        <div class="form-group">
            <label>Callout text</label>
            <input type="text" name="callouts[<?php echo e($index); ?>][text]" maxlength="25"
                value="<?php echo e(old('callouts.'.$index.'.text', $callout['text'] ?? '')); ?>" placeholder="Verified promo codes">
        </div>
        <div class="form-group">
            <label>Status</label>
            <select name="callouts[<?php echo e($index); ?>][status]">
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php if(old('callouts.'.$index.'.status', $callout['status'] ?? 'Enabled') === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
</div>
<?php /**PATH /var/www/couponshere/resources/views/admin/ads-settings/partials/callout-row.blade.php ENDPATH**/ ?>
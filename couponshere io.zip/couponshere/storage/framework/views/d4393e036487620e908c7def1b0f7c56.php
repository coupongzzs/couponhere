<?php $__env->startSection('title', 'Coupon Stores — Shop by Retailer'); ?>
<?php $__env->startSection('meta_description', 'Find coupon codes by store — Amazon, Walmart, Target, and hundreds of U.S. retailers on ' . config('site.name') . '.'); ?>
<?php $__env->startSection('canonical', $stores->currentPage() > 1 ? $stores->url($stores->currentPage()) : route('stores.index')); ?>

<?php $__env->startPush('head_links'); ?>
    <?php echo $__env->make('partials.pagination-seo', ['paginator' => $stores], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-header"><h1>Stores</h1></div>
    <div class="store-grid store-grid--cards">
        <?php $__empty_1 = true; $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('stores.show', $store->slug)); ?>" class="store-card">
                <div class="store-card-logo">
                    <?php echo $__env->make('partials.store-logo', ['store' => $store, 'size' => 'xxl', 'showVerified' => false, 'linked' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="store-card-body">
                    <strong class="store-card-name"><?php echo e($store->name); ?></strong>
                    <p class="store-card-description">
                        <?php if($store->listingDescription()): ?>
                            <?php echo e(\Illuminate\Support\Str::limit($store->listingDescription(), 160)); ?>

                        <?php endif; ?>
                    </p>
                    <div class="store-card-meta">
                        <span><?php echo e($store->coupons_count); ?> <?php echo e(Str::plural('offer', $store->coupons_count)); ?></span>
                        <?php if($store->category): ?>
                            <span class="category-inline"><?php echo $__env->make('partials.category-icon', ['category' => $store->category, 'size' => 'sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php echo e($store->category->name); ?></span>
                        <?php endif; ?>
                    </div>
                    <span class="store-chip-verified">Coupons listed on <?php echo e(config('site.name')); ?></span>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No stores available yet.</p>
        <?php endif; ?>
    </div>
    <div class="pagination"><?php echo e($stores->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/stores/index.blade.php ENDPATH**/ ?>
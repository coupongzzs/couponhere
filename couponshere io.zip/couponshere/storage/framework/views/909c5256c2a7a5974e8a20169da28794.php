<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": <?php echo json_encode($siteName, 15, 512) ?>,
    "url": <?php echo json_encode(config('site.url'), 15, 512) ?>,
    "description": <?php echo json_encode(config('site.default_description'), 15, 512) ?>,
    "email": <?php echo json_encode($contactEmail, 15, 512) ?>
}
</script>
<?php /**PATH /var/www/couponshere/resources/views/partials/site-schema.blade.php ENDPATH**/ ?>
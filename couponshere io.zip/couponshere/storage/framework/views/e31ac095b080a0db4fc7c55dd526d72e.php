<?php
    $store = $store ?? null;
    $size = $size ?? 'md';
    $showVerified = $showVerified ?? false;
    $showName = $showName ?? false;
    $linked = $linked ?? true;
    $logoPixels = match ($size) {
        'xxl' => 112,
        'xl' => 88,
        'lg' => 64,
        default => 52,
    };
?>

<?php if($store): ?>
<div class="store-logo-wrap store-logo-wrap--<?php echo e($size); ?>">
    <?php if($linked): ?>
        <a href="<?php echo e(route('stores.show', $store->slug)); ?>" class="store-logo" title="<?php echo e($store->name); ?>">
    <?php else: ?>
        <div class="store-logo" aria-hidden="true">
    <?php endif; ?>
        <?php if($store->logoUrl()): ?>
            <img
                src="<?php echo e($store->logoUrl()); ?>"
                alt=""
                class="store-logo-img"
                loading="lazy"
                width="<?php echo e($logoPixels); ?>"
                height="<?php echo e($logoPixels); ?>"
                onerror="this.style.display='none';this.nextElementSibling?.classList.add('is-visible');"
            >
        <?php endif; ?>
        <span class="store-logo-fallback <?php echo e($store->logoUrl() ? '' : 'is-visible'); ?>"><?php echo e($store->initials()); ?></span>
    <?php if($linked): ?>
        </a>
    <?php else: ?>
        </div>
    <?php endif; ?>
    <?php if($showVerified): ?>
        <span class="store-verified" title="Featured store">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
            Featured
        </span>
    <?php endif; ?>
    <?php if($showName && $linked): ?>
        <a href="<?php echo e(route('stores.show', $store->slug)); ?>" class="store-logo-name"><?php echo e($store->name); ?></a>
    <?php elseif($showName): ?>
        <span class="store-logo-name"><?php echo e($store->name); ?></span>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php /**PATH /var/www/couponshere/resources/views/partials/store-logo.blade.php ENDPATH**/ ?>
<p class="site-affiliate-notice">
    <?php echo e(config('site.name')); ?> is an independent coupon and deals site. We are not affiliated with, endorsed by, or sponsored by
    retailers mentioned on this site unless stated otherwise. Trademarks belong to their respective owners.
    <a href="<?php echo e(route('pages.disclaimer')); ?>">Affiliate disclosure</a>
</p>
<?php /**PATH /var/www/couponshere/resources/views/partials/site-affiliate-notice.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', $category->exists ? 'Edit Category' : 'Add Category'); ?>

<?php $__env->startSection('content'); ?>
<div class="admin-page-header">
    <h1><?php echo e($category->exists ? 'Edit Category' : 'Add Category'); ?></h1>
    <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-outline">← Back to list</a>
</div>

<form method="POST" action="<?php echo e($category->exists ? route('admin.categories.update', $category) : route('admin.categories.store')); ?>" class="import-card category-form" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php if($category->exists): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="form-group">
        <label for="name">Name *</label>
        <input type="text" id="name" name="name" value="<?php echo e(old('name', $category->name)); ?>" required maxlength="255">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="slug">Slug</label>
        <input type="text" id="slug" name="slug" value="<?php echo e(old('slug', $category->slug)); ?>" maxlength="255" placeholder="auto-from-name">
        <p class="form-hint">Leave blank to generate from name. Used in URLs: /categories/your-slug</p>
        <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <?php echo $__env->make('admin.categories.partials.icon-picker', ['category' => $category, 'iconOptions' => $iconOptions], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="form-group">
        <label for="description">Description</label>
        <textarea id="description" name="description" rows="4" maxlength="5000"><?php echo e(old('description', $category->description)); ?></textarea>
        <p class="form-hint">Shown on the public category page (SEO).</p>
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="sort_order">Sort order</label>
        <input type="number" id="sort_order" name="sort_order" value="<?php echo e(old('sort_order', $category->sort_order ?? 0)); ?>" min="0">
        <p class="form-hint">Lower numbers appear first on the homepage and category list.</p>
        <?php $__errorArgs = ['sort_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-check">
        <input type="checkbox" id="is_active" name="is_active" value="1" <?php if(old('is_active', $category->is_active ?? true)): echo 'checked'; endif; ?>>
        <label for="is_active">Active (visible on site)</label>
    </div>

    <div style="margin-top:1.25rem;display:flex;gap:.75rem;">
        <button type="submit" class="btn btn-primary">Save category</button>
        <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-outline">Cancel</a>
    </div>
</form>

<?php if($category->exists && $category->is_active): ?>
    <p class="form-hint" style="margin-top:1rem;">
        Public page: <a href="<?php echo e(route('categories.show', $category->slug)); ?>" target="_blank" rel="noopener"><?php echo e(route('categories.show', $category->slug)); ?></a>
    </p>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.admin-page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 1rem;
    margin-bottom: 1.5rem;
}
.admin-page-header h1 { margin: 0; }
.category-form.import-card { max-width: 820px; }
.import-card {
    background: var(--card, #fff);
    border: 1px solid var(--border, #e5e7eb);
    border-radius: 8px;
    padding: 1.25rem 1.5rem;
}
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/admin/categories/form.blade.php ENDPATH**/ ?>
<div class="form-group">
    <label for="store-category">Category</label>
    <select name="category_id" id="store-category">
        <option value="">— None —</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>" <?php if(old('category_id', $store->category_id) == $category->id): echo 'selected'; endif; ?>>
                <?php echo e($category->iconEmoji() ? $category->iconEmoji().' ' : ''); ?><?php echo e($category->name); ?><?php echo e($category->isImageIcon() ? ' 🖼' : ''); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <p class="form-hint">Coupons from this store appear under the selected category on the site.</p>
</div>
<?php /**PATH /var/www/couponshere/resources/views/partials/store-category-field.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Coupons Page Display'); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex;justify-content:space-between;align-items:center;gap:1rem;flex-wrap:wrap;margin-bottom:1.5rem;">
    <div>
        <h1 style="margin:0;">Coupons page display</h1>
        <p class="form-hint" style="margin:.35rem 0 0;">Choose which offers appear on the public <a href="<?php echo e(route('coupons.index')); ?>" target="_blank" rel="noopener">/coupons</a> page.</p>
    </div>
    <a href="<?php echo e(route('admin.coupons.index')); ?>" class="btn btn-outline">← Back to coupons</a>
</div>

<form method="POST" action="<?php echo e(route('admin.coupons.catalog-display.update')); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="form-group" style="margin-bottom:1.25rem;">
        <label for="coupons_page_limit">Maximum coupons per page</label>
        <input
            type="number"
            id="coupons_page_limit"
            name="coupons_page_limit"
            min="1"
            max="100"
            value="<?php echo e(old('coupons_page_limit', $couponsPageLimit)); ?>"
            style="max-width:8rem;"
        >
        <p class="form-hint">Only checked offers below are eligible. Up to this many show per page (sorted by order).</p>
        <?php $__errorArgs = ['coupons_page_limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="form-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <?php if($coupons->isEmpty()): ?>
        <p class="form-hint">No coupons yet. <a href="<?php echo e(route('admin.coupons.create')); ?>">Add a coupon</a> first.</p>
    <?php else: ?>
        <div class="store-coupon-display-table-wrap">
            <table class="store-coupon-display-table">
                <thead>
                    <tr>
                        <th>Show</th>
                        <th>Offer</th>
                        <th>Store</th>
                        <th>Status</th>
                        <th>Order</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $selectedIds = old('show_on_coupons');
                            if ($selectedIds === null) {
                                $selectedIds = $coupons->where('show_on_coupons', true)->pluck('id')->all();
                            }
                            $checked = in_array($coupon->id, $selectedIds, true);
                        ?>
                        <tr>
                            <td>
                                <input type="checkbox" name="show_on_coupons[]" value="<?php echo e($coupon->id); ?>" <?php if($checked): echo 'checked'; endif; ?>>
                            </td>
                            <td>
                                <strong><?php echo e($coupon->title); ?></strong>
                                <?php if($coupon->code): ?>
                                    <span class="form-hint" style="display:block;margin:.15rem 0 0;">Code: <?php echo e($coupon->code); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($coupon->store?->name); ?></td>
                            <td>
                                <?php if($coupon->is_active && ! $coupon->isExpired()): ?>
                                    <span class="store-coupon-display-status store-coupon-display-status--active">Active</span>
                                <?php else: ?>
                                    <span class="store-coupon-display-status">Hidden / expired</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <input
                                    type="number"
                                    name="coupons_sort_order[<?php echo e($coupon->id); ?>]"
                                    min="0"
                                    max="9999"
                                    value="<?php echo e(old('coupons_sort_order.'.$coupon->id, $coupon->coupons_sort_order)); ?>"
                                    style="width:5rem;"
                                >
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <p class="form-hint" style="margin-top:.75rem;">Higher order numbers appear first. Uncheck to hide from the coupons listing page.</p>
    <?php endif; ?>

    <button type="submit" class="btn btn-primary" style="margin-top:1.25rem;">Save display settings</button>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.store-coupon-display-table-wrap { overflow-x: auto; }
.store-coupon-display-table {
    width: 100%;
    border-collapse: collapse;
    font-size: .9rem;
}
.store-coupon-display-table th,
.store-coupon-display-table td {
    border: 1px solid var(--border);
    padding: .6rem .65rem;
    text-align: left;
    vertical-align: top;
}
.store-coupon-display-table th {
    background: #f8fafc;
    font-size: .78rem;
    text-transform: uppercase;
    letter-spacing: .03em;
    color: var(--muted);
}
.store-coupon-display-status { font-size: .78rem; color: var(--muted); }
.store-coupon-display-status--active { color: #047857; font-weight: 600; }
.form-error { color: #dc2626; font-size: .875rem; margin-top: .35rem; }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/admin/coupons/catalog-display.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', config('site.name') . ' — Top Hub of US Online Coupons and Promo Codes'); ?>
<?php $__env->startSection('meta_description', config('site.default_description')); ?>
<?php $__env->startSection('og_title', config('site.name') . ' — ' . config('site.tagline')); ?>
<?php $__env->startSection('og_description', config('site.default_description')); ?>
<?php $__env->startSection('canonical', route('home')); ?>
<?php $__env->startSection('og_url', route('home')); ?>

<?php $__env->startPush('structured_data'); ?>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": <?php echo json_encode(config('site.name'), 15, 512) ?>,
    "url": <?php echo json_encode(config('site.url'), 15, 512) ?>,
    "description": <?php echo json_encode(config('site.default_description'), 15, 512) ?>,
    "potentialAction": {
        "@type": "SearchAction",
        "target": {
            "@type": "EntryPoint",
            "urlTemplate": <?php echo json_encode(route('search') . '?q={search_term_string}', 15, 512) ?>
        },
        "query-input": "required name=search_term_string"
    }
}
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php if($activeTheme === 'savingspro'): ?>
    <?php echo $__env->make('themes.savingspro.home-hero', compact('stats'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif($activeTheme === 'prime'): ?>
    <?php echo $__env->make('themes.prime.home-hero', compact('stats'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<section class="hero">
    <div class="container">
        <h1><?php echo e($siteHomeH1); ?></h1>
        <p><?php echo e($siteHomeSubH1); ?>.</p>
        <p class="hero-subtitle"><?php echo e($siteHeroSubtitle); ?></p>
        <form action="<?php echo e(route('search')); ?>" method="GET" class="search-form" style="max-width:480px;margin:0 auto;">
            <input type="search" name="q" placeholder="Search coupons, stores, articles...">
            <button type="submit">Search</button>
        </form>
        <div class="hero-stats">
            <div><strong><?php echo e($stats['coupons']); ?></strong> Active Offers</div>
            <div><strong><?php echo e($stats['stores']); ?></strong> Stores</div>
            <div><strong><?php echo e($stats['categories']); ?></strong> Categories</div>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if($activeTheme === 'prime'): ?>
    <?php echo $__env->make('themes.prime.home-deals', ['hotCoupons' => $hotCoupons ?? collect()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container pch-stats" style="padding-bottom: 2.25rem;">
        <div class="pch-stat-card">
            <strong><?php echo e(number_format($stats['stores'])); ?>+</strong>
            <span>Verified brands</span>
        </div>
        <div class="pch-stat-card">
            <strong><?php echo e(number_format($stats['coupons'])); ?>+</strong>
            <span>Active coupons</span>
        </div>
        <div class="pch-stat-card">
            <strong>Editorial</strong>
            <span>Guides &amp; picks</span>
        </div>
        <div class="pch-stat-card">
            <strong>Daily</strong>
            <span>Fresh checks</span>
        </div>
    </div>
    
    <?php if($latestPosts->isNotEmpty()): ?>
        <?php echo $__env->make('themes.prime.home-blog', ['latestPosts' => $latestPosts], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->make('themes.prime.home-stores', ['stores' => $stores], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('themes.prime.home-categories', ['categories' => $categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if($latestPosts->isNotEmpty() && $activeTheme !== 'prime'): ?>
<section class="section">
    <div class="container">
        <h2 class="section-title">Review <a href="<?php echo e(route('blog.index')); ?>">All articles →</a></h2>
        <div class="blog-grid">
            <?php $__currentLoopData = $latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('blog.partials.card', ['post' => $post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if($activeTheme !== 'prime'): ?>
<section class="section">
    <div class="container">
        <h2 class="section-title"><?php echo e($activeTheme === 'savingspro' ? 'Savings from the World\'s Best Stores' : 'Popular Stores'); ?></h2>
        <div class="store-slider" data-autoplay="3000">
            <div class="store-slider-viewport store-scroll--autoplay" tabindex="0" aria-label="Popular stores">
                <div class="store-scroll-track">
                <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('stores.show', $store->slug)); ?>" class="store-chip store-chip--logo">
                        <?php echo $__env->make('partials.store-logo', ['store' => $store, 'size' => 'md', 'showVerified' => false, 'linked' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <strong><?php echo e($store->name); ?></strong>
                        <small><?php echo e($store->activeCouponsCount()); ?> offers</small>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="store-slider-dots" role="tablist" aria-label="Popular stores slides">
                <?php for($i = 0; $i < max(1, $stores->count() - 1); $i++): ?>
                    <button
                        type="button"
                        class="store-slider-dot<?php echo e($i === 0 ? ' is-active' : ''); ?>"
                        data-slide-index="<?php echo e($i); ?>"
                        role="tab"
                        aria-label="Slide <?php echo e($i + 1); ?>"
                        aria-selected="<?php echo e($i === 0 ? 'true' : 'false'); ?>"
                    ></button>
                <?php endfor; ?>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <h2 class="section-title">Categories</h2>
        <div class="category-grid home-category-grid">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('categories.show', $category->slug)); ?>" class="category-chip">
                    <span class="icon"><?php echo $__env->make('partials.category-icon', ['category' => $category, 'size' => 'md'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
                    <strong><?php echo e($category->name); ?></strong>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if($activeTheme === 'savingspro'): ?>
    <?php echo $__env->make('themes.savingspro.newsletter-cta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/home.blade.php ENDPATH**/ ?>
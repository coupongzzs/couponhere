<section class="pch-deals section">
    <div class="container">
        <p class="pch-deals-eyebrow">Limited windows</p>
        <h2 class="pch-deals-title">Hot coupons &amp; standout deals</h2>
        <p class="pch-deals-subtitle">
            High-signal picks from brands we track — copy a code or open the offer in one tap.
        </p>

        <div class="pch-disclosure-box">
            Promotions can expire or change without notice. We may earn a commission when you shop via our links —
            <a href="<?php echo e(route('pages.disclaimer')); ?>">see disclosure</a>.
        </div>

        <?php if($hotCoupons->isNotEmpty()): ?>
            <div class="pch-coupon-grid">
                <?php $__currentLoopData = $hotCoupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.coupon-card', ['coupon' => $coupon], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="pch-deals-more">
                <a href="<?php echo e(route('coupons.index')); ?>" class="pch-deals-more-link">Browse all coupons →</a>
            </div>
        <?php else: ?>
            <p class="pch-deals-empty">No active coupons yet. Check back soon.</p>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH /var/www/couponshere/resources/views/themes/prime/home-deals.blade.php ENDPATH**/ ?>
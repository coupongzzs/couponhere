<?php $__env->startSection('title', $store->seoTitle()); ?>
<?php $__env->startSection('meta_description', $store->seoDescription()); ?>
<?php $__env->startSection('og_title', $store->ogShareTitle()); ?>
<?php $__env->startSection('og_description', $store->ogShareDescription()); ?>
<?php $__env->startSection('canonical', route('stores.show', $store->slug)); ?>
<?php $__env->startSection('og_url', route('stores.show', $store->slug)); ?>
<?php if($store->ogImageUrl()): ?>
<?php $__env->startSection('og_image', $store->ogImageUrl()); ?>
<?php endif; ?>
<?php $__env->startSection('og_image_alt', $store->name); ?>

<?php $__env->startPush('og_meta'); ?>
<?php if($store->ogImageUrl()): ?>
<meta property="og:image:secure_url" content="<?php echo e(\App\Support\Seo::absoluteUrl($store->ogImageUrl())); ?>">
<?php endif; ?>
<meta property="og:updated_time" content="<?php echo e($store->updated_at?->toIso8601String()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('structured_data'); ?>
<?php echo $__env->make('partials.breadcrumb-schema', ['breadcrumbs' => [
    ['name' => 'Home', 'url' => route('home')],
    ['name' => 'Stores', 'url' => route('stores.index')],
    ['name' => $store->name, 'url' => route('stores.show', $store->slug)],
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="application/ld+json">
<?php echo json_encode($store->structuredData(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE, 512) ?>
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('head_links'); ?>
    <?php echo $__env->make('partials.pagination-seo', ['paginator' => $coupons], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="sp-store-page">
    <div class="container">
        <div class="sp-store-hero">
            <?php echo $__env->make('partials.store-logo', ['store' => $store, 'size' => 'xl', 'showVerified' => false, 'linked' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="sp-store-hero-body">
                <h1><?php echo e($store->name); ?> Promo Codes &amp; Coupons</h1>
                <span class="sp-verified-badge sp-verified-badge--lg">Verified</span>
                <?php if($store->description): ?>
                    <p class="sp-store-hero-desc"><?php echo e(\Illuminate\Support\Str::limit(strip_tags($store->description), 220)); ?></p>
                <?php else: ?>
                    <p class="sp-store-hero-desc">Browse verified <?php echo e($store->name); ?> coupon codes and discount deals updated on <?php echo e(config('site.domain')); ?>.</p>
                <?php endif; ?>
                <?php echo $__env->make('partials.store-shop-cta', ['store' => $store], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('partials.social-share', [
                    'url' => route('stores.show', $store->slug),
                    'title' => $store->seoTitle(),
                    'description' => $store->seoDescription(),
                    'store' => $store,
                    'label' => 'Share this store',
                    'compact' => true,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <?php echo $__env->make('partials.site-affiliate-notice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="sp-store-layout">
            <aside class="sp-store-sidebar">
                <?php if($similarStores->isNotEmpty()): ?>
                    <div class="sp-sidebar-box">
                        <h3>Similar Stores</h3>
                        <ul class="sp-similar-stores">
                            <?php $__currentLoopData = $similarStores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('stores.show', $similar->slug)); ?>">
                                        <?php echo $__env->make('partials.store-logo', ['store' => $similar, 'size' => 'md', 'showVerified' => false, 'linked' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <span><?php echo e($similar->name); ?></span>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if($topCategories->isNotEmpty()): ?>
                    <div class="sp-sidebar-box">
                        <h3>Top Categories</h3>
                        <div class="sp-category-tags">
                            <?php $__currentLoopData = $topCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('categories.show', $category->slug)); ?>" class="sp-category-tag"><?php echo e($category->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </aside>

            <div class="sp-store-main">
                <?php if($store->description): ?>
                    <div class="store-description-content" id="store-full-desc"><?php echo $store->renderedDescription(); ?></div>
                <?php endif; ?>
                <div class="sp-store-offers-head">
                    <h2>Active <?php echo e($store->name); ?> Offers (<?php echo e($coupons->total()); ?>)</h2>
                </div>
                <div class="sp-coupon-list">
                    <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php echo $__env->make('themes.savingspro.coupon-row', ['coupon' => $coupon, 'openAffiliateOnCopy' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="sp-empty">No coupons available for this store yet.</p>
                    <?php endif; ?>
                </div>
                <div class="pagination"><?php echo e($coupons->links()); ?></div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('partials.scroll-coupon-popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/themes/savingspro/store-show.blade.php ENDPATH**/ ?>
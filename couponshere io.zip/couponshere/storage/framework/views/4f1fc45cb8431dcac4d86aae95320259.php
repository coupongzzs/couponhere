<?php $__env->startSection('title', 'Sign In'); ?>
<?php $__env->startSection('meta_robots', 'noindex, nofollow'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="max-width:400px;padding:3rem 1rem;">
    <h1 style="margin-bottom:1.5rem;">Sign In</h1>
    <?php if($errors->any()): ?>
        <div class="alert alert-error">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($error); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required>
        </div>
        <div class="form-check">
            <input type="checkbox" name="remember" id="remember">
            <label for="remember">Remember me</label>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;margin-top:1rem;padding:.75rem;">Sign In</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/auth/login.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Our Authors — ' . config('site.name')); ?>
<?php $__env->startSection('meta_description', 'Meet the writers behind savings guides, coupon tips, and deal reviews at ' . config('site.name') . '.'); ?>
<?php $__env->startSection('canonical', route('authors.index')); ?>

<?php $__env->startSection('content'); ?>
<section class="page-hero">
    <div class="container">
        <h1>Our Authors</h1>
        <p class="page-subtitle">Meet the editorial team and writers behind our coupon guides and savings articles.</p>
    </div>
</section>

<div class="container page-body">
    <div class="author-grid">
        <article class="author-card">
            <a href="<?php echo e($defaultAuthor->url()); ?>" class="author-card-avatar" aria-hidden="true">
                <?php if($defaultAuthor->avatarUrl): ?>
                    <img src="<?php echo e($defaultAuthor->avatarUrl); ?>" alt="<?php echo e($defaultAuthor->name); ?>">
                <?php else: ?>
                    <?php echo e($defaultAuthor->initials()); ?>

                <?php endif; ?>
            </a>
            <div class="author-card-body">
                <h2><a href="<?php echo e($defaultAuthor->url()); ?>"><?php echo e($defaultAuthor->name); ?></a></h2>
                <?php if($defaultAuthor->title): ?>
                    <p class="author-card-title"><?php echo e($defaultAuthor->title); ?></p>
                <?php endif; ?>
                <p class="author-card-bio"><?php echo e(Str::limit($defaultAuthor->bio, 180)); ?></p>
                <p class="author-card-meta"><?php echo e($defaultAuthor->publishedPostCount()); ?> articles</p>
                <a href="<?php echo e($defaultAuthor->url()); ?>" class="read-more">View profile →</a>
            </div>
        </article>

        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="author-card">
                <a href="<?php echo e($author->url()); ?>" class="author-card-avatar" aria-hidden="true">
                    <?php if($author->avatarUrl): ?>
                        <img src="<?php echo e($author->avatarUrl); ?>" alt="<?php echo e($author->name); ?>">
                    <?php else: ?>
                        <?php echo e($author->initials()); ?>

                    <?php endif; ?>
                </a>
                <div class="author-card-body">
                    <h2><a href="<?php echo e($author->url()); ?>"><?php echo e($author->name); ?></a></h2>
                    <?php if($author->title): ?>
                        <p class="author-card-title"><?php echo e($author->title); ?></p>
                    <?php endif; ?>
                    <p class="author-card-bio"><?php echo e(Str::limit($author->bio, 180)); ?></p>
                    <p class="author-card-meta"><?php echo e($author->publishedPostCount()); ?> articles</p>
                    <a href="<?php echo e($author->url()); ?>" class="read-more">View profile →</a>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/authors/index.blade.php ENDPATH**/ ?>
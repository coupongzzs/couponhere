<?php $__env->startSection('title', 'Manage Coupons'); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;flex-wrap:wrap;gap:.75rem;">
    <div>
        <h1 style="margin:0;">Coupons</h1>
        <p class="form-hint" style="margin:.35rem 0 0;">Drag rows to set display order on the public <a href="<?php echo e(route('coupons.index')); ?>" target="_blank" rel="noopener">/coupons</a> page, store pages, and the scroll coupon popup. Top rows appear first. Filter by store first if you only want to reorder that store.</p>
    </div>
    <div style="display:flex;gap:.5rem;flex-wrap:wrap;">
        <a href="<?php echo e(route('admin.coupons.catalog-display')); ?>" class="btn btn-outline">Coupons page display</a>
        <a href="<?php echo e(route('admin.coupons.create')); ?>" class="btn btn-primary">+ Add Coupon</a>
    </div>
</div>

<?php echo $__env->make('partials.coupon-index-filters', ['action' => route('admin.coupons.index'), 'stores' => $stores, 'statsDate' => $statsDate ?? null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('partials.click-stats-date-filter', [
    'action' => route('admin.coupons.index'),
    'statsDate' => $statsDate ?? now()->toDateString(),
    'period' => $period ?? null,
    'preserve' => array_filter([
        'title' => request('title'),
        'store_id' => request('store_id'),
    ]),
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="coupon-sort-table-wrap">
<table class="admin-table coupon-sort-table">
    <thead>
        <tr>
            <th class="coupon-sort-col" aria-label="Reorder"></th>
            <th>Page order</th>
            <th>Title</th>
            <th>Store</th>
            <th>Code</th>
            <th>Type</th>
            <th>On /coupons</th>
            <th>Status</th>
            <th>Day</th>
            <th>Month</th>
            <th>Year</th>
            <th>Total</th>
            <th class="table-actions-col">Actions</th>
        </tr>
    </thead>
    <tbody id="coupon-sortable" data-reorder-url="<?php echo e(route('admin.coupons.sort-order')); ?>">
        <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr data-coupon-id="<?php echo e($coupon->id); ?>">
                <td class="coupon-sort-col">
                    <button type="button" class="coupon-sort-handle" aria-label="Drag to reorder <?php echo e($coupon->title); ?>" title="Drag to reorder">⠿</button>
                </td>
                <td><span class="coupon-sort-order" data-order-label><?php echo e($coupon->coupons_sort_order); ?></span></td>
                <td><?php echo e($coupon->title); ?></td>
                <td><?php echo e($coupon->store?->name); ?></td>
                <td><code><?php echo e($coupon->code ?? '—'); ?></code></td>
                <td><?php echo e($coupon->typeLabel()); ?></td>
                <td><?php echo e($coupon->show_on_coupons ? 'Yes' : 'No'); ?></td>
                <td><?php echo e($coupon->is_active ? 'Active' : 'Inactive'); ?></td>
                <td><strong><?php echo e(number_format((int) ($coupon->day_clicks ?? 0))); ?></strong></td>
                <td><?php echo e(number_format((int) ($coupon->month_clicks ?? 0))); ?></td>
                <td><?php echo e(number_format((int) ($coupon->year_clicks ?? 0))); ?></td>
                <td><strong><?php echo e(number_format($coupon->click_count)); ?></strong></td>
                <td>
                    <?php echo $__env->make('partials.coupon-table-actions', [
                        'coupon' => $coupon,
                        'editUrl' => route('admin.coupons.edit', $coupon),
                        'destroyUrl' => route('admin.coupons.destroy', $coupon),
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="13"><?php echo e(request()->hasAny(['title', 'store_id']) ? 'No coupons match your search.' : 'No coupons yet.'); ?></td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
</div>

<?php echo $__env->make('partials.table-actions-assets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.coupon-sort-col { width: 2.5rem; text-align: center; }
.coupon-sort-handle {
    border: 0;
    background: transparent;
    color: var(--muted);
    cursor: grab;
    font-size: 1.1rem;
    line-height: 1;
    padding: .15rem .35rem;
}
.coupon-sort-handle:active { cursor: grabbing; }
.coupon-sort-table tr.is-dragging { opacity: .55; }
.coupon-sort-table tr.is-drop-target td { background: #eff6ff; }
.coupon-sort-order {
    display: inline-block;
    min-width: 2rem;
    font-weight: 600;
    color: #1d4ed8;
}
.coupon-sort-status {
    margin: 0 0 .75rem;
    font-size: .875rem;
    color: var(--muted);
}
.coupon-sort-status[data-type="success"] { color: #047857; }
.coupon-sort-status[data-type="error"] { color: #dc2626; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/admin-coupon-sort.js')); ?>?v=<?php echo e(filemtime(public_path('js/admin-coupon-sort.js'))); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/admin/coupons/index.blade.php ENDPATH**/ ?>
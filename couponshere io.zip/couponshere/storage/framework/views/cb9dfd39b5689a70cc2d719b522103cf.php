<section class="section pch-blog-section">
    <div class="container">
        <p class="pch-deals-eyebrow">Editorial</p>
        <h2 class="pch-deals-title">Latest from the blog</h2>
        <p class="pch-deals-subtitle">
            Short reads on saving tactics, store notes, and what changed this week.
        </p>

        <div class="pch-blog-grid">
            <?php $__currentLoopData = $latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('themes.prime.blog-card', ['post' => $post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="pch-deals-more">
            <a href="<?php echo e(route('blog.index')); ?>" class="pch-deals-more-link">Browse the full archive</a>
        </div>
    </div>
</section>
<?php /**PATH /var/www/couponshere/resources/views/themes/prime/home-blog.blade.php ENDPATH**/ ?>
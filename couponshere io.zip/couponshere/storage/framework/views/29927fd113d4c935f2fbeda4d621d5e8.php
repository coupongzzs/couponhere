<?php $__env->startSection('title', $q ? "Blog Search: {$q}" : 'Blog — Coupon Tips & Savings Guides'); ?>
<?php $__env->startSection('meta_description', 'Expert guides on coupon codes, online deals, and smart shopping tips for U.S. consumers. ' . config('site.tagline')); ?>
<?php $__env->startSection('canonical', $posts->currentPage() > 1 ? $posts->url($posts->currentPage()) : route('blog.index')); ?>

<?php $__env->startPush('head_links'); ?>
    <?php echo $__env->make('partials.pagination-seo', ['paginator' => $posts], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="page-hero">
    <div class="container">
        <h1>Savings Blog</h1>
        <p class="page-subtitle">Coupon strategies, deal guides, and shopping tips to help you save more online.</p>
        <p class="page-subtitle"><a href="<?php echo e(route('authors.index')); ?>">Meet our authors →</a></p>
    </div>
</section>

<div class="container page-body">
    <form action="<?php echo e(route('blog.index')); ?>" method="GET" class="blog-search">
        <input type="search" name="q" placeholder="Search articles..." value="<?php echo e($q); ?>">
        <button type="submit" class="btn btn-primary">Search</button>
    </form>

    <?php if($posts->isEmpty()): ?>
        <p class="blog-empty">No articles found.<?php if($q): ?> Try a different keyword.<?php endif; ?></p>
    <?php else: ?>
        <div class="blog-grid<?php echo e(($activeTheme ?? '') === 'prime' ? ' pch-blog-grid' : ''); ?>">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(($activeTheme ?? '') === 'prime'): ?>
                    <?php echo $__env->make('themes.prime.blog-card', ['post' => $post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php else: ?>
                    <?php echo $__env->make('blog.partials.card', ['post' => $post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="pagination"><?php echo e($posts->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/blog/index.blade.php ENDPATH**/ ?>
<?php if(!empty($breadcrumbs)): ?>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
<?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $crumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        {
            "@type": "ListItem",
            "position": <?php echo e($i + 1); ?>,
            "name": <?php echo json_encode($crumb['name'], 15, 512) ?>,
            "item": <?php echo json_encode($crumb['url'] ?? null, 15, 512) ?>
        }<?php if(!$loop->last): ?>,<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ]
}
</script>
<?php endif; ?>
<?php /**PATH /var/www/couponshere/resources/views/partials/breadcrumb-schema.blade.php ENDPATH**/ ?>
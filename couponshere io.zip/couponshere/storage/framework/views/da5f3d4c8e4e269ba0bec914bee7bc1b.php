<?php $__env->startSection('content'); ?>
<div class="page-hero">
    <div class="container">
        <h1><?php echo $__env->yieldContent('page_title'); ?></h1>
        <?php if (! empty(trim($__env->yieldContent('page_subtitle')))): ?>
            <p class="page-subtitle"><?php echo $__env->yieldContent('page_subtitle'); ?></p>
        <?php endif; ?>
        <?php if (! empty(trim($__env->yieldContent('page_meta')))): ?>
            <p class="page-meta"><?php echo $__env->yieldContent('page_meta'); ?></p>
        <?php endif; ?>
    </div>
</div>
<div class="container page-body">
    <div class="legal-content legal-content--page">
        <?php echo $__env->yieldContent('page_content'); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/layouts/page.blade.php ENDPATH**/ ?>
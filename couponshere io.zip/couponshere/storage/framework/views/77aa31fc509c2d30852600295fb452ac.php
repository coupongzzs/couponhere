<?php $__env->startSection('title', 'Blog Posts'); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;flex-wrap:wrap;gap:.75rem;">
    <h1 style="margin:0;">Blog Posts</h1>
    <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-primary">+ New Post</a>
</div>

<?php echo $__env->make('partials.admin-list-search', [
    'action' => route('admin.posts.index'),
    'value' => $q ?? '',
    'placeholder' => 'Search by title…',
    'clearUrl' => route('admin.posts.index'),
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<table class="admin-table">
    <thead>
        <tr>
            <th>Image</th>
            <th>Title</th>
            <th>Home</th>
            <th>Status</th>
            <th>Published</th>
            <th>Views</th>
            <th class="table-actions-col">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <?php if($post->featuredImageUrl()): ?>
                        <img src="<?php echo e($post->featuredImageUrl()); ?>" alt="" class="admin-thumb admin-thumb--wide" loading="lazy">
                    <?php else: ?>
                        <span class="admin-thumb-empty">—</span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($post->title); ?></td>
                <td>
                    <form action="<?php echo e(route('admin.posts.toggle-home-pin', $post)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button type="submit" class="btn btn-outline btn-sm" title="<?php echo e($post->is_pinned_home ? 'Unpin from homepage' : 'Pin to homepage'); ?>">
                            <?php echo e($post->is_pinned_home ? '📌 Pinned' : 'Pin'); ?>

                        </button>
                    </form>
                </td>
                <td><?php echo e($post->is_published ? 'Published' : 'Draft'); ?></td>
                <td><?php echo e($post->published_at?->format('m/d/Y') ?? '—'); ?></td>
                <td><?php echo e(number_format($post->view_count)); ?></td>
                <td>
                    <?php echo $__env->make('partials.post-table-actions', [
                        'post' => $post,
                        'editUrl' => route('admin.posts.edit', $post),
                        'destroyUrl' => route('admin.posts.destroy', $post),
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7"><?php echo e(filled($q ?? null) ? 'No blog posts match your search.' : 'No blog posts yet.'); ?></td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php echo e($posts->links()); ?>


<?php echo $__env->make('partials.table-actions-assets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.btn-sm { padding: .25rem .55rem; font-size: .8125rem; }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/admin/posts/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Affiliate Orders'); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex;justify-content:space-between;margin-bottom:1.5rem;flex-wrap:wrap;gap:.75rem;">
    <h1>Affiliate Orders</h1>
    <div style="display:flex;gap:.5rem;flex-wrap:wrap;">
        <a href="<?php echo e(route('admin.affiliate.payouts.index')); ?>" class="btn btn-outline">Payout Requests</a>
        <a href="<?php echo e(route('admin.affiliate.orders.create')); ?>" class="btn btn-primary">+ Log Order</a>
    </div>
</div>

<table class="admin-table">
    <thead>
        <tr>
            <th>Order</th>
            <th>Referrer</th>
            <th>Customer</th>
            <th>Amount</th>
            <th>Commission</th>
            <th>Status</th>
            <th class="table-actions-col">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td>
                <code><?php echo e($order->order_number); ?></code>
                <?php if($order->description): ?>
                    <br><small style="color:var(--muted);"><?php echo e($order->description); ?></small>
                <?php endif; ?>
            </td>
            <td><?php echo e($order->referrer?->name); ?><br><small style="color:var(--muted);"><?php echo e($order->referrer?->email); ?></small></td>
            <td>
                <?php echo e($order->customer_name ?: ($order->referredUser?->name ?: '—')); ?>

                <?php if($order->customer_email): ?>
                    <br><small style="color:var(--muted);"><?php echo e($order->customer_email); ?></small>
                <?php endif; ?>
            </td>
            <td><?php echo e(number_format($order->amount, 2)); ?> <?php echo e($currency); ?></td>
            <td>
                <?php echo e(number_format($order->commission_rate, 0)); ?>%
                <?php if($order->commission_credited): ?>
                    <br><strong><?php echo e(number_format($order->commission_amount, 2)); ?></strong>
                <?php endif; ?>
            </td>
            <td><?php echo e($order->statusLabel()); ?></td>
            <td>
                <a href="<?php echo e(route('admin.affiliate.orders.edit', $order)); ?>" class="btn btn-outline btn-sm">Edit</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="7">No affiliate orders yet. <a href="<?php echo e(route('admin.affiliate.orders.create')); ?>">Log the first order</a>.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php echo e($orders->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/admin/affiliate/orders/index.blade.php ENDPATH**/ ?>
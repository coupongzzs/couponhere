<header class="site-header">
    <div class="pch-topbar">
        Verified deals · Updated regularly ·
        <a href="<?php echo e(route('pages.disclaimer')); ?>">How we earn</a>
    </div>

    <div class="container header-inner">
        <?php echo $__env->make('partials.site-brand', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <button
            type="button"
            class="nav-toggle"
            data-nav-toggle
            aria-expanded="false"
            aria-controls="main-nav"
            aria-label="Open menu"
        >
            <span class="nav-toggle-bars" aria-hidden="true"></span>
        </button>

        <nav class="main-nav" id="main-nav" data-main-nav>
            <a href="<?php echo e(route('home')); ?>">Home</a>
            <a href="<?php echo e(route('blog.index')); ?>">Blog</a>
            <a href="<?php echo e(route('pages.about')); ?>">About Us</a>
            <a href="<?php echo e(route('pages.contact')); ?>">Contact</a>
        </nav>
    </div>
</header>

<?php /**PATH /var/www/couponshere/resources/views/themes/prime/partials/header.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', $post->seoTitle()); ?>
<?php $__env->startSection('meta_description', $post->seoDescription()); ?>
<?php $__env->startSection('og_title', $post->ogShareTitle()); ?>
<?php $__env->startSection('og_description', $post->ogShareDescription()); ?>
<?php $__env->startSection('canonical', route('blog.show', $post->slug)); ?>
<?php $__env->startSection('og_url', route('blog.show', $post->slug)); ?>
<?php $__env->startSection('og_type', 'article'); ?>
<?php if($post->ogImageUrl()): ?>
<?php $__env->startSection('og_image', $post->ogImageUrl()); ?>
<?php endif; ?>
<?php $__env->startSection('og_image_alt', $post->title); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .article-content h2 { font-size: 1.35rem; margin: 2rem 0 .75rem; color: var(--secondary); }
    .article-content h3 { font-size: 1.1rem; margin: 1.5rem 0 .5rem; }
    .article-content p { margin-bottom: 1rem; line-height: 1.75; color: #374151; }
    .article-content ul, .article-content ol { margin: 0 0 1rem 1.25rem; color: #374151; }
    .article-content li { margin-bottom: .4rem; }
    .article-content a { color: var(--primary); }
    .article-content img { max-width: 100%; height: auto; border-radius: 8px; display: block; margin: .75rem 0 1rem; }
    .article-content .article-media { margin: 1rem 0 1.25rem; max-width: 100%; }
    .article-content .article-media img { margin: 0; }
    .article-content .article-media--logo { max-width: 160px; }
    .article-content .article-media--logo img { width: 160px; height: auto; object-fit: contain; }
    .article-content .article-media figcaption {
        margin-top: .4rem;
        font-size: .875rem;
        color: #64748b;
    }
    .article-content pre,
    .article-content code {
        max-width: 100%;
        overflow-x: auto;
        white-space: pre-wrap;
        word-break: break-word;
    }
    .article-content iframe,
    .article-content video {
        max-width: 100%;
    }
    .article-content table.comparison-table,
    .article-content table {
        width: max-content;
        min-width: 100%;
        border-collapse: collapse;
        margin: 1rem 0 1.5rem;
        font-size: .95rem;
        table-layout: auto;
    }
    .article-content table.comparison-table th,
    .article-content table.comparison-table td,
    .article-content table th,
    .article-content table td {
        border: 1px solid var(--border);
        padding: .65rem .75rem;
        text-align: left;
        vertical-align: top;
        overflow-wrap: normal;
        word-break: normal;
        hyphens: manual;
        min-width: 10rem;
        max-width: 16rem;
    }
    .article-content table.comparison-table th:first-child,
    .article-content table.comparison-table td:first-child,
    .article-content table th:first-child,
    .article-content table td:first-child {
        min-width: 7.5rem;
        max-width: 10rem;
    }
    .article-content table.comparison-table th,
    .article-content table th {
        background: #f8fafc;
        font-weight: 600;
    }
    .article-content .embedded-coupon-list {
        max-width: 100%;
        min-width: 0;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('structured_data'); ?>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    "headline": <?php echo json_encode($post->title, 15, 512) ?>,
    "description": <?php echo json_encode($post->seoDescription(), 15, 512) ?>,
    "datePublished": <?php echo json_encode($post->published_at?->toIso8601String(), 15, 512) ?>,
    "dateModified": <?php echo json_encode($post->updated_at->toIso8601String(), 15, 512) ?>,
    "author": {
        "@type": "Person",
        "name": <?php echo json_encode($post->authorProfile()->name, 15, 512) ?>,
        "url": <?php echo json_encode($post->authorProfile()->url(), 15, 512) ?>
    },
    "publisher": {
        "@type": "Organization",
        "name": <?php echo json_encode(config('site.name'), 15, 512) ?>,
        "url": <?php echo json_encode(config('site.url'), 15, 512) ?>
    },
    "mainEntityOfPage": <?php echo json_encode(route('blog.show', $post->slug), 512) ?>
}
</script>
<?php echo $__env->make('partials.breadcrumb-schema', ['breadcrumbs' => [
    ['name' => 'Home', 'url' => route('home')],
    ['name' => 'Blog', 'url' => route('blog.index')],
    ['name' => $post->title, 'url' => route('blog.show', $post->slug)],
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<article class="blog-article">
    <header class="blog-article-header">
        <div class="container">
            <a href="<?php echo e(route('blog.index')); ?>" class="blog-back">← Back to Blog</a>
            <h1><?php echo e($post->title); ?></h1>
        </div>
    </header>

    <?php if($post->featuredImageUrl()): ?>
        <div class="container">
            <div class="blog-featured-img-wrap">
                <img src="<?php echo e($post->featuredImageUrl()); ?>" alt="<?php echo e($post->title); ?>" class="blog-featured-img">
            </div>
        </div>
    <?php endif; ?>

    <div class="container">
        <div class="blog-article-layout">
            <div class="article-content legal-content">
                <?php echo $post->renderedContent(); ?>

            </div>
            <aside class="blog-sidebar">
                <?php echo $__env->make('partials.social-share', [
                    'url' => route('blog.show', $post->slug),
                    'title' => $post->title,
                    'description' => $post->seoDescription(),
                    'image' => $post->featuredImageUrl(),
                    'label' => 'Share this article',
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('blog.partials.author-box', ['post' => $post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="sidebar-box">
                    <h3>Save More Today</h3>
                    <p>Browse verified coupon codes at <?php echo e(config('site.name')); ?>.</p>
                    <a href="<?php echo e(route('coupons.index')); ?>" class="btn btn-primary" style="width:100%;text-align:center;">View Coupons</a>
                </div>
            </aside>
        </div>
    </div>
</article>

<?php if($related->isNotEmpty()): ?>
<section class="section">
    <div class="container">
        <h2 class="section-title">Related Articles</h2>
        <div class="blog-grid">
            <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('blog.partials.card', ['post' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php echo $__env->make('partials.scroll-coupon-popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/couponshere/resources/views/blog/show.blade.php ENDPATH**/ ?>